#############################
#Download and create a GSE-class into working directory or loads GSE series matrix from a file in working directory
#############################
dol.gse <- function (GEOID, wd.here = T, wd.path = NULL, GSEMatrix = T, ...){
        if (wd.here){
                wd <- getwd()
        }
        if (!wd.here){
                wd <- wd.path
        }
        dir <- dir(wd)
        dname <- GEOID
        chk.exist.dir <- grepl (paste ("^", GEOID, "$", sep = ""), dir, ignore.case = F)
        if (!any (chk.exist.dir)) {
                dir.create(paste(wd, "/", dname, sep = ""))
                destsave <- paste(wd, dname, sep = "/")
                gse <- getGEO (GEOID, GSEMatrix = GSEMatrix, destdir = destsave, ... = ...)
                gse <- gse[[1]]
        }
        if (any (chk.exist.dir)){
                geoidpath <- paste (wd, GEOID, sep = "/")
                chk.matrix <- grepl (paste("^", GEOID, ".*_series_matrix.txt.gz$", sep = ""), dir(geoidpath))
                if (sum(chk.matrix) == 0){
                        destsave <- paste(wd, dname, sep = "/")
                        gse <- getGEO (GEOID, GSEMatrix = GSEMatrix, destdir = destsave, ... = ...)
                        gse.length <- length(gse)
                        if (gse.length != 1) {
                                options <- data.frame("Series Matrix" = names(gse), stringsAsFactors = F)
                                print(options)
                                answer <- readline ("Found more than one series_matrix.txt.gz file. Which number should be used?")
                                gse <- gse[[as.integer(answer)]]
                        }
                }
                if (sum(chk.matrix) == 1){
                        get.matrix <- grep (paste("^", GEOID, ".*_series_matrix.txt.gz$", sep = ""), dir(geoidpath))
                        if (length(get.matrix) == 0){
                                stop (paste(paste(GEOID, "_series_matrix.txt.gz", sep = ""), "not found.", sep = " "))
                        }
                        if (length(get.matrix) == 1){
                                gse <- getGEO (GEOID, destdir = geoidpath, GSEMatrix = GSEMatrix, ... = ...)
                                gse <- gse[[1]]
                        }
                }
                if (sum(chk.matrix) > 1){
                        get.matrix <- grepl(paste("^", GEOID, ".*_series_matrix.txt.gz$", sep = ""), dir(geoidpath), ignore.case = T)
                        get.matrix <- dir(geoidpath)[get.matrix]
                        options <- data.frame("Series Matrix" = get.matrix, stringsAsFactors = F)
                        print(options)
                        answer <- readline ("Found more than one series_matrix.txt.gz file. Which number should be used?")
                        gse <- getGEO (GEOID, destdir = geoidpath, GSEMatrix = GSEMatrix, ... = ...)[[get.matrix[as.integer(answer)]]]
                }
        }
        return(gse)
}