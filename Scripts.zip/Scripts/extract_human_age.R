setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets")
d <- dir()
gses <- d[grep(pattern = "^gse", x = d, ignore.case = T)]
gses <- gses[-5]
names(gses) <- gses
pdat <- sapply(gses, function(s) {
     x <- dir(s)[grep(pattern = "phenodata", x = dir(s), ignore.case = T)]
     paste(s, x, sep = "/")
})
pdat <- lapply(pdat, read.delim, header = T, sep = "\t", stringsAsFactors = F)
pdat <- lapply(pdat, function(x) {
     i <- grep(pattern = "characteristics_", x = names(x), ignore.case = T)
     x[,i]
})
age <- lapply(pdat, function(x) {
     x <- x[,!sapply(x, function(y) any(is.na(y)))]
     ev <- sapply(x, function(y) all(grepl(pattern = "^age", x = y, ignore.case = T)))
     xx <- x[,ev]
     xx <- strsplit(x = xx, split = " ")
     sapply(xx, function(y) na.omit(as.numeric(y)))
})
summary(do.call("c", age))
