#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("arrayQualityMetrics",
                  "AffyCompatible",
                  "GEOquery"), repos = "http://bioconductor.org/biocLite.R")

#############################
# Data
#############################
GEOID <- "GSE123496"
fname <- paste(getwd(), GEOID, "txi.RData", sep = "/")
load(fname)

processed_metadata <- read.delim(paste(getwd(), GEOID, "processed_metadata.txt", sep = "/"), stringsAsFactors=FALSE)

#############################
# Create dds object
#############################
samples <- processed_metadata
ddsTxi <- DESeqDataSetFromTximport(txi,
                                   colData = samples,
                                   design = ~ condition1)
ddsTxi <- DESeq2::estimateSizeFactors(ddsTxi)
ddsTxi <- DESeq2::estimateDispersions(ddsTxi)
dds <- ddsTxi

#############################
# Create eSet
#############################
## Pre-filtering the dataset
### count filter
count_filter <- row.names(tweeDEseq::filterCounts(counts(dds), mean.cpm.cutoff = 2))
dds <- dds[count_filter, ]
## regularized-logarithm transformation or rlog
rld <- rlog(dds, blind = FALSE)

## phenoData
phenoDat <- colData(dds)
phenoDat <- sapply(phenoDat@listData, as.character)
phenoDat <- data.frame(phenoDat, stringsAsFactors = F)
row.names(phenoDat) <- phenoDat$Run
phenoDat <- as(phenoDat, "AnnotatedDataFrame")
## assayData
assayDat <- assay(rld)
assayDat <- assayDat
## featureData
ann <- read.delim(paste(getwd(), GEOID, "processed_annotation.txt", sep = "/"), stringsAsFactors=FALSE)
featlist <- unique(ann[,-1])
featlist <- subset(featlist, subset = featlist$ENSEMBL %in% row.names(assayDat))
featlist <- split(x = featlist, f = featlist$ENSEMBL)
featlist <- lapply(X = featlist, FUN = function(df) {
     if(nrow(df) > 1) {
          x1 <- unique(df[,-3])
          x2 <- paste(unique(df[,3]), collapse = "/")
          x <- cbind(x1, x2)
          x <- sapply(x, as.character)
          names(x) <- colnames(df)
          return(x)
     }
     x <- unlist(df)
     return(x)
})
featlist <- do.call("rbind", featlist)
featlist <- unique(featlist)
featlist <- data.frame(featlist, stringsAsFactors = F, row.names = featlist[,1])
featlist <- featlist[row.names(assayDat)[row.names(assayDat) %in% featlist[,1]],]
featureDat <- as(featlist, "AnnotatedDataFrame")
## ExpressionSet
myEset <- ExpressionSet(assayData = assayDat[featlist$ENSEMBL,], phenoData = phenoDat, featureData = featureDat)
gse <- myEset

#############################
# Quality Control Processed
#############################
qc <- arrayQualityMetrics(expressionset = gse,
                          outdir = paste(getwd(), GEOID, "QC_Processed", sep = "/"),
                          do.logtransform = F,
                          force = T,
                          reporttitle = "QC_report",
                          intgroup = "condition1",
                          spatial = F)
qc_table <- qc$arrayTable
write.table(x = qc_table, file = paste(getwd(), GEOID, "QC_table.txt", sep = "/"), sep = "\t", row.names = F)
