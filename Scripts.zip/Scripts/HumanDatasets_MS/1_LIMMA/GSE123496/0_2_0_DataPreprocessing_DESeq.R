#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("tximport",
                  "DESeq2",
                  "biomaRt"), 
                repos = "http://bioconductor.org/biocLite.R")

#############################
# Data
#############################
GEOID <- "GSE123496"
## Sample paths
qt_fpath <- paste(getwd(), GEOID, "Data_Processed/FASTQ_qt", sep = "/")
qt_fpath <- paste(qt_fpath, dir(qt_fpath), sep = "/")
file_path <- file.path(qt_fpath, "quant.sf")
error_sample <- sapply(file_path, function(path) file.exists(path))
file_path <- file_path[error_sample]
SRR_id <- strsplit(x = basename(qt_fpath), "_")
SRR_id <- sapply(SRR_id, function (x) x[[1]])
names(file_path) <- SRR_id

## metadata
SRARunTable_path <- "sraruntable"
SRARunTable_path <- grep(pattern = SRARunTable_path, x = dir(GEOID), ignore.case = T)
SRARunTable_path <- dir(GEOID)[SRARunTable_path]
SRARunTable_path <- paste(getwd(), GEOID, SRARunTable_path, sep = "/")
SRR_Acc_List <- read.table(SRARunTable_path, sep = "\t", head = T, stringsAsFactors=FALSE)

#############################
# Metadata processing
#############################
metadata <- SRR_Acc_List[,c(1,13,23)]
metadata$experimental_groups <- make.names(metadata$disease_state)

### set test condition
metadata$condition1 <- factor(x = metadata$experimental_groups, levels = c("MS", "healthy.control"))

#############################
# Creating a transcript database
#############################
## 
library(GenomicFeatures)
txdb <- makeTxDbFromGFF(file = "/mnt/hd/Marco/Dropbox/Salmon/Human_GRCH38/homosapiens.gtf.gz")
k <- keys(txdb, keytype = "TXNAME")
tx_map <- biomaRt::select(txdb, keys = k, columns = "GENEID", keytype = "TXNAME")
tx2gene <- tx_map

ann_segmentation <- list()
ann_dim <- nrow(tx2gene)
start_int <- 1
count_int <- 1
while(ann_dim > 0) {
        seg_end <- start_int + 1000
        if(seg_end < nrow(tx2gene)) {
                ann_int <- seq(from = start_int, to = seg_end)
                ann_segmentation[[count_int]] <- ann_int
                start_int <- seg_end
                count_int <- count_int + 1
                ann_dim <- ann_dim - length(ann_int)
        } else {
                seg_end <- nrow(tx2gene)
                ann_int <- seq(from = start_int, to = seg_end)
                ann_segmentation[[count_int]] <- ann_int
                start_int <- seg_end
                count_int <- count_int + 1
                ann_dim <- ann_dim - length(ann_int)
        }
}
names(ann_segmentation) <- 1:length(ann_segmentation)
atable_segments <- list()
mart <- useMart(biomart = "ensembl", 
                dataset = "hsapiens_gene_ensembl", 
                host = "www.ensembl.org")
seg_int_ev <- NULL
while(length(atable_segments) < length(ann_segmentation)) {
        segments <- setdiff(names(ann_segmentation), names(atable_segments))
        for(seg_int in segments) {
                seg <- ann_segmentation[[seg_int]]
                seg_int_ev <- c(seg_int_ev, seg_int)
                tryCatch({
                        atable_segments[[seg_int]] <- biomaRt::getBM(attributes = c("ensembl_gene_id", 
                                                                                    "hgnc_symbol", 
                                                                                    "entrezgene_id", 
                                                                                    "description"), 
                                                                     filters = "ensembl_gene_id",
                                                                     values = tx2gene$GENEID[seg],
                                                                     mart = mart)
                }, error = function(e) {
                        seg_int_ev <- seg_int_ev[-which(seg_int_ev == seg_int)]
                })
                
        }
}
save(atable_segments, file = paste(getwd(), GEOID, "annotation_segments.RData", sep = "/"))
atable <- do.call("rbind", atable_segments)
names(atable) <- c("ENSEMBL", "SYMBOL", "ENTREZID", "DESCRIPTION")
atable <- merge(atable, tx2gene, by.x = "ENSEMBL", by.y = "GENEID")
atable <- unique(atable)
atable <- atable[,c(5,1:4)]

#############################
# Integrate quantification into R
#############################
## tximport
txi <- tximport(file_path, 
                type = "salmon", 
                tx2gene = tx_map, 
                varReduce = F, 
                txOut = F,
                ignoreTxVersion = T)
fname <- paste(getwd() , sep = "/")
save(list = c("txi"), file = paste(fname, GEOID, "txi.RData", sep = "/"))

##
samples <- metadata
row.names(samples) <- samples$Run
samples <- samples[colnames(txi$counts),]
ddsTxi <- DESeqDataSetFromTximport(txi,
                                   colData = samples,
                                   design = ~ condition1)
ddsTxi <- DESeq2::estimateSizeFactors(ddsTxi)
ddsTxi <- DESeq2::estimateDispersions(ddsTxi)
dds <- ddsTxi

#############################
# Save Tables
#############################
dds_counts <- counts(ddsTxi)
write.table(x = dds_counts, 
            file = paste(fname, GEOID, "processed_counts.txt", sep = "/"), 
            sep = "\t")

dds_metadata <- as.data.frame(colData(ddsTxi))
write.table(x = dds_metadata, 
            file = paste(fname, GEOID, "processed_metadata.txt", sep = "/"), 
            sep = "\t")

dds_annotation <- atable
write.table(x = dds_annotation, 
            file = paste(fname, GEOID, "processed_annotation.txt", sep = "/"), 
            sep = "\t")

#############################
# Exploratory Analysis and Visualization
#############################
## Pre-filtering the dataset
### count filter
count_filter <- row.names(tweeDEseq::filterCounts(counts(dds), mean.cpm.cutoff = 5))
dds <- dds[count_filter, ]

## Data Transformation
library(dplyr)
library(ggplot2)
library(vsn)
### regularized-logarithm transformation or rlog
rld <- rlog(dds, blind = FALSE)
### variance stabilizing transformation(VST)
vsd <- vst(dds, blind = FALSE)
df <- bind_rows(
        as_tibble(log2(counts(dds, normalized=TRUE)[, 1:2]+1)) %>%
                mutate(transformation = "log2(x + 1)"),
        as_tibble(assay(rld)[, 1:2]) %>% mutate(transformation = "rlog"),
        as_tibble(assay(vsd)[, 1:2]) %>% mutate(transformation = "vst")
)
colnames(df)[1:2] <- c("x", "y")
ggplot(df, aes(x = x, y = y)) + geom_hex() +
        coord_fixed() + facet_grid( . ~ transformation)
vsn::meanSdPlot(assay(rld), ranks = F)
vsn::meanSdPlot(assay(vsd), ranks = F)
### Sample distances
library("pheatmap")
library("RColorBrewer")
sampleDists <- dist(t(assay(rld)))
sampleDistMatrix <- as.matrix(sampleDists)
rownames(sampleDistMatrix) <- paste(rld$specimenID, sep = " - ")
colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette(rev(brewer.pal(9, "Blues")))(255)
pheatmap::pheatmap(sampleDistMatrix,
                   clustering_distance_rows = sampleDists,
                   clustering_distance_cols = sampleDists,
                   col = colors)
