#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("rJava", "RCurl", "reshape2", "RColorBrewer", "ggplot2", "xlsx"), repos = "http://lib.stat.cmu.edu/R/CRAN")
load_or_install(c("org.Hs.eg.db", "FGNet", "topGO", "biomaRt", "clusterProfiler"), repos = "http://bioconductor.org/biocLite.R")

#############################
# Custom Functions
#############################
custom.fea <- function(table, ontology = "BP") {
        genelist <- na.omit(table$human_EntrezGeneID)
        ## FEA
        ### KEGG
        fea_kegg <- enrichKEGG(gene = genelist)
        kegg_genes <- fea_kegg@result$geneID
        kegg_genes <- lapply(kegg_genes, strsplit, split = "/")
        kegg_genes <- lapply(kegg_genes, unlist)
        kegg_genes <- lapply(kegg_genes, function(gl) {
                unique(table[table$human_EntrezGeneID %in% gl, 3])
        })
        kegg_genes <- sapply(kegg_genes, paste, collapse = "/")
        fea_kegg@result <- cbind(fea_kegg@result, "geneSymbol" = kegg_genes)
        ## GO
        fea_go <- enrichGO(gene = genelist, OrgDb = "org.Hs.eg.db", ont = ontology, minGSSize = 50, readable = T)
        ## result
        res <- list("KEGG" = fea_kegg, "GO" = fea_go, "input_data" = table)
        return(res)
}

#############################
# Load Data
#############################
degList <- list()
degList[["Human_MS"]] <- read.delim(file = "GSE123496/1_MS-healthy.control_DEG.txt", stringsAsFactors = F)
degList[["Human_EOAD"]] <- read.delim(file = "HumanDatasets/MergedSet/AD_early-CONTROL_early_DEG.txt", stringsAsFactors = F)
degList[["Human_LOAD"]] <- read.delim(file = "HumanDatasets/MergedSet/AD_late-CONTROL_late_DEG.txt", stringsAsFactors = F)
degList[["MODEL-AD_hAbeta_KI_homozygous_22months-WT_22months"]] <- read.delim(file = "MODEL-AD_hAbeta_KI/homozygous_22months-WT_22months_DEG.txt", stringsAsFactors = F)
degList[["MODEL-AD_5XFAD"]] <- read.delim(file = "MODEL-AD_5XFAD/hemizygous-WT_DEG.txt", stringsAsFactors = F)
degList[["MODEL_APP.PS1"]] <- read.delim(file = "MODEL_APP.PS1/APPPS1-WT_DEG.txt", stringsAsFactors = F)

pval_cutoff <- 0.05
listSYMBOL <- lapply(X = degList, function(deg, pv) {
        symbol_col <- grepl(pattern = "hgnc", x = colnames(deg), ignore.case = T)
        if(!any(symbol_col)) {
                symbol_col <- grep(pattern = "symbol", x = colnames(deg), ignore.case = T)
        }
        sig_col <- grep(pattern = "value", x = colnames(deg), ignore.case = T)
        subset(deg[,symbol_col], subset = deg[,sig_col] < pv)
}, pv = pval_cutoff)
listSYMBOL <- lapply(listSYMBOL, na.omit)
listSYMBOL <- lapply(listSYMBOL, unique)

gquery <- listSYMBOL
#############################
# Expand Gene Annotation
#############################
## general Mart object
mart.args = list(
        "biomart" = "ENSEMBL_MART_ENSEMBL",
        "dataset" = "hsapiens_gene_ensembl",
        "host" = "www.ensembl.org"
)
mart <- biomaRt::useMart(biomart = mart.args$biomart, dataset = mart.args$dataset, host = mart.args$host)
#biomaRt::listDatasets(mart)
#biomaRt::columns(mart)
entrezList_full <- lapply(gquery, function(x) {
        res <- biomaRt::select(x = mart, keys = x, columns = c("hgnc_symbol", "entrezgene_id"), keytype = "hgnc_symbol")
        colnames(res) <- c("human_GeneSymbol", "human_EntrezGeneID")
        res <- data.frame(res, stringsAsFactors = F)
        return(res)
})

#############################
# FEA
#############################
customFEA <- lapply(entrezList_full, function(x, ont) {
        fea <- custom.fea(table = x, ontology = ont)
        res <- list("KEGG" = fea$KEGG@result,
                    "GO" = fea$GO@result,
                    "input_data" = fea$input_data
        )
        return(res)
}, ont = "ALL")

keggFEA <- lapply(names(customFEA), function(x, y) {
        dt <- y[[x]]$KEGG [,1:9]
        if(nrow(dt) > 0) {
                data.frame(dt, "study" = x, stringsAsFactors = F)
        } else {
                dt[1,] <- NA
                data.frame(dt, "study" = x, stringsAsFactors = F)
        }
}, y = customFEA)
names(keggFEA) <- names(customFEA)
keggFEA <- do.call("rbind", keggFEA)
keggFEA <- subset(x = keggFEA, subset = keggFEA$p.adjust < 0.05) ## pvalue filter

goFEA <- lapply(names(customFEA), function(x, y) {
        dt <- y[[x]]$GO
        if(nrow(dt) > 0) {
                data.frame(dt, "study" = x, stringsAsFactors = F)
        } else {
                dt[1,] <- NA
                data.frame(dt, "study" = x, stringsAsFactors = F)
        }
}, y = customFEA)
names(goFEA) <- names(customFEA)
goFEA <- do.call("rbind", goFEA)
goFEA <- subset(x = goFEA, subset = goFEA$p.adjust < 0.05) ## pvalue - filter

inputFEA <- lapply(names(customFEA), function(x, y) {
        y[[x]]$input_data
}, y = customFEA)
names(inputFEA) <- names(customFEA)

#############################
# Save Results
#############################
ndir <- paste(getwd(), "FEA", sep = "/")
if(!dir.exists(ndir)) {
        dir.create(ndir)
}
ndir <- paste(ndir, "MS", sep = "/")
if(!dir.exists(ndir)) {
        dir.create(ndir)
}

## KEGG
fname <- paste(ndir, "/FEA_KEGG.txt", sep = "")
write.table(x = keggFEA, file = fname, sep = "\t", row.names = F)
## GOBP
fname <- paste(ndir, "/FEA_GO.txt", sep = "")
write.table(x = goFEA, file = fname, sep = "\t", row.names = F)
## input_data
for(i in names(customFEA)) {
        fname <- paste(ndir, "/FEA_input_", i, ".txt", sep = "")
        write.table(x = inputFEA[[i]], file = fname, sep = "\t", row.names = F)
}
