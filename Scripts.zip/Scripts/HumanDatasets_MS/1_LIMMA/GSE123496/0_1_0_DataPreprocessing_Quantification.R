#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("tximport",
                  "DESeq2"), 
                repos = "http://bioconductor.org/biocLite.R")

#############################
# Transcript abundance quantification using Salmon
#############################
## Prep - FASTQ
GEOID <- "GSE123496"
### Create FASTQ_qt folder
ndir <- paste(getwd(), GEOID, "Data_Processed", sep = "/")
if(!dir.exists(ndir)) {
        dir.create(ndir)   
}
ndir <- paste(getwd(), GEOID, "Data_Processed", "FASTQ_qt", sep = "/")
if(!dir.exists(ndir)) {
        dir.create(ndir)   
}
SRARunTable_path <- "sraruntable"
SRARunTable_path <- grep(pattern = SRARunTable_path, x = dir(GEOID), ignore.case = T)
SRARunTable_path <- dir(GEOID)[SRARunTable_path]
SRARunTable_path <- paste(getwd(), GEOID, SRARunTable_path, sep = "/")
SRR_Acc_List <- read.table(SRARunTable_path, sep = "\t", head = T, stringsAsFactors=FALSE)

## Quantify samples
### - Linux Terminal - pipeline
path_processed <- paste(getwd(), GEOID, "Data_Processed", "FASTQ_qt", sep = "/")
path_unprocessed <- paste(getwd(), GEOID, "RAW_FASTQ", sep = "/")
path_index <- "/mnt/hd/Marco/Dropbox/Salmon/Human_GRCH38/homosapiens_index/"
query <- SRR_Acc_List$Run
liblayout <- unique(SRR_Acc_List$LibraryLayout)
for (q in seq(query)) {
        ndir <- paste (path_processed, "/", query[q], "_quant", sep = "")
        temp_filepath <- dir(path_unprocessed)
        temp_filepath <- temp_filepath[grep(pattern = ".fastq", x = temp_filepath, ignore.case = T)]
        temp_filepath <- temp_filepath[grep(pattern = query[q], x = temp_filepath, ignore.case = T)]
        temp_filepath <- paste(path_unprocessed, "/", temp_filepath, sep = "")
        comm_l01 <- "export PATH=$PATH:/mnt/hd/Marco/Dropbox/Salmon/salmon-latest_linux_x86_64/bin"
        if(grepl(pattern = "single", x = liblayout, ignore.case = T)) {
                comm_l02 <- paste(paste("salmon quant -i ", path_index, " -l A", sep = ""), 
                          paste("-r ", temp_filepath, sep = ""),
                          paste("-p 8 -o ", ndir, sep = ""),
                          "--numBootstraps 200",
                          "--gcBias",
                          "--validateMappings",
                          sep = " ")
        } else {
                comm_l02 <- paste(paste("salmon quant -i ", path_index, " -l A", sep = ""), 
                                  paste("-1 ", temp_filepath[1], sep = ""),
                                  paste("-2 ", temp_filepath[2], sep = ""),
                                  paste("-p 8 -o ", ndir, sep = ""),
                                  "--numBootstraps 200",
                                  "--gcBias",
                                  "--validateMappings",
                                  sep = " ")
        }
        comm <- paste(comm_l01, comm_l02, sep = ";")
        system(command = comm)
}

for (q in seq(query)) {
        temp_filepath <- dir(path_unprocessed)
        temp_filepath <- temp_filepath[grep(pattern = ".fastq", x = temp_filepath, ignore.case = T)]
        temp_filepath <- paste(path_unprocessed, temp_filepath, sep = "/")
        file.remove(temp_filepath)
}
