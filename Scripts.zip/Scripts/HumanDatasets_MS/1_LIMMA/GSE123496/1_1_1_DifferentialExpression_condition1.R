#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("tximport",
                   "DESeq2",
                   "org.Mm.eg.db"), 
                 repos = "http://bioconductor.org/biocLite.R")

#############################
# Data
#############################
GEOID <- "GSE123496"
fname <- paste(getwd(), GEOID, "txi.RData", sep = "/")
load(fname)
fname <- paste(getwd(), GEOID, "processed_metadata.txt", sep = "/")
samples <- read.delim2(fname, sep = "\t", stringsAsFactors=FALSE)
row.names(samples) <- samples$Run

#############################
# Construct dds object
#############################
ddsTxi <- DESeqDataSetFromTximport(txi,
                                   colData = samples,
                                   design = ~ condition1)
ddsTxi <- DESeq2::estimateSizeFactors(ddsTxi)
ddsTxi <- DESeq2::estimateDispersions(ddsTxi)
dds <- ddsTxi
## arrayQualityMetrics
fname <- paste(getwd(), GEOID, "QC_table.txt", sep = "/")
qc_table <- read.delim2(file = fname, header = T)
qc_outliers <- apply(qc_table[,c(3:5)], 2, function(col) grep("x", col))
qc_outliers <- Reduce("union", qc_outliers)
if(!is.null(qc_outliers)) {
        dds <- dds[,-qc_outliers]
}

#############################
# DESeq
#############################
## Pre-filtering the dataset
### count filter
count_filter <- row.names(tweeDEseq::filterCounts(counts(dds), mean.cpm.cutoff = 2))
dds <- dds[count_filter, ]
## DE
dds <- DESeq(dds)

## comparisons
cpairs <- t(combn(x = unique(samples$condition1), m = 2))
resList <- list()
for(comp in seq(nrow(cpairs))) {
        p <- cpairs[comp,]
        order_ev1 <- grepl(pattern = "MS", x = p, ignore.case = T)
        order_ev2 <- grepl(pattern = "healthy", x = p, ignore.case = T)
        if(all(order_ev1)) {
                contrast_obj <- c("condition1", p[which(order_ev2)], p[which(!order_ev2)])
        } else {
                contrast_obj <- c("condition1", p[which(order_ev1)], p[which(!order_ev1)])
        }
        contrast_name <- paste(contrast_obj[2], contrast_obj[3], sep = "-")
        res <- results(dds, contrast = contrast_obj)
        resList[[contrast_name]] <- lfcShrink(dds, 
                                              contrast = contrast_obj, 
                                              res = res, 
                                              type = "ashr",
                                              svalue = F)
        rm(comp, p, contrast_obj, contrast_name, res)
}
# DESeq2::plotMA(resList[[1]], ylim = c(-1, 1), alpha = 0.05)

#############################
# Annotating and exporting results
#############################
processed_annotation <- read.delim(paste(getwd(), GEOID, "processed_annotation.txt", sep = "/"), stringsAsFactors=FALSE)
featlist <- unique(processed_annotation[,!grepl(pattern = "txname", x = names(processed_annotation), ignore.case = T)])
featlist <- subset(x = featlist, subset = !featlist$SYMBOL %in% "")
featlist <- split (x = featlist, f = featlist$SYMBOL)
featlist <- lapply (X = featlist, FUN = function (df) {
        if (length (df[,3]) > 1) {
                x1 <- unique (df[,-3])
                x2 <- paste(unique(df[,3]), collapse = "/")
                x <- cbind (x1, x2)
                x <- sapply (x, as.character)
                names(x) <- colnames(df)
                return(x)
        }
        x <- unlist(df)
        return(x)
})
featlist <- do.call("rbind", featlist)
row.names(featlist) <- featlist[,"ENSEMBL"]
ann_dup <- duplicated(featlist[,"ENSEMBL"])
ann_dup <- featlist[,"ENSEMBL"][!ann_dup]
featlist <- featlist[ann_dup,]
featlist <- data.frame(featlist, row.names = featlist[,"ENSEMBL"], stringsAsFactors = F)

#############################
# Exporting results
#############################
resListAnn <- lapply(resList, function(res, fdat) {
        res <- res[intersect(row.names(res), row.names(fdat)),]
        tT <- data.frame(res, stringsAsFactors = F)
        tT <- data.frame("ENSEMBL" = row.names(tT), tT, stringsAsFactors = F)
        tT <- merge(tT, fdat)
        tT <- tT[order(tT$pvalue),]
        tT <- na.omit(tT)
        return(tT)
}, fdat = featlist)

## result outputs
for(comp in seq(resListAnn)) {
        contrast_name <- names(resListAnn)[[comp]]
        fname <- paste(getwd(), "/", GEOID, "/", comp, "_", contrast_name, "_DEG.txt", sep = "")
        write.table(resListAnn[[comp]], file = fname, sep = "\t", row.names = F)
}
