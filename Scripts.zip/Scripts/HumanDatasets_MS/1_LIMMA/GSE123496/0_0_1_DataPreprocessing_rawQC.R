#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("ShortRead", "fastqcr", "QuasR", "dada2", "ggplot2"), 
                repos = "http://bioconductor.org/biocLite.R")

#############################
# GEOquery
#############################
## load series and platform data from GEO
GEOID <- "GSE123496"
source('/mnt/hd/Marco/Dropbox/Arthur_Neumann/Scripts/rnaseqQCtable.R', echo=TRUE)

fastq_raw <- paste(getwd(), GEOID, sep = "/")
fastq_raw <- paste(fastq_raw, dir(fastq_raw)[grep(pattern = "raw*.*fastq", x = dir(GEOID), ignore.case = T)], sep = "/")

#############################
# Rename
#############################
# fastq_fpath <- dir(fastq_raw)
# fastq_fpath <- paste(fastq_raw, fastq_fpath, sep = "/")
# is_fastq <- grepl(pattern = ".fastq", x = basename(fastq_fpath), ignore.case = T)
# to_rename <- fastq_fpath[is_fastq]
# new_name <- gsub(pattern = ".fastq", replacement = "_R1.fastq", x = basename(to_rename), ignore.case = T)
# new_name <- paste(fastq_raw, new_name, sep = "/")
# file.rename(from = to_rename, to = new_name)

#############################
#
#############################
fastq_raw <- paste(getwd(), GEOID, sep = "/")
fastq_raw <- paste(fastq_raw, dir(fastq_raw)[grep(pattern = "raw*.*fastq", x = dir(GEOID), ignore.case = T)], sep = "/")
R1_files <- dir(fastq_raw)
R1_files <- R1_files[grep(pattern = ".fastq", x = R1_files, ignore.case = T)]
R1_files <- paste(fastq_raw, R1_files, sep = "/")
names(R1_files) <- sapply(basename(R1_files), "[[", 1)

R_files <- c(R1_files)

#############################
# fastq QC - RAW (fastqcr)
#############################
# fastq_qcdir <- paste(getwd(), GEOID, "fastqQCRAW_results", sep = "/")
# fastqc(fq.dir = fastq_raw, qc.dir = fastq_qcdir, threads = 4)

#############################
# Inspect read quality profiles
#############################
### In gray-scale is a heat map of the frequency of each quality score at each base position. 
### The median quality score at each position is shown by the green line, and the quartiles of 
### the quality score distribution by the orange lines. The red line shows the scaled proportion of 
### reads that extend to at least that position (this is more useful for other sequencing technologies, 
### as Illumina reads are typically all the same lenghth, hence the flat red line).

## Plot 1
fnF_plots <- list()
fnR_plots <- list()
for(f in seq(R_files)) {
     fnF_plots[[names(R_files)[f]]] <- plotQualityProfile(R_files[f])
}
# for(f in seq(R2_files)) {
#      fnR_plots[[names(R2_files)[f]]] <- plotQualityProfile(R2_files[f])
# }
## Plot 2
QC_res_R <- rnaseqQCtables(fastq_filepth = R_files)
fnF_vplot <- ggplot(data = QC_res_R, mapping = aes(x = file, y = Mean)) + 
     geom_violin() + 
     # geom_dotplot(binaxis = "y", 
     #                           stackdir = "center", 
     #                           position = position_dodge(), 
     #                           dotsize = 0.5) +
     theme_classic() +
     theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1),
           plot.margin = margin(10,10,10,50))
# QC_res_R2 <- rnaseqQCtables(fastq_filepth = R2_files)
# fnR_vplot <- ggplot(data = QC_res_R2, mapping = aes(x = file, y = Mean)) + 
#      geom_violin() + geom_dotplot(binaxis = "y", 
#                                   stackdir = "center", 
#                                   position = position_dodge(), 
#                                   dotsize = 0.5) +
#      theme_classic() +
#      theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1))

#############################
# Save
#############################
ndir <- paste(getwd(),GEOID, "QCRAW", sep = "/")
if(!dir.exists(ndir)) {
     dir.create(ndir)
}
## R
fnames <- paste(ndir, "QualityPlot.pdf", sep = "/")
pdf(file = fnames, width = 10, height = 8)
for(p in fnF_plots) {
     plot(p)
}
dev.off()
fnames <- paste(ndir, "ViolinPlot.pdf", sep = "/")
ggsave(filename = fnames, plot = fnF_vplot, width = 10, height = 8)
fnames <- paste(ndir, "QCresultTable.txt", sep = "/")
write.table(x = QC_res_R, file = fnames, sep = "\t", row.names = F)
