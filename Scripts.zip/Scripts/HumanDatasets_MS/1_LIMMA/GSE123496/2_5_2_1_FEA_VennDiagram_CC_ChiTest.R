#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("reshape2", "VennDiagram", "gplots", "gridExtra"), repos = "http://lib.stat.cmu.edu/R/CRAN")

#############################
# Load Data
#############################
FEA_GO <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/FEA/MS/FEA_GO.txt", 
                       stringsAsFactors=FALSE)
feaList <- split(x = FEA_GO, f = FEA_GO$study)
feaList <- feaList[c("MODEL-AD_5XFAD", "Human_EOAD", "Human_LOAD", "Human_MS")]
feaList <- lapply(feaList, function(x) subset(x = x, subset = x$ONTOLOGY == "CC"))

#############################
# Venn Diagram
#############################
listSYMBOL <- lapply(feaList, function(x) x$ID)
listSYMBOL <- lapply(listSYMBOL, unique)
a1 <- length(x = listSYMBOL[[1]])
a2 <- length(x = listSYMBOL[[2]])
a3 <- length(x = listSYMBOL[[3]])
a4 <- length(x = listSYMBOL[[4]])
n12 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[2]]))
n13 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[3]]))
n14 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[4]]))
n23 <- length(intersect(listSYMBOL[[2]], listSYMBOL[[3]]))
n24 <- length(intersect(listSYMBOL[[2]], listSYMBOL[[4]]))
n34 <- length(intersect(listSYMBOL[[3]], listSYMBOL[[4]]))
n123 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]])) == 3)
n124 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[4]])) == 3)
n134 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[3]], listSYMBOL[[4]])) == 3)
n234 <- sum(table(c(listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[4]])) == 3)
n1234 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[4]])) == 4)

#############################
# Chi Test
#############################
chisq.post.hoc <- function(tbl,
                           test = c("fisher.test", "chisq.test"),
                           popsInRows = TRUE,
                           method = c("fdr","BH","BY","bonferroni","holm","hochberg","hommel"),
                           digits = 4, ...) {
     #### extract correction method
     method <- match.arg(method)
     
     #### extract which test (fisher or chi square) 
     test = match.fun(test)
     
     #### test rows or columns
     if (!popsInRows) tbl <- t(tbl)
     popsNames <- rownames(tbl)
     
     #### come up with all possible comparisons
     prs <- combn(1:nrow(tbl),2)
     
     #### preallocate  
     tests <- ncol(prs)
     pvals <- numeric(tests)
     lbls <- character(tests)
     for (i in 1:tests) {
          pvals[i] <- test(tbl[prs[,i],], ...)$p.value
          lbls[i] <- paste(popsNames[prs[,i]],collapse=" vs. ")
     }
     adj.pvals <- p.adjust(pvals,method=method)
     cat("Adjusted p-values used the",method,"method.\n\n")
     data.frame(comparison=lbls,raw.p=round(pvals,digits),adj.p=round(adj.pvals,digits))
}

ki_countTest <- matrix(nrow = 3, ncol = 2, 
                       dimnames = list("row" = c(names(listSYMBOL)[2],
                                                 names(listSYMBOL)[3],
                                                 names(listSYMBOL)[4]), 
                                       "column" = c("Overlap", "NotOverlap")))
ki_countTest[names(listSYMBOL)[2], "Overlap"] <- n12
ki_countTest[names(listSYMBOL)[2], "NotOverlap"] <- a1 - n12
ki_countTest[names(listSYMBOL)[3], "Overlap"] <- n13
ki_countTest[names(listSYMBOL)[3], "NotOverlap"] <- a1 - n13
ki_countTest[names(listSYMBOL)[4], "Overlap"] <- n14
ki_countTest[names(listSYMBOL)[4], "NotOverlap"] <- a1 - n14
ki_countTestres <- chisq.test(ki_countTest, correct = T)
chisq_post <- chisq.post.hoc(ki_countTest, test = "chisq.test", method = "bonferroni")

#############################
# Mosaic Plots
#############################
ndir <- paste (getwd(), "FEA", sep = "/")
if (!dir.exists(ndir)) {
     dir.create(ndir)   
}
ndir <- paste (ndir, "MS", sep = "/")
if (!dir.exists(ndir)) {
     dir.create(ndir)   
}
ndir <- paste (ndir, "CC", sep = "/")
if (!dir.exists(ndir)) {
     dir.create(ndir)   
}

fname <- paste(ndir, "/2_1_0_MosaicPlots_ChiSquare_FEA_", names(listSYMBOL)[1], ".pdf", sep = "")
pdf(file = fname, width = 12, height = 12)
mosaicplot(ki_countTest, 
           col = c("firebrick", "goldenrod1"), 
           cex.axis = 1, 
           xlab = "Model-Disease Overlap", 
           ylab = names(listSYMBOL)[1], 
           main = ki_countTestres$method,
           sub = paste(names(ki_countTestres$statistic), " = ", round(ki_countTestres$statistic, 2), "; ",
                       "p-value = ", round(ki_countTestres$p.value, 2),
                       sep = ""))
plot.new()
gridExtra::grid.table(chisq_post)
plot.new()
gridExtra::grid.table(ki_countTest)
dev.off()
