#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("reshape2", "VennDiagram", "gplots", "gridExtra"), repos = "http://lib.stat.cmu.edu/R/CRAN")

#############################
# Load Data
#############################
MRA_Vargas2018 <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/MRA_Vargas2018.txt", stringsAsFactors=FALSE)
iRegs <- MRA_Vargas2018$Regulon

#############################
# Extract results from TNA
#############################
regExp <- paste("TNA.*", ".RData$", sep = "")
## REGULONS MODELS
models <- c("MODEL-AD_5XFAD", "MODEL-AD_hAbeta_KI", "MODEL_APP.PS1")
results <- list()
for(i in seq(models)) {
        model <- models[i]
        filename <- grep(pattern = regExp, dir(model), ignore.case = T)
        if(length(filename) == 1) {
                filepath <- paste(model, "/", dir(model)[filename], sep = "")
                load(filepath)
                results [[length(results) + 1]] <- tna@results$MRA.results
                names(results)[length(results)] <- make.names(model)
                rm(tna, filename, filepath)
        } else {
                for (f in filename) {
                        filepath <- paste(model, "/", dir(model)[f], sep = "")
                        load(filepath)
                        results [[length(results) + 1]] <- tna@results$MRA.results
                        m <- sub(pattern = "TNA_", replacement = "", x = basename(filepath))
                        m <- sub(pattern = ".RData", replacement = "", x = m)
                        m <- paste(model, m, sep = ".")
                        names(results)[length(results)] <- make.names(m)
                        rm(tna, f, filepath, m)
                }
        }
        rm(i)
}
models <- c("HumanDatasets/GSE39420/", "HumanDatasets/MergedSet/")
for(i in seq(models)) {
        model <- models[i]
        filename <- grep(pattern = regExp, dir(model), ignore.case = T)
        if(length(filename) == 1) {
                filepath <- paste(model, "/", dir(model)[filename], sep = "")
                load(filepath)
                results [[length(results) + 1]] <- tna@results$MRA.results
                names(results)[length(results)] <- make.names(model)
                rm(tna, filename, filepath)
        } else {
                for (f in filename) {
                        filepath <- paste(model, "/", dir(model)[f], sep = "")
                        load(filepath)
                        results [[length(results) + 1]] <- tna@results$MRA.results
                        m <- sub(pattern = "TNA_", replacement = "", x = basename(filepath))
                        m <- sub(pattern = ".RData", replacement = "", x = m)
                        m <- paste(model, m, sep = ".")
                        names(results)[length(results)] <- make.names(m)
                        rm(tna, f, filepath, m)
                }
        }
        rm(i)
}

threshold_cutoff <- 0.05
results_sig <- lapply(results, function(x, iRegs, threshold_cutoff) {
        # x <- x[iRegs,]
        x <- subset (x, subset = x$Adjusted.Pvalue < threshold_cutoff)
        return(x)
}, iRegs = iRegs, threshold_cutoff = threshold_cutoff)
# results_sig <- results_sig[-c(3,4,5)]

#############################
# Venn Diagram
#############################
listSYMBOL <- lapply(X = results_sig, function(x) {
        x$Regulon
})
listSYMBOL <- lapply(listSYMBOL, unique)
i <- table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[4]], listSYMBOL[[5]]))
i <- names(i)[i >= 4]
listSYMBOL <- list("intersection" = i,
                   "Vargas2018" = MRA_Vargas2018$Regulon)

a1 <- length(x = listSYMBOL[[1]])
a2 <- length(x = listSYMBOL[[2]])
n12 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[2]]))
vennPlot <- draw.pairwise.venn(area1 = a1, 
                             area2 = a2,
                             cross.area = n12,
                             scaled = F,
                             category = c(names(listSYMBOL)[1], 
                                          names(listSYMBOL)[2]), 
                             lty = 1,
                             fill = c("pink1", "skyblue"),
                             cat.cex = c (2, 2),
                             cat.pos = c(0, 0),
                             cat.dist = c(0.02, 0.02),
                             cat.just = list(c(0.9, 1), 
                                             c(0.4, 1)),
                             int = F)

#############################
# Save Plots
#############################
fname <- "2_4_1_1_VennDiagram_MRA_Vargas2018.pdf"
pdf (file = fname, width = 30, height = 15)
grid.arrange(gTree(children = vennPlot))
dev.off()
