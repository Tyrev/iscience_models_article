#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("GOSemSim", "ggplot2", "RedeR", "igraph"), 
                repos = "http://bioconductor.org/biocLite.R")

#############################
# Custom Function
#############################
## Function returns the Jaccard index and Jaccard distance
### Parameters:
#### 1. df, dataframe of interest
#### 2. margin, axis in which the apply function is meant to move along
jaccard <- function(df, margin=1) {
        if(margin == 1 | margin == 2) {
                M_00 <- apply(df, margin, sum) == 0
                M_11 <- apply(df, margin, sum) == 2
                if(margin == 1) {
                        df <- df[!M_00, ]
                        JSim <- sum(M_11) / nrow(df)
                } else {
                        df <- df[, !M_00]
                        JSim <- sum(M_11) / length(df)
                }
                JDist <- 1 - JSim
                return(c(JSim = JSim, JDist = JDist))
        } else break
}
findEdges <- function(chord_data, circ_data, jaccardThreshold = 0.25, ncores = 4) {
        logicalMatrix <- chord_data[,-ncol(chord_data)]
        processList_ID <- split(x = circ_data$ID, f = circ_data$term)
        processList_ID <- sapply(processList_ID, unique)
        if(!all(grepl(pattern = "GO:", x = colnames(logicalMatrix)))) {
                colnames(logicalMatrix) <- processList_ID[colnames(logicalMatrix)]
        }
        
        pairs <- combn(x = colnames(logicalMatrix), m = 2)
        pairs <- t(pairs)
        colnames(pairs) <- c("from", "to")
        pairList <- lapply(1:nrow(pairs), function(i, p) {p[i,]}, p = pairs)
        sharedGenes <- mclapply(pairList, function(pair, lmtx) {
                sharedLogical <- apply(lmtx[,pair], 1, sum) == 2
                sharedGenes <- sum(sharedLogical)
                return(sharedGenes)
        }, lmtx = logicalMatrix, mc.cores = ncores)
        sharedGenes <- unlist(sharedGenes)
        jaccardCoef <- mclapply(pairList, function(pair, lmtx) {
                jaccardCoef <- jaccard(df = lmtx[,pair], margin = 1)
                return(jaccardCoef)
        }, lmtx = logicalMatrix, mc.cores = ncores)
        jaccardCoef <- do.call("rbind", jaccardCoef)
        eData <- data.frame(pairs, 
                            "nsharedGenes" = sharedGenes, 
                            jaccardCoef, 
                            stringsAsFactors = F)
        eData <- eData[eData$JSim > jaccardThreshold,]
        return(eData)
}

#############################
# Load Data
#############################
intersection_data <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/GOSemSim/GOBP_UNION/2_0_unionLOADvsModels_IntersecTable.txt", 
                                stringsAsFactors=FALSE)
row.names(intersection_data) <- intersection_data$ID
cluster_data <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/GOSemSim/GOBP_UNION/2_1_unionLOADvsModels_ClustersTable.txt", 
                           stringsAsFactors=FALSE)
row.names(cluster_data) <- cluster_data$labels
cluster_colors <- split(cluster_data$color, f = cluster_data$clusters)
cluster_colors <- sapply(cluster_colors, unique)

#############################
# Process
#############################
## Chord
geneIDs <- cluster_data$geneID
names(geneIDs) <- cluster_data$labels
geneID_lists <- strsplit(x = geneIDs, split = "/")
goSize <- sapply(geneID_lists, length)
chord <- matrix(data = 0, nrow = length(unique(unlist(geneID_lists))), ncol = length(geneID_lists),
                dimnames = list("row" = unique(unlist(geneID_lists)),
                                "col" = names(geneID_lists)))
for(go in colnames(chord)) {
        chord[geneID_lists[[go]],go] <- 1
        rm(go)
}
chord <- cbind(chord, "dummy" = NA)

## CircData
circ <- data.frame("ID" = cluster_data$labels, "term" = cluster_data$clusters)

## EdgeData
# edgeData <- findEdges(chord_data = chord, circ_data = circ, jaccardThreshold = 0.7)
edgeData <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/Networks/GOSemSim_UNION/2_0_unionLOADvsModels_edgeData.txt")

## partial saves
# ndir <- paste(getwd(), "Networks", sep = "/")
# if(!dir.exists(ndir)) {
#         dir.create(ndir)
# }
# ndir <- paste(ndir, "GOSemSim_UNION", sep = "/")
# if(!dir.exists(ndir)) {
#         dir.create(ndir)
# }
# fname <- paste(ndir, "/2_0_unionLOADvsModels_edgeData.txt", sep = "")
# write.table(x = edgeData, file = fname, sep = "\t", row.names = F)

#############################
# Graph
#############################
graph <- graph_from_data_frame(edgeData, directed = F)
graphMap <- as_data_frame(graph, what = "both")
VgraphMap <- graphMap$vertices
EgraphMap <- graphMap$edges

## Map graph
intersect_subset <- intersection_data[VgraphMap$name,-1]
color_comb <- list()
for(r in row.names(intersect_subset)) {
        color_comb[[r]] <- colnames(intersect_subset)[unlist(intersect_subset[r,])]
}
color_comb <- lapply(color_comb, paste, collapse = "|")
color_comb <- unlist(color_comb)
VgraphMap[names(color_comb),"intersections"] <- color_comb
color_unique <- unique(color_comb)
color_unique <- RColorBrewer::brewer.pal(n = length(levels(as.factor(color_unique))), name = "Dark2")
names(color_unique) <- unique(color_comb)
VgraphMap[names(color_comb),"nodeColor"] <- color_unique[color_comb]
VgraphMap[,"GOsize"] <- goSize[VgraphMap$name]
VgraphMap$nodeFontSize <- 25

graph <- att.mapv(g = graph, dat = VgraphMap)
graph <- att.mape(g = graph, dat = EgraphMap)
### nodeSize to GOsize
graph <- att.setv(g = graph, from = "GOsize", to = "nodeSize", nquant = 5, getleg = T)

## Containers
container_data <- cluster_data[VgraphMap$name,-4]
container_data$GOsize <- VgraphMap$GOsize
container_data$clusters <- paste("cluser", container_data$clusters, sep = "")
container_nodes <- split(x = container_data$labels, f = container_data$clusters)
container_size <- split(x = container_data$GOsize, f = container_data$clusters)
container_size <- sapply(container_size, sum)
container_colors <- split(x = container_data$color, f = container_data$clusters)
container_colors <- sapply(container_colors, unique)
container_template <- list(nestAlias = NULL,
                           nestFontX = 0,
                           nestFontY = -11,
                           nestFontSize = 50,
                           nestSize = NULL,
                           nestColor = "white",
                           nestFontColor = NULL,
                           nestLineWidth = 7,
                           nestLineColor = NULL,
                           nestLineType = "SOLID",
                           nestShape = "ROUNDED_RECTANGLE"
)
container_att <- lapply(names(container_colors), function(cl_id, cl_col, cl_size, template) {
        template$nestAlias <- cl_id
        template$nestSize <- sqrt(cl_size[cl_id])*20
        template$nestFontColor <- cl_col[cl_id]
        template$nestLineColor <- cl_col[cl_id]
        return(template)
}, cl_col = container_colors, cl_size = container_size, template = container_template)
names(container_att) <- names(container_colors)

## RedeR
rdp <- RedPort()
calld(rdp)
addGraph(obj = rdp, g = graph, zoom = 60)
for(i in seq(container_nodes)) {
        nestNodes(obj = rdp, nodes = container_nodes[[i]], gscale = 60, gatt = container_att[[i]])
        mergeOutEdges(rdp, nlev = i)
        relax(rdp)
}

### Legend
gAttr <- graph.attributes(graph)
addLegend.size(obj = rdp, 
               type = "node",
               sizevec = gAttr$legNodeSize$scale,
               labvec = gAttr$legNodeSize$legend,
               title = "GO Size", 
               vertical = T,
               position = "bottomleft",
               ftsize = 20,
               intersp = 50)
addLegend.color(obj = rdp, 
               type = "node",
               colvec = color_unique,
               labvec = names(color_unique),
               title = "Intersections", 
               vertical = T,
               position = "topleft",
               ftsize = 20, dyborder = -5)
