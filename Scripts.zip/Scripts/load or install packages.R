#############################
#Package Install/Load
#############################
load_or_install <- function(package_names, repos = "http://lib.stat.cmu.edu/R/CRAN"){
        if (!is.character (repos) & length(repos) == 1) {stop ("Invalid repos argument.")}
        is.installed <- function(mypkg) {is.element(mypkg, installed.packages()[,1])} 
        
        for(package_name in package_names){
                if(!is.installed(package_name)){
                        if (grepl("bioconductor", repos, ignore.case = T)){
                                if (!requireNamespace("BiocManager", quietly = TRUE)) {install.packages("BiocManager")}
				BiocManager::install(package_names)
                        }
                        else {install.packages(pkgs = package_name, repos = repos)}
                }
                library(package_name,character.only=TRUE,quietly=TRUE,verbose=FALSE)
        }
}
