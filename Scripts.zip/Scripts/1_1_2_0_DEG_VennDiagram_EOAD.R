#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("reshape2", "VennDiagram", "gplots", "gridExtra"), repos = "http://lib.stat.cmu.edu/R/CRAN")

#############################
# Load Data
#############################
degList <- list()
degList[["MODEL-AD_5XFAD"]] <- read.delim(file = "MODEL-AD_5XFAD/hemizygous-WT_DEG.txt", stringsAsFactors = F)
degList[["MODEL-AD_hAbeta_KI_homozygous_22months-WT_22months"]] <- read.delim(file = "MODEL-AD_hAbeta_KI/homozygous_22months-WT_22months_DEG.txt", stringsAsFactors = F)
degList[["MODEL_APP.PS1"]] <- read.delim(file = "MODEL_APP.PS1/APPPS1-WT_DEG.txt", stringsAsFactors = F)
degList[["Human_EOAD"]] <- read.delim(file = "HumanDatasets/MergedSet/AD_early-CONTROL_early_DEG.txt", stringsAsFactors = F)

#############################
# Venn Diagram
#############################
threshold_cutoff <- 0.05
listSYMBOL <- lapply(X = degList, function(deg, threshold_cutoff) {
        symbol_col <- grepl(pattern = "hgnc", x = colnames(deg), ignore.case = T)
        if(!any(symbol_col)) {
                symbol_col <- grep(pattern = "symbol", x = colnames(deg), ignore.case = T)
        }
        sig_col <- grep(pattern = "value", x = colnames(deg), ignore.case = T)
        subset(deg[,symbol_col], subset = deg[,sig_col] < threshold_cutoff)
}, threshold_cutoff = threshold_cutoff)
listSYMBOL <- lapply(listSYMBOL, na.omit)
listSYMBOL <- lapply(listSYMBOL, unique)
a1 <- length(x = listSYMBOL[[1]])
a2 <- length(x = listSYMBOL[[2]])
a3 <- length(x = listSYMBOL[[3]])
a4 <- length(x = listSYMBOL[[4]])
n12 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[2]]))
n13 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[3]]))
n14 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[4]]))
n23 <- length(intersect(listSYMBOL[[2]], listSYMBOL[[3]]))
n24 <- length(intersect(listSYMBOL[[2]], listSYMBOL[[4]]))
n34 <- length(intersect(listSYMBOL[[3]], listSYMBOL[[4]]))
n123 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]])) == 3)
n124 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[4]])) == 3)
n134 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[3]], listSYMBOL[[4]])) == 3)
n234 <- sum(table(c(listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[4]])) == 3)
n1234 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[4]])) == 4)
# vennPlot <- draw.triple.venn(area1 = a1, 
#                              area2 = a2,
#                              area3 = a3,
#                              n12 = n12,
#                              n23 = n23,
#                              n13 = n13,
#                              n123 = n123,
#                              scaled = F,
#                              category = c(names(listSYMBOL)[1], 
#                                           names(listSYMBOL)[2], 
#                                           names(listSYMBOL)[3]), 
#                              lty = 1,
#                              fill = c("pink1", "skyblue", "orange"),
#                              cat.cex = c (2, 2, 2),
#                              cat.pos = c(0, 0, 180),
#                              cat.dist = c(0.02, 0.02, 0.02),
#                              cat.just = list(c(0.9, 1), 
#                                              c(0.4, 1), 
#                                              c(0.5, 0)),
#                              int = F)
vennPlot <- draw.quad.venn(area1 = a1,
                           area2 = a2,
                           area3 = a3,
                           area4 = a4,
                           n12 = n12,
                           n13 = n13,
                           n14 = n14,
                           n23 = n23,
                           n24 = n24,
                           n34 = n34,
                           n123 = n123,
                           n124 = n124,
                           n134 = n134,
                           n234 = n234,
                           n1234 = n1234,
                           scaled = F,
                           category = c(names(listSYMBOL)[1],
                                        names(listSYMBOL)[2],
                                        names(listSYMBOL)[3],
                                        names(listSYMBOL)[4]),
                           lty = 1,
                           cex = rep(3, 15),
                           fill = c("pink1", "skyblue", "orange", "lightblue"),
                           cat.cex = c (2, 2, 2, 2),
                           cat.pos = c(0, 0, 0, 0),
                           cat.dist = c(0.2, 0.2, 0.1, 0.1),
                           cat.just = c(list(c(0.85, 0.5)),
                                        list(c(0.55, 0.5)),
                                        rep(list(c(0.5, 0.5)), 2)),
                           int = F)

#############################
# Save Plots
#############################
fname <- "1_1_1_1_VennDiagram_DEG_EOAD.pdf"
pdf (file = fname, width = 30, height = 15)
grid.arrange(gTree(children = vennPlot), 
             bottom = textGrob(paste("DEG = pvalue < ", threshold_cutoff, sep = ""),
                               gp = gpar(fontsize =25, font = 8)))
dev.off()
