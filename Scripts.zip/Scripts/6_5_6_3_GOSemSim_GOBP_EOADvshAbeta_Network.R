#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("GOSemSim", "ggplot2", "RedeR", "igraph"), 
                repos = "http://bioconductor.org/biocLite.R")

#############################
# Load Data
#############################
cluster_data <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/GOSemSim/GOBP/8_intersection_Human_EOAD|MODEL-AD_hAbeta_KI_homozygous_22months-WT_22months_ClustersTable.txt", 
                           stringsAsFactors=FALSE)
cluster_colors <- split(cluster_data$color, f = cluster_data$clusters)
cluster_colors <- sapply(cluster_colors, unique)

#############################
# GOSemSim - Clusters
#############################
hsGO <- godata("org.Hs.eg.db", ont = "BP", computeIC = FALSE)
term_clusters <- split(cluster_data$labels, f = cluster_data$clusters)
cl_mtx <- matrix(data = NA, nrow = length(term_clusters), ncol = length(term_clusters),
                 dimnames = list("row" = names(term_clusters),
                                 "col" = names(term_clusters)))
for(r in row.names(cl_mtx)) {
     for(c in colnames(cl_mtx)) {
          cl_mtx[r,c] <- mgoSim(term_clusters[[r]], 
                                term_clusters[[c]], 
                                semData = hsGO, measure = "Wang", combine = "BMA")
     }
}
cl_mtx_melted <- reshape2::melt(cl_mtx)
row.names(cl_mtx_melted) <- apply(cl_mtx_melted[,1:2], 1, paste, collapse = "_")

sim_ecdf <- ecdf(c(cl_mtx)[!c(cl_mtx) == 1])
sim_ecdf_threshold <- quantile(x = sim_ecdf, prob = 0.8)
cl_mtxLogic <- cl_mtx > sim_ecdf_threshold & cl_mtx != 1
cl_mtxLogic <- matrix(as.numeric(cl_mtxLogic), nrow = nrow(cl_mtxLogic),
                      dimnames = list("row" = row.names(cl_mtx),
                                      "col" = colnames(cl_mtx)
                      )
)

#############################
# Graph
#############################
graph <- graph_from_adjacency_matrix(cl_mtxLogic, mode = "undirected", diag = F)
graphMap <- as_data_frame(graph, what = "both")
VgraphMap <- graphMap$vertices
EgraphMap <- graphMap$edges

## Map graph
EgraphMap$pairid <- apply(EgraphMap[,1:2], 1, paste, collapse = "_")
EgraphMap$SimilarityScore <- cl_mtx_melted[EgraphMap$pairid,"value"]
VgraphMap$ClusterSize <- sapply(term_clusters, length)[VgraphMap$name]
VgraphMap$degree <- degree(graph)[VgraphMap$name]
VgraphMap$nodeColor <- cluster_colors[VgraphMap$name]
graph <- att.mapv(g = graph, dat = VgraphMap)
graph <- att.mape(g = graph, dat = EgraphMap)
### nodeSize to ClusterSize
graph <- att.setv(g = graph, from = "ClusterSize", to = "nodeSize", nquant = 5, getleg = T)
### nodeColor to degree
## colorRampPalette from ggplot2 -> usage exp.: colorRampPalette(c("blue", "white", "red")) -> colfunc ; plot(rep(1,300), col = colfunc(300), pch = 19, cex = 3)
# palfunc <- colorRampPalette(c("white", "red"))
# graph <- att.setv(g = graph, from = "degree", to = "nodeColor", nquant = 8, cols = palfunc(8), getleg = T)
### edgeWidth to SimilarityScore
graph <- att.sete(g = graph, from = "SimilarityScore", to = "edgeWidth", nquant = 5, 
                  xlim = c(1,8,0.5), roundleg = 2)

## RedeR
rdp <- RedPort()
calld(rdp)
addGraph(obj = rdp, g = graph, zoom = 60)

### Legend
gAttr <- graph.attributes(graph)
addLegend.size(obj = rdp, 
               type = "node",
               sizevec = gAttr$legNodeSize$scale,
               labvec = round(as.numeric(gAttr$legNodeSize$legend),0),
               title = "ClusterSize", 
               vertical = T,
               position = "bottomleft",
               ftsize = 20,
               intersp = 50)
addLegend.size(obj = rdp, 
               type = "edge",
               sizevec = gAttr$legEdgeWidth$scale,
               labvec = gAttr$legEdgeWidth$legend,
               title = "Similarity Score", 
               vertical = F,
               position = "topright",
               ftsize = 20, dyborder = 10,
               intersp = 50)
