#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("RTN", "viper", "reshape2", "DESeq2"), repos = "http://bioconductor.org/biocLite.R")
source(paste(getwd(), "Scripts", "aracne2regulon_adapted.R", sep = "/"))
source(paste(getwd(), "Scripts", "msviper_adapted.R", sep = "/"))

#############################
# Load Data
#############################
MRA_Vargas2018 <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/MRA_Vargas2018.txt", stringsAsFactors=FALSE)
iRegs <- dget("2_2_1_2_TilePlot_MRA_intersection.txt")

#############################
# Extract results from VIPER
#############################
regExp <- paste("VIPER.*", ".RData$", sep = "")
## REGULONS
models <- paste(getwd(), c("MODEL-AD_5XFAD", 
                           "MODEL-AD_hAbeta_KI",
                           "MODEL_APP.PS1",
                           "HumanDatasets/MergedSet"),
                sep = "/")
results <- list()
for(i in seq(models)) {
        model <- models[i]
        filename <- grep(pattern = regExp, dir(model), ignore.case = T)
        if(length(filename) == 1) {
                filepath <- paste(model, "/", dir(model)[filename], sep = "")
                load(filepath)
                results [[length(results) + 1]] <- mra
                names(results)[length(results)] <- make.names(basename(model))
                rm(mra, filename, filepath)
        } else {
                for(f in filename) {
                        filepath <- paste(model, "/", dir(model)[f], sep = "")
                        load(filepath)
                        results [[length(results) + 1]] <- mra
                        m <- sub(pattern = "VIPER_", replacement = "", x = basename(filepath))
                        m <- sub(pattern = ".RData", replacement = "", x = m)
                        m <- paste(model, m, sep = ".")
                        names(results)[length(results)] <- make.names(basename(m))
                        rm(f, filepath, m)
                }
        }
        rm(i)
}

#############################
# save
#############################
source('/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/Scripts/plot.msviper_adapted.R')
fname <- fname <- paste("3_1_1_1_VIPER_plot.pdf", sep = "")
pdf(file = fname, width = 15, height = 15)
for (mra in seq(results)) {
        plot.msviper_adapted(x = results[[mra]], mrs = iRegs, plotTitle = names(results)[mra], 
                             orderby = "alphabetical")
}
dev.off()
