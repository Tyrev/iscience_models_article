#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("reshape2", "VennDiagram", "gplots", "gridExtra"), repos = "http://lib.stat.cmu.edu/R/CRAN")

#############################
# Load Data
#############################
FEA_GO <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/FEA/DEG/FEA_GO.txt", 
                       stringsAsFactors=FALSE)
feaList <- split(x = FEA_GO, f = FEA_GO$study)
feaList <- feaList[c("MODEL-AD_5XFAD", "MODEL-AD_hAbeta_KI_homozygous_22months-WT_22months", 
                     "MODEL_APP.PS1", "Human_LOAD")]
feaList <- lapply(feaList, function(x) subset(x = x, subset = x$ONTOLOGY == "BP"))

#############################
# Venn Diagram
#############################
listSYMBOL <- lapply(feaList, function(x) x$ID)
listSYMBOL <- lapply(listSYMBOL, na.omit)
listSYMBOL <- lapply(listSYMBOL, unique)
a1 <- length(x = listSYMBOL[[1]])
a2 <- length(x = listSYMBOL[[2]])
a3 <- length(x = listSYMBOL[[3]])
a4 <- length(x = listSYMBOL[[4]])
n12 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[2]]))
n13 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[3]]))
n14 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[4]]))
n23 <- length(intersect(listSYMBOL[[2]], listSYMBOL[[3]]))
n24 <- length(intersect(listSYMBOL[[2]], listSYMBOL[[4]]))
n34 <- length(intersect(listSYMBOL[[3]], listSYMBOL[[4]]))
n123 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]])) == 3)
n124 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[4]])) == 3)
n134 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[3]], listSYMBOL[[4]])) == 3)
n234 <- sum(table(c(listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[4]])) == 3)
n1234 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[4]])) == 4)
# vennPlot <- draw.triple.venn(area1 = a1, 
#                              area2 = a2,
#                              area3 = a3,
#                              n12 = n12,
#                              n23 = n23,
#                              n13 = n13,
#                              n123 = n123,
#                              scaled = F,
#                              category = c(names(listSYMBOL)[1], 
#                                           names(listSYMBOL)[2], 
#                                           names(listSYMBOL)[3]), 
#                              lty = 1,
#                              fill = c("pink1", "skyblue", "orange"),
#                              cat.cex = c (2, 2, 2),
#                              cat.pos = c(0, 0, 180),
#                              cat.dist = c(0.02, 0.02, 0.02),
#                              cat.just = list(c(0.9, 1), 
#                                              c(0.4, 1), 
#                                              c(0.5, 0)),
#                              int = F)
vennPlot <- draw.quad.venn(area1 = a1,
                           area2 = a2,
                           area3 = a3,
                           area4 = a4,
                           n12 = n12,
                           n13 = n13,
                           n14 = n14,
                           n23 = n23,
                           n24 = n24,
                           n34 = n34,
                           n123 = n123,
                           n124 = n124,
                           n134 = n134,
                           n234 = n234,
                           n1234 = n1234,
                           scaled = F,
                           category = c(names(listSYMBOL)[1],
                                        names(listSYMBOL)[2],
                                        names(listSYMBOL)[3],
                                        names(listSYMBOL)[4]),
                           lty = 1,
                           cex = rep(3, 15),
                           fill = c("pink1", "skyblue", "orange", "lightblue"),
                           cat.cex = c (2, 2, 2, 2),
                           cat.pos = c(0, 0, 0, 0),
                           cat.dist = c(0.2, 0.2, 0.1, 0.1),
                           cat.just = c(list(c(0.85, 0.5)),
                                        list(c(0.55, 0.5)),
                                        rep(list(c(0.5, 0.5)), 2)),
                           int = F)

#############################
# Save Plots
#############################
ndir <- paste(getwd(), "FEA", sep = "/")
if(!dir.exists(ndir)) {
     dir.create(ndir)
}
ndir <- paste(ndir, "DEG", sep = "/")
if(!dir.exists(ndir)) {
     dir.create(ndir)
}
ndir <- paste(ndir, "GOBP", sep = "/")
if(!dir.exists(ndir)) {
     dir.create(ndir)
}

fname <- paste(ndir, "/1_3_0_VennDiagram_DEG_GOBP.pdf", sep = "")
pdf (file = fname, width = 30, height = 12)
grid.arrange(gTree(children = vennPlot), 
             bottom = textGrob("FEA = pvalue < 0.05", ## pvalue threshold
                               gp = gpar(fontsize =25, font = 8)))
dev.off()
