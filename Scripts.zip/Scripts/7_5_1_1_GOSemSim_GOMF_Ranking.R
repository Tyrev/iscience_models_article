#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("GOSemSim", "ggplot2", "RedeR", "igraph"), 
                repos = "http://bioconductor.org/biocLite.R")

#############################
# Load Data
#############################
cluster_Dirpath <- "/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/GOSemSim/GOMF"
clusterTable_Filepath <- dir(cluster_Dirpath)
clusterTable_Filepath <- clusterTable_Filepath[grep(pattern = "ClustersTable.txt", x = clusterTable_Filepath)]
clusterTable_Filepath <- paste(cluster_Dirpath, clusterTable_Filepath, sep = "/")
cluster_tableList <- lapply(clusterTable_Filepath, read.delim, stringsAsFactors = FALSE)
names(cluster_tableList) <- gsub(pattern = ".txt", replacement = "", 
                                 x = basename(clusterTable_Filepath))

cluster_colors <- lapply(cluster_tableList, function(cluster_data) {
     cluster_colors <- split(cluster_data$color, f = cluster_data$clusters)
     cluster_colors <- sapply(cluster_colors, unique)
     return(cluster_colors)
})

#############################
# GOSemSim - Clusters
#############################
hsGO <- godata("org.Hs.eg.db", ont = "MF", computeIC = FALSE)

cl_mtxLogic_list <- lapply(cluster_tableList, function(cluster_data, hsGO) {
     term_clusters <- split(cluster_data$labels, f = cluster_data$clusters)
     cl_mtx <- matrix(data = NA, nrow = length(term_clusters), ncol = length(term_clusters),
                      dimnames = list("row" = names(term_clusters),
                                      "col" = names(term_clusters)))
     for(r in row.names(cl_mtx)) {
          for(c in colnames(cl_mtx)) {
               cl_mtx[r,c] <- mgoSim(term_clusters[[r]], 
                                     term_clusters[[c]], 
                                     semData = hsGO, measure = "Wang", combine = "BMA")
          }
     }
     cl_mtx_melted <- reshape2::melt(cl_mtx)
     row.names(cl_mtx_melted) <- apply(cl_mtx_melted[,1:2], 1, paste, collapse = "_")
     
     sim_ecdf <- ecdf(c(cl_mtx)[!c(cl_mtx) == 1])
     sim_ecdf_threshold <- quantile(x = sim_ecdf, prob = 0.8)
     cl_mtxLogic <- cl_mtx > sim_ecdf_threshold & cl_mtx != 1
     cl_mtxLogic <- matrix(as.numeric(cl_mtxLogic), nrow = nrow(cl_mtxLogic),
                           dimnames = list("row" = row.names(cl_mtx),
                                           "col" = colnames(cl_mtx)
                           )
     )
     return(cl_mtxLogic)
}, hsGO = hsGO)

clusterSize <- lapply(names(cluster_tableList), function(i, cl) {
     cluster_data <- cl[[i]]
     term_clusters <- split(cluster_data$labels, f = cluster_data$clusters)
     cl_size <- sapply(term_clusters, length)
     cl_size <- data.frame("cluster" = names(cl_size), "cluster_size" = cl_size, row.names = NULL)
     data.frame("Description" = i, cl_size, stringsAsFactors = F, row.names = NULL)
     
}, cl = cluster_tableList)
clusterSize <- do.call("rbind", clusterSize)

#############################
# Graph
#############################
graphList <- lapply(cl_mtxLogic_list, graph_from_adjacency_matrix, mode = "undirected", diag = F)
degreeList <- lapply(names(graphList), function(i, cl) {
     graph <- cl[[i]]
     dgr <- igraph::degree(graph)
     dgr <- data.frame("cluster" = names(dgr), "cluster_degree" = dgr, row.names = NULL)
     data.frame("Description" = i, dgr, stringsAsFactors = F, row.names = NULL)
}, cl = graphList)
degreeList <- do.call("rbind", degreeList)

#############################
# Cluster Rank
#############################
cluster_rank <- cbind(clusterSize, "cluster_degree" = degreeList[,3])
cluster_rank$cluster_rank_score <- apply(cluster_rank[,3:4], 1, prod)
clusterList <- split(x = cluster_rank, f = cluster_rank$Description)
clusterList <- lapply(clusterList, function(x) {
        x <- x[order(x$cluster_rank_score,decreasing = T),]
        x$cluster_rank <- 1:nrow(x)
        return(x)
})
cluster_rank <- do.call("rbind", clusterList)

#############################
# Save Results
#############################
ndir <- paste(getwd(), "GOSemSim", sep = "/")
if(!dir.exists(ndir)) {
     dir.create(ndir)
}
ndir <- paste(ndir, "GOMF", sep = "/")
if(!dir.exists(ndir)) {
     dir.create(ndir)
}
fname <- paste(ndir, "ClusterRank_Table_MF.txt", sep = "/")
write.table(x = cluster_rank, file = fname, sep = "\t", row.names = F)
