#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("clusterProfiler", "topGO", "GOSemSim", "ggplot2"), 
                repos = "http://bioconductor.org/biocLite.R")

#############################
# Load Data
#############################
FEA_GO <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/FEA/DEG/FEA_GO.txt", 
                     stringsAsFactors=FALSE)
FEA_GO <- subset(x = FEA_GO, subset = FEA_GO$ONTOLOGY == "CC")
fea_split <- split(x = FEA_GO, f = FEA_GO$study)
comp_int <- 4
comp <- names(fea_split)[comp_int]
fea_split <- fea_split[[comp]]

#############################
# GOSemSim - Terms
#############################
hsGO <- godata("org.Hs.eg.db", ont = "CC", computeIC = FALSE)
go1 <- fea_split$ID
go2 <- fea_split$ID
semantic_table <- mgoSim(go1, go2, semData = hsGO, measure = "Wang", combine = NULL)
## edge = similarity > sim_ecdf_threshold (or sim_ecdf_threshold = 0.8)
# sim_ecdf <- ecdf(c(semantic_table)[!c(semantic_table) == 1])
# sim_ecdf_threshold <- quantile(x = sim_ecdf, prob = 0.99)
# semantic_table_logic <- semantic_table > sim_ecdf_threshold & semantic_table != 1
# semantic_table_logic <- matrix(as.numeric(semantic_table_logic), nrow = nrow(semantic_table_logic),
#                                dimnames = list("row" = row.names(semantic_table),
#                                                "col" = colnames(semantic_table)
#                                ))

#############################
# Hierarchical cluster
#############################
smplDist = "euclidean"
clstDist = "ward.D"
##Extracting clusters
hcl <- hclust(d = dist(x = semantic_table, method = smplDist), method = clstDist)
cls <- as.data.frame(table(round(hcl$height, 1)))
cls <- cls[order(cls$Freq, decreasing = T),]
cls <- cls[cls$Freq >= round(mean(cls$Freq)),]
cls <- nrow(cls)
clusters <- cutree(tree = hcl, k = cls)[hcl$order]
clustcol <- cutree(tree = hcl, k = cls)[hcl$labels]
set.seed(123)
sidecolors <- randomcoloR::randomColor(count = length(levels(as.factor(clustcol))))
for(i in 1:length(levels(as.factor(clustcol)))){
     clustcol[clustcol == i] <- rep(sidecolors[i], length(clustcol[clustcol == i]))
     rm(i)
}
labels <- names(clusters)
clusters <- data.frame(labels, "clusters" = as.character(clusters[labels]),
                       "color" = clustcol[labels], stringsAsFactors = F)
annotation_colorsL <- unique(clusters$color)
names(annotation_colorsL) <- unique(clusters$clusters)
annotation_colorsL <- list("clusters" = annotation_colorsL)

plotmap <- pheatmap::pheatmap(mat = semantic_table,
                              clustering_distance_rows = smplDist,
                              clustering_distance_cols = smplDist,
                              clustering_method = clstDist,
                              annotation_row = clusters[,"clusters",drop=F],
                              show_rownames = F, show_colnames = F,
                              cluster_rows = T,
                              cluster_cols = T,
                              scale = "none",
                              annotation_colors = annotation_colorsL,
                              silent = F)

#############################
# Save Results
#############################
ndir <- paste(getwd(), "GOSemSim", sep = "/")
if(!dir.exists(ndir)) {
     dir.create(ndir)
}
ndir <- paste(ndir, "GOCC", sep = "/")
if(!dir.exists(ndir)) {
     dir.create(ndir)
}
fname <- paste(ndir, "/", comp_int, "_", comp, "_ClustersTable.txt", sep = "")
write.table(x = merge(x = clusters, y = fea_split[,c("ID","geneID")], by.x = "labels", by.y = "ID"), 
            file = fname, sep = "\t", row.names = F)
fname <- paste(ndir, "/", comp_int, "_", comp, "_Heatmap.pdf", sep = "")
ggsave(filename = fname, plot = plotmap, width = 15, height = 15)
