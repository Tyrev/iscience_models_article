#!/bin/sh
#cd /mnt/HD/Marco/Dropbox/PosDoc02_Zimmer/MODEL-AD_hAbeta_KI/test/FASTQ
for file in `ls | grep "fastq.gz$"`
	do
		wdpath=`pwd`
		#echo "path = ${wdpath}"
		fpath=`echo ${wdpath}/$file`
		echo "Uncompressing sample ${fpath}"
		gunzip ${fpath}
		#gunzip -k ${fpath} # Uncomment to NOT delete the original zip file
done

