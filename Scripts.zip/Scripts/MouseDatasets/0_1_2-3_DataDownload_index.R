#############################
# 
#############################
setwd("PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("curl"))

### - Linux Terminal - pipeline
### - Files:
###     2. PosDoc02_Zimmer/Scripts/0_1_2_DataDownload_indexDownload.sh 
###     3. PosDoc02_Zimmer/Scripts/0_1_3_DataDownload_indexBuild.sh

### download index transcriptome
# system (command = "bash MODEL-AD_hAbeta_KI/hAbetaKI_0_1_2_DataDownload_indexDownload.sh")
curl::curl_download(url = "ftp://ftp.ensembl.org/pub/release-96/fasta/mus_musculus/cdna/Mus_musculus.GRCm38.cdna.all.fa.gz", 
                    destfile = paste (getwd(), "musmusculus.fa.gz", sep = "/"),
                    quite = F)
curl::curl_download(url = "ftp://ftp.ensembl.org/pub/release-96/gtf/mus_musculus/Mus_musculus.GRCm38.96.chr.gtf.gz",
                    destfile = paste (getwd(), "musmusculus.gtf.gz", sep = "/"),
                    quiet = F)

### build index transcriptome
comm <- paste ("bash ", getwd(), "/Scripts/", "0_1_2_DataDownload_indexDownload.sh", sep = "")
system (command = comm)
