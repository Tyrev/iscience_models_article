#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("tximport",
                  "DESeq2",
                  "biomaRt"), 
                repos = "http://bioconductor.org/biocLite.R")
library(org.Mm.eg.db)
library(org.Hs.eg.db)

#############################
# Data
#############################
GEOID <- "MODEL_APP.PS1/"
## Sample paths
qt_fpath <- paste(getwd(), GEOID, "Data_Processed/FASTQ_qt", sep = "/")
qt_fpath <- paste(qt_fpath, dir(qt_fpath), sep = "/")
file_path <- file.path(qt_fpath, "quant.sf")
error_sample <- sapply(file_path, function(path) file.exists(path))
file_path <- file_path[error_sample]
SRR_id <- strsplit(x = basename(qt_fpath), "_")
SRR_id <- sapply(SRR_id, function (x) x[[1]])
names(file_path) <- SRR_id

## metadata
SRARunTable_path <- "sraruntable"
SRARunTable_path <- grep(pattern = SRARunTable_path, x = dir(GEOID), ignore.case = T)
SRARunTable_path <- dir(GEOID)[SRARunTable_path]
SRARunTable_path <- paste(getwd(), GEOID, SRARunTable_path, sep = "/")
SRR_Acc_List <- read.table(SRARunTable_path, sep = "\t", head = T, stringsAsFactors=FALSE)

#############################
# Metadata processing
#############################
metadata <- SRR_Acc_List[,c(1,3,4,14,15,16,17,20,21,24,25,26,2,27)]
# metadata1[,c(2:4)] <- sapply(metadata1[,c(2:4)], make.names)

### set test condition
metadata$condition1 <- metadata$Genotype

#############################
# Creating a transcript database
#############################
## 
library(GenomicFeatures)
txdb <- makeTxDbFromGFF(file = "/mnt/hd/Marco/Dropbox/Salmon/Mus.musculus_GRCm38/musmusculus.gtf.gz")
k <- keys(txdb, keytype = "TXNAME")
tx_map <- biomaRt::select(txdb, keys = k, columns = "GENEID", keytype = "TXNAME")
tx2gene <- tx_map

## annotation table
annotExpanded <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/Mm_Annotation.txt", stringsAsFactors=FALSE)
atable <- annotExpanded

#############################
# Integrate quantification into R
#############################
## tximport
txi <- tximport(file_path[metadata$Run], 
                type = "salmon", 
                tx2gene = tx_map, 
                varReduce = F, 
                txOut = F,
                ignoreTxVersion = T)
fname <- paste(getwd(), GEOID, sep = "/")
save(list = c("txi"), file = paste(fname, "txi.RData", sep = "/"))

## ddsTxi
samples <- metadata
row.names(samples) <- samples$Run
samples <- samples[colnames(txi$counts),]
ddsTxi <- DESeqDataSetFromTximport(txi,
                                   colData = samples,
                                   design = ~LibraryLayout + condition1)
ddsTxi <- DESeq2::estimateSizeFactors(ddsTxi)
ddsTxi <- DESeq2::estimateDispersions(ddsTxi)

#############################
# Save Tables
#############################
dds_counts <- counts(ddsTxi)
write.table(x = dds_counts, 
            file = paste(fname, "processed_counts.txt", sep = "/"), 
            sep = "\t")

dds_metadata <- as.data.frame(colData(ddsTxi))
write.table(x = dds_metadata, 
            file = paste(fname, "processed_metadata.txt", sep = "/"), 
            sep = "\t")

dds_annotation <- atable
write.table(x = dds_annotation, 
            file = paste(fname, "processed_annotation.txt", sep = "/"), 
            sep = "\t")

# #############################
# # Exploratory Analysis and Visualization
# #############################
# ## Pre-filtering the dataset
# ### mean row count > 10
# rowcountmean <- rowMeans(counts(ddsTxi))
# filter <- rowcountmean > 10
# dds <- ddsTxi[filter, ]
# 
# ## Data Transformation
# library(dplyr)
# library(ggplot2)
# library(vsn)
# ### regularized-logarithm transformation or rlog
# rld <- rlog(dds, blind = FALSE)
# ### variance stabilizing transformation(VST)
# vsd <- vst(dds, blind = FALSE)
# dds <- DESeq2::estimateSizeFactors(dds)
# df <- bind_rows(
#      as_tibble(log2(counts(dds, normalized=TRUE)[, 1:2]+1)) %>%
#           mutate(transformation = "log2(x + 1)"),
#      as_tibble(assay(rld)[, 1:2]) %>% mutate(transformation = "rlog"),
#      as_tibble(assay(vsd)[, 1:2]) %>% mutate(transformation = "vst")
#      )
# colnames(df)[1:2] <- c("x", "y")
# ggplot(df, aes(x = x, y = y)) + geom_hex() +
#      coord_fixed() + facet_grid( . ~ transformation)
# vsn::meanSdPlot(assay(rld), ranks = F)
# vsn::meanSdPlot(assay(vsd), ranks = F)
# ### Sample distances
# library("pheatmap")
# library("RColorBrewer")
# sampleDists <- dist(t(assay(rld)))
# sampleDistMatrix <- as.matrix(sampleDists)
# rownames(sampleDistMatrix) <- paste(rld$Genotype, sep = " - ")
# colnames(sampleDistMatrix) <- NULL
# colors <- colorRampPalette(rev(brewer.pal(9, "Blues")))(255)
# pheatmap::pheatmap(sampleDistMatrix,
#                    clustering_distance_rows = sampleDists,
#                    clustering_distance_cols = sampleDists,
#                    col = colors)
