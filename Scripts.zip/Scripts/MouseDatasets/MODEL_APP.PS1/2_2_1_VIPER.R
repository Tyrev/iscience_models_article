#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("RTN", "viper", "reshape2", "DESeq2"), repos = "http://bioconductor.org/biocLite.R")
source(paste(getwd(), "Scripts", "aracne2regulon_adapted.R", sep = "/"))
source(paste(getwd(), "Scripts", "msviper_adapted.R", sep = "/"))

#############################
# TNI
#############################
# RTNI info
# source("~/Dropbox/MR_AD/Scripts/Transcription network inference_hip_GSE60862.R"))
GEOID <- "GSE60862"
fname <- paste ("HumanDatasets", "/", GEOID, "/", "tni_hip.RData", sep = "")
load(fname)
MRA_Vargas2018 <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/MRA_Vargas2018.txt", stringsAsFactors=FALSE)

#############################
# Data
#############################
bdir <- paste(getwd(), "MODEL_APP.PS1/", sep = "/")
fname <- paste(bdir, "txi.RData", sep = "/")
load(fname)

processed_metadata <- read.delim(paste (bdir, "processed_metadata.txt", sep = "/"), stringsAsFactors=FALSE)
samples <- processed_metadata
samples$condition1 <- factor(samples$condition1, levels = c("WT", "APPPS1"))

#############################
# Construct dds object
#############################
ddsTxi <- DESeqDataSetFromTximport(txi,
                                   colData = samples,
                                   design = ~LibraryLayout + condition1) #https://support.bioconductor.org/p/76099/
ddsTxi <- DESeq2::estimateSizeFactors(ddsTxi)
ddsTxi <- DESeq2::estimateDispersions(ddsTxi)
dds <- ddsTxi
## arrayQualityMetrics
fname <- paste (bdir, "QC_table.txt", sep = "/")
qc_table <- read.delim2(file = fname, header = T)
qc_outliers <- apply (qc_table[,c(3:5)], 2, function (col) grep ("x", col))
qc_outliers <- Reduce ("union", qc_outliers)
# dds <- dds[,-qc_outliers]

## Pre-filtering the dataset
### count filter
count_filter <- row.names(tweeDEseq::filterCounts(counts(dds), mean.cpm.cutoff = 2))
dds <- dds[count_filter, ]
###  varianceStabilizingTransformation
rld <- vst(dds)
# dds <- rlog(assay(dds), blind = FALSE)
## batch correction
rld$batch <- factor(samples$LibraryLayout)
assay(rld) <- limma::removeBatchEffect(x = assay(rld), batch = rld$batch)
plotPCA(rld, "batch")

#############################
# Construct ExpressionSet object
#############################
## phenoData
phenoDat <- colData(rld)
phenoDat <- sapply(phenoDat@listData, as.character)
phenoDat <- data.frame(phenoDat, stringsAsFactors = F)
row.names(phenoDat) <- phenoDat[,1]
## assayData
assayDat <- assay(rld)
assayDat <- assayDat
## featureData
ann <- processed_metadata <- read.delim(paste (bdir, "processed_annotation.txt", sep = "/"), stringsAsFactors=FALSE)
featlist <- unique(ann[,-1])
featlist <- split(x = featlist, f = featlist$MGI_SYMBOL)
featlist <- lapply(X = featlist, FUN = function(df) {
     if(length(df[,3]) > 1) {
          x1 <- unique(df[,-3])
          x2 <- paste(unique(df[,3]), collapse = "/")
          x <- cbind(x1, x2)
          x <- sapply(x, as.character)
          names(x) <- colnames(df)
          return(x)
     }
     x <- unlist(df)
     return(x)
})
featlist <- do.call("rbind", featlist)
featureDat <- unique(featlist)
featureDat <- data.frame(featureDat, stringsAsFactors = F, row.names = NULL)
row.names(featureDat) <- featureDat$EMSEMBLID
featureDat <- featureDat[row.names(assayDat)[row.names(assayDat) %in% featureDat$EMSEMBLID],]
## ExpressionSet
featureDat <- as(featureDat, "AnnotatedDataFrame")
phenoDat <- as(phenoDat, "AnnotatedDataFrame")
myEset <- ExpressionSet(assayData = assayDat[featureDat$EMSEMBLID,], phenoData = phenoDat, featureData = featureDat)

gse <- myEset

#############################
# Load DEG
#############################
sig <- read.delim(paste(bdir, "/APPPS1-WT_DEG.txt", sep = ""), stringsAsFactors = FALSE)
sig <- na.omit(sig)
row.names(sig) <- sig$EMSEMBLID
signature <- (qnorm(sig$pvalue/2, lower.tail = FALSE) * sign(sig$log2FoldChange))
names(signature) <- sig$HGNC_SYMBOL

## setting study groups
groups <- pData(gse)$condition1
groups <- as.factor(groups)
names(groups) <- pData(gse)$specimenID

#############################
# VIPER
#############################
mim <- tni.get(object = rtni.hip, what = "tnet", idkey = "SYMBOL")
mmim <- melt(mim)
mmim$value <- abs(mmim$value)
mmim <- mmim[mmim$value != 0, ]
dset <- rtni.hip@gexp
row.names(dset) <- rtni.hip@annotation[row.names(dset), "SYMBOL"]
regul <- aracne2regulon_adapted(meltedmim = mmim, eset = dset, verbose = T, cores = 1)

pData(gse)$description_1 <- groups
pData(gse)$description_1 <- as.character(pData(gse)$description_1)

g1 <- levels(as.factor(pData(gse)[["description_1"]]))[1]
g2 <- levels(as.factor(pData(gse)[["description_1"]]))[2]

pos1 <- pData(gse)[["description_1"]] %in% g1
pos2 <- pData(gse)[["description_1"]] %in% g2
nullmodel <- ttestNull(x = exprs(gse)[, pos1], 
                       y = exprs(gse)[, pos2], 
                       per = 1000, repos = TRUE,
                       cores = 1, verbose = T, seed = 123)
row.names(nullmodel) <- fData(gse)[row.names(nullmodel), 3]

signature <- bootstrapTtest(x = gse, 
                            pheno = "description_1", 
                            group1 = g1, group2 = g2, 
                            per = 1000, verbose = T, seed = 123)
row.names(signature) <-  fData(gse)[row.names(signature), 3]

mra <- msviper_adapted(ges = signature, 
                       regulon = regul, 
                       nullmodel = nullmodel, 
                       pleiotropy = T,
                       adaptive.size = T,
                       verbose = T, 
                       cores = 1)
mra <- bootstrapmsviper(mra, "mode")
mra <- msviperCombinatorial(mra, regulators = 100, nullmodel = nullmodel, verbose = T)
mra <- msviperSynergy(mra, verbose = T, seed = 123)
mra <- ledge(mra)
mra <- shadow(mra, regulators = 100, verbose = T, seed = 123)

## results
fname <- paste(bdir, "VIPER.RData", sep = "/")
save(mra, file = fname)
