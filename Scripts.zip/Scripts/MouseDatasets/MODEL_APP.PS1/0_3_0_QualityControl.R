#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("arrayQualityMetrics",
                  "AffyCompatible",
                  "GEOquery",
                  "DESeq2"), repos = "http://bioconductor.org/biocLite.R")

#############################
# Data
#############################
GEOID <- "MODEL_APP.PS1/"
fname <- paste(getwd(), GEOID, "txi.RData", sep = "/")
load(fname)

processed_metadata <- read.delim(paste(getwd(), GEOID, "processed_metadata.txt", sep = "/"), stringsAsFactors=FALSE)

#############################
# Create dds object
#############################
samples <- processed_metadata
ddsTxi <- DESeqDataSetFromTximport(txi,
                                   colData = samples,
                                   design = ~LibraryLayout + condition1) #https://support.bioconductor.org/p/76099/
ddsTxi <- DESeq2::estimateSizeFactors(ddsTxi)
ddsTxi <- DESeq2::estimateDispersions(ddsTxi)
dds <- ddsTxi

# ## batch correction
# count_matrix <- assay(dds)
# batch <- factor(samples$LibraryLayout)
# group <- factor(samples$condition1)
# adjusted <- sva::ComBat_seq(count_matrix, batch = batch, group = group)
# adjusted <- apply(adjusted, 2, as.integer)
# dds <- DESeqDataSetFromMatrix(adjusted,
#                               colData = samples,
#                               design = ~LibraryLayout + condition1)
# dds <- DESeq2::estimateSizeFactors(dds)
# dds <- DESeq2::estimateDispersions(dds)
# dds$batch <- factor(samples$LibraryLayout)
# 
# plotPCA(vst(dds), "LibraryLayout")
# 
# pca_nonadj <- pcaMethods::pca(t(count_matrix))
# df_nonadj <- merge(pcaMethods::scores(pca_nonadj), samples, by = 0)
# ggplot(df_nonadj, aes(PC1, PC2, shape = Genotype, color = Instrument)) +
#      geom_point() +
#      xlab(paste("PC1", pca_nonadj@R2[1] * 100, "% of the variance")) +
#      ylab(paste("PC2", pca_nonadj@R2[2] * 100, "% of the variance"))
# pca_adj <- pcaMethods::pca(t(adjusted))
# df_adj <- merge(pcaMethods::scores(pca_adj), samples, by = 0)
# ggplot(df_adj, aes(PC1, PC2, shape = Genotype, color = Instrument)) +
#      geom_point() +
#      xlab(paste("PC1", pca_nonadj@R2[1] * 100, "% of the variance")) +
#      ylab(paste("PC2", pca_nonadj@R2[2] * 100, "% of the variance"))

#############################
# Create eSet
#############################
### count filter
count_filter <- row.names(tweeDEseq::filterCounts(counts(ddsTxi), mean.cpm.cutoff = 2))
dds <- dds[count_filter, ]
###  varianceStabilizingTransformation
dds <- vst(dds)
# dds <- rlog(assay(dds), blind = FALSE)
## batch correction
dds$batch <- factor(samples$LibraryLayout)
assay(dds) <- limma::removeBatchEffect(x = assay(dds), batch = dds$batch)
# plotPCA(dds, c("LibraryLayout", "condition1"))

phenoDat <- colData(dds)
phenoDat <- sapply(phenoDat@listData, as.character)
phenoDat <- data.frame(phenoDat, stringsAsFactors = F)
row.names(phenoDat) <- phenoDat$Run
assayDat <- assay(dds)
assayDat <- assayDat
ann <- read.delim(paste(getwd(), GEOID, "processed_annotation.txt", sep = "/"), stringsAsFactors=FALSE)
featlist <- subset(x = ann, subset = ann$MGI_SYMBOL != "")
featlist <- unique(featlist[,-1])
featlist <- split(x = featlist, f = featlist$MGI_SYMBOL)
featlist <- lapply(X = featlist, FUN = function(df) {
     if(length(df[,3]) > 1) {
          x1 <- unique(df[,-3])
          x2 <- paste(unique(df[,3]), collapse = "/")
          x <- cbind(x1, x2)
          x <- sapply(x, as.character)
          names(x) <- colnames(df)
          return(x)
     }
     x <- unlist(df)
     return(x)
})
featlist <- do.call("rbind", featlist)
featureDat <- na.omit(unique(featlist))
featureDat <- data.frame(featureDat, stringsAsFactors = F, row.names = NULL)
row.names(featureDat) <- featureDat$EMSEMBLID
featureDat <- featureDat[row.names(assayDat)[row.names(assayDat) %in% featureDat$EMSEMBLID],]

featureDat <- as(featureDat, "AnnotatedDataFrame")
phenoDat <- as(phenoDat, "AnnotatedDataFrame")
myEset <- ExpressionSet(assayData = assayDat[featureDat$EMSEMBLID,], phenoData = phenoDat, featureData = featureDat)

gse <- myEset

#############################
# Quality Control Processed
#############################
qc <- arrayQualityMetrics(expressionset = gse,
                          outdir = paste(getwd(), GEOID, "QC_Processed", sep = "/"),
                          do.logtransform = F,
                          force = T,
                          reporttitle = "QC_report",
                          intgroup = "condition1",
                          spatial = F)
qc_table <- qc$arrayTable
write.table(x = qc_table, file = paste(getwd(), GEOID, "QC_table.txt", sep = "/"), sep = "\t", row.names = F)
