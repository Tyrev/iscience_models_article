#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("tximport",
                   "DESeq2",
                   "org.Mm.eg.db"), 
                 repos = "http://bioconductor.org/biocLite.R")

#############################
# Data
#############################
GEOID <- "MODEL_APP.PS1/"
fname <- paste(getwd(), GEOID, "txi.RData", sep = "/")
load (fname)

processed_metadata <- read.delim(paste (getwd(), GEOID, "processed_metadata.txt", sep = "/"), stringsAsFactors=FALSE)

#############################
# Create dds object
#############################
samples <- processed_metadata
samples$condition1 <- factor(samples$condition1, levels = c("WT", "APPPS1"))
ddsTxi <- DESeqDataSetFromTximport(txi,
                                   colData = samples,
                                   design = ~LibraryLayout + condition1) #https://support.bioconductor.org/p/76099/
ddsTxi <- DESeq2::estimateSizeFactors(ddsTxi)
ddsTxi <- DESeq2::estimateDispersions(ddsTxi)
dds <- ddsTxi
## arrayQualityMetrics
fname <- paste (getwd(), GEOID, "QC_table.txt", sep = "/")
qc_table <- read.delim2(file = fname, header = T)
qc_outliers <- apply (qc_table[,c(3:5)], 2, function (col) grep ("x", col))
qc_outliers <- Reduce ("union", qc_outliers)
# dds <- dds[,-qc_outliers]

#############################
# DESeq
#############################
## Pre-filtering the dataset
### count filter
count_filter <- row.names(tweeDEseq::filterCounts(counts(dds), mean.cpm.cutoff = 2))
dds <- dds[count_filter, ]
## DE
dds <- DESeq(dds)
## comparisons
cpairs <- strsplit(x = resultsNames(dds)[3], split = "_")
cpairs <- unlist(cpairs)[c(2,4)]
cpairs <- paste(cpairs, collapse = "-")
resList <- list()
resList[[cpairs]] <- results(dds, name = resultsNames(dds)[3])
resList[[cpairs]] <- lfcShrink(dds, 
                               contrast = contrast_obj, 
                               res = resList[[cpairs]], 
                               type = "ashr",
                               svalue = F)
# DESeq2::plotMA(resList[[1]], ylim = c(-1, 1), alpha = 0.05)

#############################
# Annotating and exporting results
#############################
processed_annotation <- read.delim(paste (getwd(), GEOID, "processed_annotation.txt", sep = "/"), 
                                   stringsAsFactors = FALSE)
featlist <- unique(processed_annotation[,-1])
featlist <- split(x = featlist, f = featlist$MGI_SYMBOL)
featlist <- lapply(X = featlist, FUN = function (df) {
        if (length (df[,3]) > 1) {
                x1 <- unique (df[,-3])
                x2 <- paste(unique(df[,3]), collapse = "/")
                x <- cbind (x1, x2)
                x <- sapply (x, as.character)
                names(x) <- colnames(df)
                return(x)
        }
        x <- unlist(df)
        return(x)
})
featlist <- do.call("rbind", featlist)
featureDat <- unique(featlist)
featureDat <- data.frame(featureDat, stringsAsFactors = F, row.names = NULL)
row.names(featureDat) <- featureDat$EMSEMBLID

#############################
# Exporting results
#############################
resListAnn <- lapply (resList, function (res, fdat) {
        res <- res[intersect(row.names(res), row.names(fdat)),]
        tT <- data.frame (res, stringsAsFactors = F)
        tT <- data.frame ("EMSEMBLID" = row.names (tT), tT, stringsAsFactors = F)
        tT <- merge(tT,fdat)
        tT <- tT[order(tT$pvalue),]
        tT <- na.omit (tT)
        return(tT)
}, fdat = featureDat)

## result outputs
for (comp in names(resListAnn)) {
        contrast_name <- comp
        fname <- paste(getwd(), "/", GEOID, "/", contrast_name, "_DEG.txt", sep = "")
        write.table(resListAnn[[comp]], file = fname, sep = "\t")
}
