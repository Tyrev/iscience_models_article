#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("SRAdb", "Biobase", "GEOquery"), 
                 repos = "http://bioconductor.org/biocLite.R")

#############################
# GEOquery
#############################
## load series and platform data from GEO
GEOID <- "MODEL_APP.PS1/"

#############################
# Raw Count Files Download (SRA) (SRAToolKit)
#############################
### https://www.ncbi.nlm.nih.gov/Traces/study/?
SRARunTable_path <- "sraruntable"
SRARunTable_path <- grep(pattern = SRARunTable_path, x = dir(GEOID), ignore.case = T)
SRARunTable_path <- dir(GEOID)[SRARunTable_path]
SRARunTable_path <- paste(getwd(), GEOID, SRARunTable_path, sep = "/")
SRR_Acc_List <- read.table(SRARunTable_path, sep = "\t", head = T, stringsAsFactors=FALSE)
SRR_Acc <- SRR_Acc_List$Run

dfolder <- paste(getwd(), GEOID, "FASTQ", sep = "/")
if (!file.exists(dfolder)) {
        dir.create(path = dfolder) 
}

liblayout <- SRR_Acc_List$LibraryLayout
names(liblayout) <- SRR_Acc

for(q in seq(SRR_Acc)) {
        ## Download SRA using SRAToolKit
        comm1 <- paste("export PATH=$PATH:/mnt/hd/Marco/Dropbox/SRAToolKit/sratoolkit.2.10.0-ubuntu64/bin")
        comm2 <- paste("prefetch -c ", SRR_Acc[q],
                       " --output-directory ", dfolder,
                       sep = "")
        comm <- paste(comm1, comm2, sep = ";")
        system (command = comm)
        ## convert to SRA to FASTQ
        sra_file <- paste(dfolder, "/", SRR_Acc[q], ".sra", sep = "")
        if(grepl(pattern = "single", x = liblayout[SRR_Acc[q]], ignore.case = T)) {
                comm3 <- paste("fastq-dump ",
                               sra_file,
                               " --outdir ", dfolder,
                               sep = "")
        } else {
                comm3 <- paste("fastq-dump ",
                               "--split-files ",
                               sra_file,
                               " --outdir ", dfolder,
                               sep = "")
        }
        comm <- paste(comm1, comm3, sep = ";")
        system (command = comm)
}
