#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("RTN", "DESeq2"), 
                repos = "http://bioconductor.org/biocLite.R")

#############################
# TNI
#############################
# RTNI info
# source("~/Dropbox/MR_AD/Scripts/Transcription network inference_hip_GSE60862.R"))
load("HumanDatasets/GSE60862/tni_hip.RData")
MRA_Vargas2018 <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/MRA_Vargas2018.txt", stringsAsFactors=FALSE)

#############################
# Data
#############################
bdir <- paste(getwd(), "MODEL_APP.PS1/", sep = "/")
fname <- paste(bdir, "txi.RData", sep = "/")
load(fname)

processed_metadata <- read.delim(paste (bdir, "processed_metadata.txt", sep = "/"), stringsAsFactors=FALSE)
samples <- processed_metadata
samples$condition1 <- factor(samples$condition1, levels = c("WT", "APPPS1"))

#############################
# Construct dds object
#############################
ddsTxi <- DESeqDataSetFromTximport(txi,
                                   colData = samples,
                                   design = ~LibraryLayout + condition1) #https://support.bioconductor.org/p/76099/
ddsTxi <- DESeq2::estimateSizeFactors(ddsTxi)
ddsTxi <- DESeq2::estimateDispersions(ddsTxi)
dds <- ddsTxi
## arrayQualityMetrics
fname <- paste (bdir, "QC_table.txt", sep = "/")
qc_table <- read.delim2(file = fname, header = T)
qc_outliers <- apply (qc_table[,c(3:5)], 2, function (col) grep ("x", col))
qc_outliers <- Reduce ("union", qc_outliers)
# dds <- dds[,-qc_outliers]

## Pre-filtering the dataset
### count filter
count_filter <- row.names(tweeDEseq::filterCounts(counts(dds), mean.cpm.cutoff = 2))
dds <- dds[count_filter, ]
###  varianceStabilizingTransformation
rld <- vst(dds)
plotPCA(rld, "batch")
# dds <- rlog(assay(dds), blind = FALSE)
## batch correction
rld$batch <- factor(samples$LibraryLayout)
assay(rld) <- limma::removeBatchEffect(x = assay(rld), batch = rld$batch)

#############################
# Construct TNA
#############################
# Load DEG
deg.table <- read.delim(paste(bdir, "/APPPS1-WT_DEG.txt", sep = ""), stringsAsFactors = FALSE)
deg.table <- na.omit(deg.table)
row.names(deg.table) <- deg.table$EMSEMBLID

dups <- deg.table$EMSEMBLID[deg.table$HGNC_SYMBOL %in% deg.table$HGNC_SYMBOL[duplicated(deg.table$HGNC_SYMBOL)]]
names(dups) <- deg.table[dups,"HGNC_SYMBOL"]
dups_list <- split(x = dups, f = names(dups))

counts_mtx <- assay(rld)
counts_mtx <- counts_mtx[dups,]
cv <- apply(X = counts_mtx,MARGIN = 1, FUN = function(r) sd(r)/mean(r))
cv_filter <- lapply(dups_list, function(g,cv) {
     set <- cv[g]
     cvfilter <- which(set %in% min(set))
     names(set)[-cvfilter]
}, cv = cv)
cv_filter <- do.call("c", cv_filter)

deg.table <- deg.table[-which(deg.table$EMSEMBLID %in% cv_filter),]

# phenotype
pheno <- deg.table$log2FoldChange
names(pheno) <- deg.table$EMSEMBLID

# hits
threshold_cutoff <- 0.05
hits <- deg.table[deg.table$pvalue < threshold_cutoff,]
hits <- as.character(hits$EMSEMBLID)

# phenoIDs
gcol <- NULL
if(length(grep("HGNC", names(deg.table), ignore.case = T)) != 0) {gcol <- c(gcol, grep("HGNC", names(deg.table), ignore.case = T))}
pid <- deg.table[,c(1, gcol)]
names(pid) <- c("PROBEID", "SYMBOL")[1:ncol(pid)]

## TNI to TNA
tna <- tni2tna.preprocess(rtni.hip, phenotype = pheno, hits = hits, phenoIDs = pid)

## MRA
set.seed(123)
tna <- tna.mra(tna, minRegulonSize = 100)
mra.result <- tna.get(tna, what = "mra")

## one-tail GSEA
# library(snow)
# options(cluster = makeCluster(3, "SOCK"))
set.seed(123)
tna <- tna.gsea1(tna, minRegulonSize = 100, orderAbsValue = T, sizeFilterMethod = "posPLUSneg")
# stopCluster(getOption("cluster"))
gsea1.result <- tna.get(tna, what = "gsea1")

## two-tail GSEA
# library(snow)
# options(cluster = makeCluster(3, "SOCK"))
set.seed(123)
tna <- tna.gsea2(tna, sizeFilterMethod = "posPLUSneg")
# stopCluster(getOption("cluster"))
gsea2.result <- tna.get(tna, what = "gsea2")$differential

# results
fname <- paste(bdir, "TNA.RData", sep = "/")
save(tna, file = fname)
