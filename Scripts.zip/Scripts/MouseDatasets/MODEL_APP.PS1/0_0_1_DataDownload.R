#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("synapser",
                   "synapserutils"), 
                 repos = "http://bioconductor.org/biocLite.R")

#############################
# Download from Synapse
#############################
## Metadata processing
RNAseq_metadata <- read.csv("MODEL_APP.PS1/ModelAD_Metadata/Jax.IU.Pitt_APP.PS1_assay_rnaseq_metadata.csv", stringsAsFactors=FALSE, na.strings = "")
biospecimen_metadata <- read.csv("MODEL_APP.PS1/ModelAD_Metadata/Jax.IU.Pitt_APP.PS1_biospecimen_metadata.csv", stringsAsFactors=FALSE, na.strings = "")
merge1 <- merge(RNAseq_metadata, unique(biospecimen_metadata))
merge1 <- merge1 [,c(1,2,3,11,17)]
individual_metadata <- read.csv("MODEL_APP.PS1/ModelAD_Metadata/Jax.IU.Pitt_APP.PS1_individual_metadata.csv", stringsAsFactors=FALSE, na.strings = "")
individual_metadata <- individual_metadata[,c(1:5,24)]
merge2 <- merge(merge1, individual_metadata, by.x = "specimenID", by.y = "individualID")
merge2$tissue

# synLogin("Tyrev", "mtv24fox")
# ## https://www.synapse.org/#!Synapse:syn18634479
# synid <- "syn15667136"
# iter <- synapse.browser(synid = synid)
# 
# x <- NULL
# for(r in 1:nrow(iter)) {
#      ri <- iter[r,2]
#      
#      id <- strsplit(x = ri, split = "_")
#      id <- id[[1]][[1]]
#      
#      x <- c(x, id)
# }
# rm(id, r, ri)
# x <- gsub(pattern = "C57-", replacement = "", x = x, ignore.case = T)
# iter <- cbind(iter, x)
# keep_files <- merge(merge2, iter, by.x = "individualID", by.y = "x")
# 
# iter <- as.character(keep_files$id)
# 
# ndir <- paste(getwd(), "MODEL-AD_hAbeta_KI", "Data_UnProcessed", sep = "/")
# if(!dir.exists(ndir)) {
#      dir.create(ndir)   
# }
# ndir <- paste(getwd(), "MODEL-AD_hAbeta_KI", "Data_UnProcessed", "FASTQ", sep = "/")
# if(!dir.exists(ndir)) {
#      dir.create(ndir)   
# }
# 
# for(f in 1:length(iter)) {
#      synid <- iter[f]
#      synapserutils::syncFromSynapse(entity = synid, 
#                                     path = ndir,
#                                     ifcollision = "overwrite.local")
# }
