#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("tximport",
                  "DESeq2",
                  "tweeDEseq"), 
                repos = "http://bioconductor.org/biocLite.R")
library(org.Mm.eg.db)
library(org.Hs.eg.db)

#############################
# Data
#############################
## Sample paths
qt_fpath <- paste(getwd(), "MODEL-AD_hAbeta_KI", sep = "/")
qt_fpath <- paste(c(qt_fpath, "Data_Processed/FASTQ_qt"), collapse = "/")
qt_fpath <- paste(qt_fpath, dir(qt_fpath), sep = "/")
file_path <- file.path(qt_fpath, "quant.sf")
error_sample <- sapply(file_path, function(path) file.exists(path))
file_path <- file_path[error_sample]

###
qt_fpath <- qt_fpath[error_sample]
bname <- basename(qt_fpath)
bname <- strsplit(x = bname, split = "=")
bname <- sapply(bname, function(x) {x[[length(x)]]})

## Metadata processing
RNAseq_metadata <- read.csv("MODEL-AD_hAbeta_KI/Metadata/UCI_hAbKI_RNAseq_metadata.csv", stringsAsFactors=FALSE)
biospecimen_metadata <- read.csv("MODEL-AD_hAbeta_KI/Metadata/UCI_hAbKI_biospecimen_metadata.csv", stringsAsFactors=FALSE)
merge1 <- merge(RNAseq_metadata, unique(biospecimen_metadata))
merge1 <- merge1 [,c(1,13,2:12,14:15)]
individual_metadata <- read.csv("MODEL-AD_hAbeta_KI/Metadata/UCI_hABKI_individual_metadata.csv", stringsAsFactors=FALSE)
merge2 <- merge(merge1, individual_metadata)
merge2 <- merge2[,-c(3, 5:13, 21, 26:38)]
merge2$individualID <- gsub(pattern = ",", replacement = "-", x = merge2$individualID)
row.names(merge2) <- merge2$individualID

sampname <- strsplit(x = qt_fpath, split = "/")
sampname <- sapply(sampname, function(x) {x[[length(x)]]})
sampinfo <- strsplit(x = sampname, split = "_")
sampinfo <- sapply(sampinfo, function(x){x[[2]]})
samporder <- sapply(merge2$individualID, function(id, file) {
        grep(pattern = id, x = file, ignore.case = T)
}, file = sampinfo)
sampinfo <- sampinfo[samporder]
names(sampinfo) <- names(samporder)
sampinfo <- strsplit(x = sampinfo, split = "=")
sampinfo <- do.call("rbind", sampinfo)
sampinfo <- data.frame(sampinfo, stringsAsFactors = F)
sampinfo[,"individualID"] <- row.names(sampinfo)
birth <- as.Date(merge2$dateBirth, tryFormats = c("%m/%d/%y"))
death <- as.Date(merge2$dateDeath, tryFormats = c("%m/%d/%y"))
time_months <- ifelse (test = (death - birth)/30 > 20, yes = "22months", no = "2months")
sampinfo <- data.frame("time_months" = time_months, "individualID" = sampinfo[,2], stringsAsFactors = F)

merge3 <- merge(merge2, sampinfo)
merge3 <- merge3[,c(1,2,ncol(merge3), 3:(ncol(merge3)-1))]
merge3$condition1 <- apply(merge3, 1, function(x) {
        x <- paste(x[c("time_months", "sex", "genotype")], collapse = "_")
        x <- gsub(pattern = "hABKI_", replacement = "", x = x)
        return(x)
})

###
genotype <- merge3$genotype
genotype <- strsplit(x = genotype, split = "_")
genotype <- sapply(genotype, function(x) x[[2]])
samples <- data.frame("sampleID" = merge3$individualID, 
                      "specimenID" = merge3$specimenID,
                      "tissue" = merge3$tissue,
                      "genotype" = genotype, 
                      "time_months" = merge3$time_months,
                      "sex" = merge3$sex,
                      "condition1" = merge3$condition1,
                      stringsAsFactors = F)
row.names(samples) <- samples$sampleID

###
samp_o <- sapply(row.names(samples), function(id, bnm) {
        n_eval <- grepl(pattern = id, x = bnm, ignore.case = T)
        which(n_eval)
}, bnm = bname)
samp_o <- samp_o[sapply(samp_o, length) == 1]
file_path <- file_path[samp_o]
names(file_path) <- names(samp_o)
samples <- samples[names(file_path),]

#############################
# Creating a transcript database
#############################
## 
library(GenomicFeatures)
txdb <- makeTxDbFromGFF(file = "/mnt/hd/Marco/Dropbox/Salmon/Mus.musculus_GRCm38/musmusculus.gtf.gz")
k <- keys(txdb, keytype = "TXNAME")
tx_map <- biomaRt::select(txdb, keys = k, columns = "GENEID", keytype = "TXNAME")
tx2gene <- tx_map

## annotation table
annotExpanded <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/Mm_Annotation.txt", stringsAsFactors=FALSE)

#############################
# Integrate quantification into R
#############################
## tximport
txi <- tximport(file_path, 
                type = "salmon", 
                tx2gene = tx_map, 
                varReduce = F, 
                txOut = F,
                ignoreTxVersion = T)
fname <- "MODEL-AD_hAbeta_KI"
save(list = c("txi"), file = paste(fname, "txi.RData", sep = "/"))

##
ddsTxi <- DESeqDataSetFromTximport(txi,
                                   colData = samples,
                                   design = ~ condition1)
ddsTxi <- DESeq2::estimateSizeFactors(ddsTxi)
ddsTxi <- DESeq2::estimateDispersions(ddsTxi)
dds <- ddsTxi

#############################
# Save Tables
#############################
dds_counts <- counts(ddsTxi)
write.table(x = dds_counts, 
            file = paste(fname, "processed_counts.txt", sep = "/"), 
            sep = "\t")

dds_metadata <- as.data.frame(colData(ddsTxi))
write.table(x = dds_metadata, 
            file = paste(fname, "processed_metadata.txt", sep = "/"), 
            sep = "\t")

dds_annotation <- annotExpanded
write.table(x = dds_annotation, 
            file = paste(fname, "processed_annotation.txt", sep = "/"), 
            sep = "\t")

#############################
# Exploratory Analysis and Visualization
#############################
## Pre-filtering the dataset
### count filter
count_filter <- row.names(filterCounts(counts(dds), mean.cpm.cutoff = 2))
dds <- dds[count_filter, ]

## Data Transformation
library(dplyr)
library(ggplot2)
library(vsn)
### regularized-logarithm transformation or rlog
rld <- rlog(dds, blind = FALSE)
### variance stabilizing transformation(VST)
vsd <- vst(dds, blind = FALSE)
df <- bind_rows(
        as_tibble(log2(counts(dds, normalized=TRUE)[, 1:2]+1)) %>%
                mutate(transformation = "log2(x + 1)"),
        as_tibble(assay(rld)[, 1:2]) %>% mutate(transformation = "rlog"),
        as_tibble(assay(vsd)[, 1:2]) %>% mutate(transformation = "vst")
)
colnames(df)[1:2] <- c("x", "y")
ggplot(df, aes(x = x, y = y)) + geom_hex() +
        coord_fixed() + facet_grid( . ~ transformation)
vsn::meanSdPlot(assay(rld), ranks = F)
vsn::meanSdPlot(assay(vsd), ranks = F)
### Sample distances
library("pheatmap")
library("RColorBrewer")
sampleDists <- dist(t(assay(rld)))
sampleDistMatrix <- as.matrix(sampleDists)
rownames(sampleDistMatrix) <- paste(rld$condition1, sep = " - ")
colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette(rev(brewer.pal(9, "Blues")))(255)
pheatmap::pheatmap(sampleDistMatrix,
                   clustering_distance_rows = sampleDists,
                   clustering_distance_cols = sampleDists,
                   col = colors)
