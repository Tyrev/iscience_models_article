#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("tximport",
                   "DESeq2",
                   "EnsDb.Mmusculus.v79"), 
                 repos = "http://bioconductor.org/biocLite.R")


#############################
# Custom Functions
#############################
is_fastq.gz <- function (path) {
     teval <- grepl (pattern = ".fastq.gz$", x = path)
     return (teval)
}

fastq_rename <- function (FASTQFolderPath, dir_lvls) {
        filepath <- FASTQFolderPath
        if (dir_lvls > 1) {
                dlvl <- 0
                while (dlvl != dir_lvls) {
                        dlvl <- dlvl + 1
                        filepath <- sapply (filepath, function (p) {
                                np <- paste (p, dir (p), sep = "/")
                                names (np) <- dir(p)
                                return (np)
                        })
                }
                fnew_names <- sapply (unlist (filepath), strsplit, split = "/")
                names (fnew_names) <- unlist (filepath)
                fnew_names <- sapply (fnew_names, function (x, dir_lvls) {
                        pathlenth <- length (x)
                        dlvls <- dir_lvls - 1
                        dpath <- paste (x[-pathlenth], collapse = "/")
                        new_file <- paste (x[pathlenth-1], x[pathlenth], sep = "=")
                        return (paste (dpath, new_file, sep = "/"))
                }, dir_lvls = dir_lvls)
        } else {
                fnew_names <- paste (filepath, dir (filepath), sep = "/")
        }
        return (fnew_names)
}

#############################
# Raw Data - FASTQ
#############################
## Transcript abundance quantification using Salmon
### - Linux Terminal - pipeline
### - Files:
###     0_1_4_DataDownload_Quantification.sh

## Indentify and rename fastq.gz files to prepare FASTQ folder
filepath <- paste (getwd(), "MODEL-AD_hAbeta_KI/Data_UnProcessed/FASTQ", sep = "/")
dir_lvls <- 0
dir_eval <- T
while (dir_eval) {
     test <- all (sapply (filepath, is_fastq.gz))
     if (!test) {
          filepath <- sapply (filepath, function (p) {
               np <- paste (p, dir (p), sep = "/")
               names (np) <- dir(p)
               return (np)
          })
          filepath <- unlist (filepath)
          
          dir_lvls <- dir_lvls + 1
     } else {
          dir_eval <- F
     }
     rm (test)
}
rm (filepath, dir_eval)

fastqfilepath <- paste (getwd(), "MODEL-AD_hAbeta_KI/Data_UnProcessed/FASTQ", sep = "/")

## Create FASTQ_qt folder, create subfolder structures and copy fastq.gz files to FASTQ_qt subfolder
ndir <- paste (getwd(), "MODEL-AD_hAbeta_KI/Data_UnProcessed", "FASTQ_qt", sep = "/")
if (!dir.exists(ndir)) {
     dir.create(ndir)   
}
ndir <- paste (getwd(), "MODEL-AD_hAbeta_KI", "Data_Processed", sep = "/")
if (!dir.exists(ndir)) {
        dir.create(ndir)   
}
ndir <- paste (getwd(), "MODEL-AD_hAbeta_KI", "Data_Processed", "FASTQ_qt", sep = "/")
if (!dir.exists(ndir)) {
        dir.create(ndir)   
}
fnew_names <- fastq_rename(fastqfilepath, dir_lvls)
for (f in seq (fnew_names)) {
        fstrucr <- lapply (fnew_names[f], function (x) strsplit (x = x, split = "_R1|_R2")[[1]][[1]])
        fstrucr <- sapply (fstrucr, function (x) {
                s <- strsplit (x = x, split = "/")[[1]]
                return (s[length (s)])
        })
        names (fstrucr) <- fnew_names[f]
        d <- fstrucr
        ndir <- paste (getwd(), "MODEL-AD_hAbeta_KI/Data_UnProcessed", "FASTQ_qt", sep = "/")
        if (!dir.exists(ndir)) {
                dir.create(ndir)   
        }
        nd <- paste (ndir, d, sep = "/")
        if (!dir.exists(nd)) {
                dir.create(nd)
        }
        file.copy(from = names (d), to = nd)
        # file.remove(names (d))
}

## Quantify samples
### run quantification shell
l1 <- "export PATH=$PATH:/mnt/hd/Marco/Dropbox/Salmon/salmon-latest_linux_x86_64/bin"
l2 <- paste("cd ", getwd(), "/MODEL-AD_hAbeta_KI/", sep = "")
l3 <- paste("bash ", getwd(), "/MODEL-AD_hAbeta_KI/", "0_1_4_DataDownload_Quantification.sh", sep = "")
system(command = paste (l1, l2, l3, sep = ";"))
