#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("synapser",
                   "synapserutils"), 
                 repos = "http://bioconductor.org/biocLite.R")

#############################
# Download from Synapse
#############################
## Metadata processing
RNAseq_metadata <- read.csv("MODEL-AD_hAbeta_KI/Metadata/UCI_hAbKI_RNAseq_metadata.csv", stringsAsFactors=FALSE, na.strings = "")
biospecimen_metadata <- read.csv("MODEL-AD_hAbeta_KI/Metadata/UCI_hAbKI_biospecimen_metadata.csv", stringsAsFactors=FALSE, na.strings = "")
merge1 <- merge(RNAseq_metadata, unique(biospecimen_metadata))
merge1 <- merge1 [,c(1,3)]
merge1$individualID <- gsub(pattern = "rh", replacement = "", x = merge1$specimenID, ignore.case = T)
individual_metadata <- read.csv("MODEL-AD_hAbeta_KI/Metadata/UCI_hABKI_individual_metadata.csv", stringsAsFactors=FALSE, na.strings = "")
merge2 <- merge(merge1, individual_metadata)
merge2$individualID <- gsub(pattern = ",", replacement = "-", x = merge2$individualID)

synLogin("Tyrev", "mtv24fox")
## https://www.synapse.org/#!Synapse:syn18634479
synid <- "syn18634479"
iter <- synapse.browser(synid = synid)

x <- NULL
for(r in 1:nrow(iter)) {
     ri <- iter[r,2]
     
     id <- strsplit(x = ri, split = "_")
     id <- id[[1]][[1]]
     
     x <- c(x, id)
}
rm(id, r, ri)
x <- gsub(pattern = "C57-", replacement = "", x = x, ignore.case = T)
iter <- cbind(iter, x)
keep_files <- merge(merge2, iter, by.x = "individualID", by.y = "x")

iter <- as.character(keep_files$id)

ndir <- paste(getwd(), "MODEL-AD_hAbeta_KI", "Data_UnProcessed", sep = "/")
if(!dir.exists(ndir)) {
     dir.create(ndir)   
}
ndir <- paste(getwd(), "MODEL-AD_hAbeta_KI", "Data_UnProcessed", "FASTQ", sep = "/")
if(!dir.exists(ndir)) {
     dir.create(ndir)   
}

for(f in 1:length(iter)) {
     synid <- iter[f]
     synapserutils::syncFromSynapse(entity = synid, 
                                    path = ndir,
                                    ifcollision = "overwrite.local")
}
