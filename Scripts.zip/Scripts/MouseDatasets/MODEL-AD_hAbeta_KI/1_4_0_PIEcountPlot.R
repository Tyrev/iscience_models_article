##############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("ggplot2", "reshape2"), repos = "http://lib.stat.cmu.edu/R/CRAN")

#############################
# Load Data
#############################
bdir <- paste(getwd(), "MODEL-AD_hAbeta_KI", sep = "/")
fname <- paste(bdir, sep = "/")
degfiles <- grep(pattern = "_DEG.txt", x = dir(fname), ignore.case = T)
names(degfiles) <- gsub(pattern = "_DEG.txt", replacement = "", x = dir(fname)[degfiles])
fname <- paste(fname, dir(fname), sep = "/")
degList <- lapply (X = fname[degfiles], FUN = read.delim, header = T, stringsAsFactors = F)
names(degList) <- names(degfiles)

degList <- lapply(degList, function(dt) {
        symbol_col <- grep(pattern = "mgi*.*symbol", x = colnames(dt), ignore.case = T)
        dt <- dt[,-symbol_col]
        return(dt)
})
degList <- lapply(degList, function(dt) {
        logfc_col <- grep(pattern = "log", x = colnames(dt), ignore.case = T)
        pval_col <- grep(pattern = "p*.*value", x = colnames(dt), ignore.case = T)
        adjpval_col <- grep(pattern = "adj", x = colnames(dt), ignore.case = T)
        symbol_col <- grep(pattern = "hgnc*.*symbol", x = colnames(dt), ignore.case = T)
        cols <- c(logfc_col, pval_col, adjpval_col, symbol_col)
        colnames(dt)[cols] <- c("logFC", "pvalue", "adj.pvalue", "gene_symbol")
        return(dt)
})
degList <- lapply(degList, na.omit)
degList <- lapply(degList, unique)
degList <- lapply(degList, function(dt) {
        x <- dt[,c(3,5,6,7)]
        xx <- split(x = x[,-ncol(x)], f = x$gene_symbol)
        y <- lapply(xx, function(g) {
                if(nrow(g) > 1) {
                        peval <- which(g$adj.pvalue == min(g$adj.pvalue))
                        g <- g[peval,]
                }
                return(g)
        })
        y <- do.call("rbind", y)
        res <- data.frame(y, "gene_symbol" = row.names(y), row.names = NULL)
        return(res)
})

#############################
# PIE Plots
#############################
make.PIE <- function (deg, 
                      pie_title, 
                      sig_var,
                      logfc_var,
                      sig_threshold = 0.05, 
                      logfc_threshold = 1,
                      filter = c("both", "sig", "logfc"),
                      mode = c("simple", "detailed")
) 
{
     filter <- match.arg(arg = NULL, choices = filter)
     mode <- match.arg(arg = NULL, choices = mode)
     count_all <- nrow(deg)
     if (filter == "both") {
          count_eval <- deg[,sig_var] < sig_threshold & abs(deg[,logfc_var]) > logfc_threshold
          subtitle <- paste("DEG = ", sig_var, " < ", sig_threshold, "AND |logFC| > ", logfc_threshold)
     } else if (filter == "sig") {
          count_eval <- deg[,sig_var] < sig_threshold
          subtitle <- paste("DEG = ", sig_var, " < ", sig_threshold)
     } else if (filter == "logfc") {
          count_eval <- abs(deg[,logfc_var]) > logfc_threshold
          subtitle <- paste("|logFC| > ", logfc_threshold)
     }
     deg_count <- sum(count_eval)
     all_minus_deg <- count_all - deg_count
     if(mode == "simple") {
          table_count <- data.frame("group" = c("DEG", "not-DEG"), 
                                    "count" = c(deg_count, all_minus_deg), 
                                    stringsAsFactors = F)
     } else {
          count_up <- sum(deg[count_eval,logfc_var] > 0)
          count_down <- sum(deg[count_eval,logfc_var] < 0)
          table_count <- data.frame("group" = c("DEG_up", "DEG_down", "not-DEG"), 
                                    "count" = c(count_up, count_down, all_minus_deg), 
                                    stringsAsFactors = F)
     }
     
     bp <- ggplot (data = table_count, mapping = aes (x = "", y = count, fill=group)) + 
          geom_bar(width = 1, stat = "identity") + 
          coord_polar("y", start=0)
     blank_theme <- theme_minimal() +
          theme(
               axis.title.x = element_blank(),
               axis.title.y = element_blank(),
               panel.border = element_blank(),
               panel.grid = element_blank(),
               axis.ticks = element_blank(),
               plot.title = element_text(size = 14, face = "bold")
          )
     pie <- bp + blank_theme + theme(axis.text.x = element_blank()) +
          geom_text(aes(y = count/2 + c(0, cumsum(count)[-length(count)]), 
                        label = count), size = 5)
     pie <- pie + ggtitle(label = pie_title, subtitle = subtitle)
     return(pie)
     
}
threshold_cutoff <- 0.05
piePlots_simple <- lapply(names(degList), function(x, deg_l) {
     make.PIE(deg = deg_l[[x]],
              pie_title = x, 
              sig_var = "pvalue", 
              logfc_var = "logFC",
              sig_threshold = threshold_cutoff, 
              filter = "sig", mode = "simple")
}, deg_l = degList)
piePlots_detailed <- lapply(names(degList), function(x, deg_l) {
     make.PIE(deg = deg_l[[x]],
              pie_title = x, 
              sig_var = "pvalue", 
              logfc_var = "logFC",
              sig_threshold = threshold_cutoff, 
              filter = "sig", mode = "detailed")
}, deg_l = degList)

names(piePlots_simple) <- names(piePlots_detailed) <- names(degList)
i = 2
piePlots_simple <- piePlots_simple[i]
piePlots_detailed <- piePlots_detailed[i]

#############################
# Save Plots
#############################
ndir <- paste (bdir, "Figures", sep = "/")
if (!dir.exists(ndir)) {
     dir.create(ndir)   
}
ndir <- paste (ndir, "PiePlot", sep = "/")
if (!dir.exists(ndir)) {
     dir.create(ndir)   
}

filepath <- paste(ndir, "/", "simple_PiePlot.pdf", sep = "")
ggsave(filename = filepath, plot = piePlots_simple[[1]], width = 12, height = 12)

filepath <- paste(ndir, "/", "detailed_PiePlot.pdf", sep = "")
ggsave(filename = filepath, plot = piePlots_detailed[[1]], width = 12, height = 12)
