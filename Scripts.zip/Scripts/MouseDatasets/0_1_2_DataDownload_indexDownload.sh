#!/bin/bash
curl "ftp://ftp.ensembl.org/pub/release-96/fasta/mus_musculus/cdna/Mus_musculus.GRCm38.cdna.all.fa.gz" -o MODEL-AD_hAbeta_KI/musmusculus.fa.gz
