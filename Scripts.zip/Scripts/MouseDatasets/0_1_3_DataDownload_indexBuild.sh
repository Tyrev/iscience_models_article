#!/bin/bash
#source activate salmon
export PATH=$PATH:/mnt/hd/Marco/Dropbox/Salmon/salmon-latest_linux_x86_64/bin
cd /mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/MODEL-AD_hAbeta_KI
salmon index -t musmusculus.fa.gz -i musmusculus_index
#conda deactivate


