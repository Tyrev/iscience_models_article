#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer_mirror/")
library(tximport)
library(DESeq2)
library(org.Mm.eg.db)
library(org.Hs.eg.db)
library(foreach)

#############################
# Transcript database with Annotations
#############################
## 
library(GenomicFeatures)
txdb <- makeTxDbFromGFF(file = "/mnt/hd/Marco/Dropbox/Salmon/Mus.musculus_GRCm38/musmusculus.gtf.gz")
k <- keys(txdb, keytype = "TXNAME")
tx_map <- biomaRt::select(txdb, keys = k, columns = "GENEID", keytype = "TXNAME")
tx2gene <- tx_map

### Fixing the problem with transcript names - the hard way!
#library(tidyr)
#library(dplyr)
#quants <- read.delim2(file_path[1], stringsAsFactors = F)
#quants <- separate(data = quants, col = Name, into = c("TXNAME","Number"), remove = FALSE)
#quants <- left_join(quants, tx_map, by="TXNAME")
#tx2gene <- dplyr:::select(quants, Name, GENEID)

## Annotation 01
res <- mapIds(org.Mm.eg.db,
              keys = tx2gene$GENEID,
              column = "SYMBOL",
              keytype = "ENSEMBL",
              multiVals = "first")
res <- data.frame("ensembl_gene_id" = names(res), "mgi_symbol" = res, stringsAsFactors = F)
res <- unique(res)

## Annotation 02
mart.args = list(
        "biomart" = "ENSEMBL_MART_ENSEMBL",
        "dataset" = "hsapiens_gene_ensembl"
)
mart <- biomaRt::useMart(biomart = mart.args$biomart, dataset = mart.args$dataset)
martDtsets <- as.matrix(biomaRt::listDatasets(mart = mart), stringsAsFactors = F)
## Mus musculus Mart object
mm.Dtset <- martDtsets[grep("Mouse gene", martDtsets[,"description"], ignore.case = F), "dataset"]
mm.mart <- biomaRt::useMart(biomart = mart.args$biomart, dataset = mm.Dtset)
## Homo sapiens Mart object
hs.Dtset <- martDtsets[grep("Human genes", martDtsets[,"description"]), "dataset"]
hs.mart <- biomaRt::useMart(biomart = mart.args$biomart, dataset = hs.Dtset)
## annotation conversion
mm.attr <- c("mgi_symbol")
mm.filter <- "mgi_symbol"
mm.values <- na.omit(res$mgi_symbol)
hs.attr <- c("hgnc_symbol")
annotConv <- biomaRt::getLDS(attributes = mm.attr, 
                             filters = mm.filter, 
                             values = mm.values, 
                             mart = mm.mart, 
                             attributesL = hs.attr, 
                             martL = hs.mart)
featlist <- split(x = annotConv, f = annotConv$MGI.symbol)
featlist <- lapply(X = featlist, FUN = function (df) {
        if (length (df[,2]) > 1) {
                x1 <- unique (df[,-2,drop=F])
                x2 <- paste(df[,2], collapse = "/")
                x <- cbind (x1, x2)
                x <- sapply (x, as.character)
                names(x) <- colnames(df)
                return(x)
        }
        x <- unlist(df)
        return(x)
})
featlist <- do.call("rbind", featlist)
featlist <- unique(featlist)
featlist <- data.frame(featlist, stringsAsFactors = F, row.names = NULL)
annotExpanded <- merge(x = tx2gene, y = res, by.x = "GENEID", by.y = "ensembl_gene_id")
row.names(annotExpanded) <- annotExpanded$TXNAME
cl <- parallel::makeCluster(6)
doParallel::registerDoParallel(cl)
HGCNsymbol <- foreach(i = seq(nrow(annotExpanded)), .combine = c) %dopar% {
        r <- paste ("^", annotExpanded$mgi_symbol[i], "$", sep = "")
        r <- grep(pattern = r, x = annotConv$MGI.symbol)
        if (length(r) > 0) {
                x <- unique(annotConv$HGNC.symbol[r])
                names(x) <- annotExpanded$TXNAME[i]
        } else {
                x <- NA
                names(x) <- annotExpanded$TXNAME[i]
        }
        return(x)
}
parallel::stopCluster(cl)
HGCN_symbol <- data.frame("symbol" = HGCNsymbol, "tx" = names(HGCNsymbol), stringsAsFactors = F)
HGCN_symbol <- unique(na.omit(HGCN_symbol))
row.names(HGCN_symbol) <- HGCN_symbol$tx
annotExpanded$HGCN.symbol <- NA
annotExpanded[row.names(HGCN_symbol),"HGCN.symbol"] <- HGCN_symbol$symbol
annotExpanded <- annotExpanded[,c(2,1,3,4)]
annotExpanded <- unique (annotExpanded)
colnames(annotExpanded) <- c("TXNAME", "EMSEMBLID", "MGI_SYMBOL", "HGNC_SYMBOL")

write.table(x = annotExpanded, 
            file = "Mm_Annotation.txt", 
            sep = "\t")
