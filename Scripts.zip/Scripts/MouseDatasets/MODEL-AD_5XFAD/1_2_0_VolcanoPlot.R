#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("ggplot2", "reshape2"), repos = "http://lib.stat.cmu.edu/R/CRAN")

#############################
# Load Data
#############################
bdir <- paste(getwd(), "MODEL-AD_5XFAD", sep = "/")
fname <- paste(bdir, sep = "/")
degfiles <- grep(pattern = "_DEG.txt", x = dir(fname), ignore.case = T)
names(degfiles) <- gsub(pattern = "_DEG.txt", replacement = "", x = dir(fname)[degfiles])
fname <- paste(fname, dir(fname), sep = "/")
degList <- lapply(X = fname[degfiles], FUN = read.delim, header = T, stringsAsFactors = F)
names(degList) <- names(degfiles)

degList <- lapply(degList, function(dt) {
        symbol_col <- grep(pattern = "mgi*.*symbol", x = colnames(dt), ignore.case = T)
        dt <- dt[,-symbol_col]
        return(dt)
})
degList <- lapply(degList, function(dt) {
        logfc_col <- grep(pattern = "log", x = colnames(dt), ignore.case = T)
        pval_col <- grep(pattern = "p*.*value", x = colnames(dt), ignore.case = T)
        adjpval_col <- grep(pattern = "adj", x = colnames(dt), ignore.case = T)
        symbol_col <- grep(pattern = "hgnc*.*symbol", x = colnames(dt), ignore.case = T)
        cols <- c(logfc_col, pval_col, adjpval_col, symbol_col)
        colnames(dt)[cols] <- c("logFC", "pvalue", "adj.pvalue", "gene_symbol")
        return(dt)
})
degList <- lapply(degList, na.omit)
degList <- lapply(degList, unique)
degList <- lapply(degList, function(dt) {
        x <- dt[,c(3,5,6,7)]
        xx <- split(x = x[,-ncol(x)], f = x$gene_symbol)
        y <- lapply(xx, function(g) {
                if(nrow(g) > 1) {
                        peval <- which(g$adj.pvalue == min(g$adj.pvalue))
                        g <- g[peval,]
                }
                return(g)
        })
        y <- do.call("rbind", y)
        res <- data.frame(y, "gene_symbol" = row.names(y), row.names = NULL)
        return(res)
})

#############################
# Volcano Plots
#############################
make.volcano <- function(deg, 
                         volcano_title,
                         sig_var,
                         logfc_var,
                         sig_threshold = 0.05, 
                         logfc_threshold = 1,
                         filter = c("both", "sig", "logfc")) 
{
        filter <- match.arg(arg = NULL, choices = filter)
        if(filter == "both") {
                color_eval <- deg[,sig_var] < sig_threshold & abs(deg[,logfc_var]) > logfc_threshold
                subtitle <- paste("DEG = ", sig_var, " < ", sig_threshold, "AND |logFC| > ", logfc_threshold)
        } else if(filter == "sig") {
                color_eval <- deg[,sig_var] < sig_threshold
                subtitle <- paste("DEG = ", sig_var, " < ", sig_threshold)
        } else if(filter == "logfc") {
                color_eval <- abs(deg[,logfc_var]) > logfc_threshold
                subtitle <- paste("|logFC| > ", logfc_threshold)
        }
        color_point <- ifelse(color_eval, yes = "red", no = "gray")
        ggplot(data = deg, mapping = aes(x = eval(as.name(logfc_var)), y = -log10(eval(as.name(sig_var))))) + 
                labs(x = logfc_var, y = sig_var) +
                geom_point(size = 1.5, color = color_point) +
                ggtitle(label = volcano_title, subtitle = subtitle) +
                geom_hline(yintercept = -log10(sig_threshold), linetype = 2) +
                geom_vline(xintercept = c(-logfc_threshold, logfc_threshold), linetype = 2) +
                theme_bw()
}
volcanos <- lapply(names(degList), function(contrast, degs, sig_var, logfc_var, sig_threshold, filter) {
        deg <- degs[[contrast]]
        make.volcano(deg = deg, 
                     volcano_title = contrast,
                     sig_var = sig_var,
                     logfc_var = logfc_var,
                     sig_threshold = sig_threshold,
                     filter = filter)
}, degs = degList, sig_var = "pvalue", logfc_var = "logFC", sig_threshold = 0.05, filter = "sig")
names(volcanos) <- names(degList)

#############################
# Save Plots
#############################
ndir <- paste(bdir, "Figures", sep = "/")
if(!dir.exists(ndir)) {
        dir.create(ndir)   
}
ndir <- paste(ndir, "VolcanoPlots", sep = "/")
if(!dir.exists(ndir)) {
        dir.create(ndir)   
}
for(contrast in names(volcanos)) {
        filepath <- paste(ndir, "/", contrast, "_VolcanoPlot.pdf", sep = "")
        ggsave(filename = filepath, plot = volcanos[[contrast]], width = 12, height = 12)
}
