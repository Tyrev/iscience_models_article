#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("tximport",
                  "DESeq2",
                  "arrayQualityMetrics",
                  "AffyCompatible",
                  "GEOquery"), repos = "http://bioconductor.org/biocLite.R")

#############################
# Data
#############################
bdir <- paste(getwd(), "MODEL-AD_5XFAD/", sep = "/")
fname <- paste(bdir, "txi.RData", sep = "/")
load(fname)

processed_metadata <- read.delim(paste (bdir, "processed_metadata.txt", sep = "/"), stringsAsFactors=FALSE)

#############################
# Create dds object
#############################
samples <- processed_metadata
ddsTxi <- DESeqDataSetFromTximport(txi,
                                   colData = samples,
                                   design = ~ condition1)
ddsTxi <- DESeq2::estimateSizeFactors(ddsTxi)
ddsTxi <- DESeq2::estimateDispersions(ddsTxi)
dds <- ddsTxi

#############################
# Create eSet
#############################
## Pre-filtering the dataset
### count filter
count_filter <- row.names(tweeDEseq::filterCounts(counts(dds), mean.cpm.cutoff = 2))
dds <- dds[count_filter, ]
### regularized-logarithm transformation or rlog
rld <- rlog(dds, blind = FALSE)

## phenoData
phenoDat <- colData(dds)
phenoDat <- sapply(phenoDat@listData, as.character)
phenoDat <- data.frame(phenoDat, stringsAsFactors = F)
row.names(phenoDat) <- phenoDat[,2]
## assayData
assayDat <- assay(rld)
assayDat <- assayDat
ann <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/MODEL-AD_5XFAD/processed_annotation.txt", stringsAsFactors=FALSE)
featlist <- unique(ann[,-1])
featlist <- split (x = featlist, f = featlist$MGI_SYMBOL)
featlist <- lapply (X = featlist, FUN = function (df) {
     if (length (df[,3]) > 1) {
          x1 <- unique (df[,-3])
          x2 <- paste(unique(df[,3]), collapse = "/")
          x <- cbind (x1, x2)
          x <- sapply (x, as.character)
          names(x) <- colnames(df)
          return(x)
     }
     x <- unlist(df)
     return(x)
})
featlist <- do.call("rbind", featlist)
featureDat <- unique (featlist)
featureDat <- data.frame (featureDat, stringsAsFactors = F, row.names = NULL)
row.names(featureDat) <- featureDat$EMSEMBLID
featureDat <- featureDat[row.names(assayDat)[row.names(assayDat) %in% featureDat$EMSEMBLID],]

featureDat <- as(featureDat, "AnnotatedDataFrame")
phenoDat <- as(phenoDat, "AnnotatedDataFrame")
myEset <- ExpressionSet(assayData = assayDat[featureDat$EMSEMBLID,], phenoData = phenoDat, featureData = featureDat)

gse <- myEset

#############################
# Quality Control Processed
#############################
qc <- arrayQualityMetrics(expressionset = gse,
                          outdir = paste("MODEL-AD_5XFAD", "QC_Processed", sep = "/"),
                          do.logtransform = F,
                          force = T,
                          reporttitle = "QC_report",
                          intgroup = "condition1",
                          spatial = F)
qc_table <- qc$arrayTable
write.table(x = qc_table, file = paste("MODEL-AD_5XFAD", "QC_table.txt", sep = "/"), sep = "\t", row.names = F)
