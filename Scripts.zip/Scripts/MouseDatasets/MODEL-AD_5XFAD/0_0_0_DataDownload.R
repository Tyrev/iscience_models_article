#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("synapser",
                   "synapserutils"), 
                 repos = "http://bioconductor.org/biocLite.R")

#############################
# Download from Synapse
#############################
## Metadata processing
RNAseq_metadata <- read.csv("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/MODEL-AD_5XFAD/Metadata/MODEL-AD_5XFAD_biospecimen_metadata.csv", stringsAsFactors=FALSE, na.strings = "")
biospecimen_metadata <- read.csv("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/MODEL-AD_5XFAD/Metadata/MODEL-AD_5XFAD_biospecimen_metadata.csv", stringsAsFactors=FALSE, na.strings = "")
merge1 <- merge (RNAseq_metadata, unique (biospecimen_metadata))
merge1 <- merge1 [,c(1,2,4)]
individual_metadata <- read.csv("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/MODEL-AD_5XFAD/Metadata/MODEL-AD_5XFAD_individual_metadata.csv", stringsAsFactors=FALSE, na.strings = "")
merge2 <- merge (merge1, individual_metadata)
merge2 <- merge2[,c(1:3,5:7)]
merge2 <- unique (merge2)
merge2$specimenID <- toupper(merge2$specimenID)
merge2$specimenID <- gsub (pattern = "l|r", replacement = "", x = merge2$specimenID, ignore.case = T)
merge3 <- unique (merge2)
row.names (merge3) <- merge3$specimenID

## https://www.synapse.org/#!Synapse:syn16798191
synLogin("Tyrev", "mtv24fox")
synid <- c("5xFAD_12mon" = "syn18778597", 
           "5xFAD_4mon" = "syn17099434", 
           "5xFAD_8mon" = "syn17099433")
# entity_temp <- synGet(synid)
iterator <- list ()
for (i in 1:length (synid)) {
        x <- synGetChildren(synid[[i]], includeTypes = list("file", "folder"), sortBy = "NAME")
        iterator[[i]] <- as.list (x)
        names (iterator)[i] <- names (synid)[i]
}
iter1 <- list ()
for (i in 1:length (iterator)) {
        x <- lapply (iterator[[i]], function (i) do.call ("c", i))
        x <- do.call ("rbind", x)
        x <- x[,c("id", "name")]
        x[,2] <- paste (x[,2], names (iterator)[i], sep = "_")
        iter1[[i]] <- x
}
iter1 <- do.call ("rbind", iter1)

synid <- iter1[,1]
iterator <- list ()
for (i in 1:length (synid)) {
        x <- synGetChildren(synid[[i]], includeTypes = list("file", "folder"), sortBy = "NAME")
        iterator[[i]] <- as.list (x)
        names (iterator)[i] <- names (synid)[i]
}
iter2 <- list ()
for (i in 1:length (iterator)) {
        x <- lapply (iterator[[i]], function (i) do.call ("c", i))
        x <- do.call ("rbind", x)
        x <- x[,c("id", "name")]
        iter2[[i]] <- x
}
iter2 <- do.call ("rbind", iter2)

x <- NULL
for (r in 1:nrow (iter2)) {
     ri <- iter2[r,2]
     
     id <- strsplit (x = ri, split = "_")
     id <- id[[1]][[1]]
     
     x <- c(x, id)
}
rm (id, r, ri)
iter2 <- cbind (iter2, x)
keep_files <- merge (merge3, iter2, by.x = "specimenID", by.y = "x")

iter <- as.character (keep_files$id)

ndir <- paste (getwd(), "MODEL-AD_5XFAD", "Data_UnProcessed", sep = "/")
if (!dir.exists(ndir)) {
     dir.create(ndir)   
}
ndir <- paste (getwd(), "MODEL-AD_5XFAD", "Data_UnProcessed", "FASTQ", sep = "/")
if (!dir.exists(ndir)) {
     dir.create(ndir)   
}

for (f in 1:length (iter)) {
     synid <- iter[f]
     synapserutils::syncFromSynapse(entity = synid, 
                                    path = ndir,
                                    ifcollision = "overwrite.local")
}
