#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("RTN", "DESeq2"), 
                repos = "http://bioconductor.org/biocLite.R")

#############################
# Load Data
#############################
MRA_Vargas2018 <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/MRA_Vargas2018.txt", stringsAsFactors=FALSE)
iRegs <- dget("2_2_1_2_TilePlot_MRA_intersection.txt")

#############################
# Extract results from TNA
#############################
regExp <- paste("TNA.*", ".RData$", sep = "")
## REGULONS MODELS
models <- c("MODEL-AD_5XFAD", "MODEL-AD_hAbeta_KI", "MODEL_APP.PS1")
results <- list()
for(i in seq(models)) {
        model <- models[i]
        filename <- grep(pattern = regExp, dir(model), ignore.case = T)
        if(length(filename) == 1) {
                filepath <- paste(model, "/", dir(model)[filename], sep = "")
                load(filepath)
                results [[length(results) + 1]] <- tna@results$GSEA2.results$differential
                names(results)[length(results)] <- make.names(model)
                rm(tna, filename, filepath)
        } else {
                for(f in filename) {
                        filepath <- paste(model, "/", dir(model)[f], sep = "")
                        load(filepath)
                        results [[length(results) + 1]] <- tna@results$GSEA2.results$differential
                        m <- sub(pattern = "TNA_", replacement = "", x = basename(filepath))
                        m <- sub(pattern = ".RData", replacement = "", x = m)
                        m <- paste(model, m, sep = ".")
                        names(results)[length(results)] <- make.names(m)
                        rm(tna, f, filepath, m)
                }
        }
        rm(i)
}
models <- c("HumanDatasets/GSE39420/", "HumanDatasets/MergedSet/")
for(i in seq(models)) {
        model <- models[i]
        filename <- grep(pattern = regExp, dir(model), ignore.case = T)
        if(length(filename) == 1) {
                filepath <- paste(model, "/", dir(model)[filename], sep = "")
                load(filepath)
                results [[length(results) + 1]] <- tna@results$GSEA2.results$differential
                names(results)[length(results)] <- make.names(model)
                rm(tna, filename, filepath)
        } else {
                for(f in filename) {
                        filepath <- paste(model, "/", dir(model)[f], sep = "")
                        load(filepath)
                        results [[length(results) + 1]] <- tna@results$GSEA2.results$differential
                        m <- sub(pattern = "TNA_", replacement = "", x = basename(filepath))
                        m <- sub(pattern = ".RData", replacement = "", x = m)
                        m <- paste(model, m, sep = ".")
                        names(results)[length(results)] <- make.names(m)
                        rm(tna, f, filepath, m)
                }
        }
        rm(i)
}

results_sig <- lapply(results, function(x, iRegs) {
        x <- subset(x, subset = x$Regulon %in% iRegs)
        return(x)
}, iRegs = iRegs)

pval <- lapply(results_sig, function(x) {
     pval.res <- x$"Adjusted.Pvalue"
     names(pval.res) <- x$"Regulon"
     pval.res
})
es <- lapply(results_sig, function(x) {
     pval.res <- x$"Observed.Score"
     names(pval.res) <- x$"Regulon"
     pval.res
})

#############################
# Regulons DataFrame
#############################
# iRegs <- unique(do.call("c", lapply(pval, names)))
## Mapping
mlength <- length(iRegs)
rdf <- matrix(nrow = mlength, ncol = length(pval))
row.names(rdf) <- iRegs
colnames(rdf) <- names(pval)
for(r in seq(pval)) {
     for(g in names(pval[[r]])) {
          if(g %in% iRegs) {
               rdf[g, r] <- pval[[r]][g]
          }
     }
}
esdf <- matrix(nrow = mlength, ncol = length(es))
row.names(esdf) <- iRegs
colnames(esdf) <- names(es)
for(r in seq(es)) {
     for(g in names(es[[r]])) {
          if(g %in% iRegs) {
               esdf[g, r] <- es[[r]][g]
          }
     }
}
lrdf <- !rdf <= 0.05
frdf <- esdf
for(c in colnames(frdf)) {
     frdf[lrdf[,c],c] <- NA
}

#############################
# Tile plot
#############################
require(ggplot2)
require(reshape2)
lrdf.melt <- melt(frdf)
colnames(lrdf.melt) <- c("Regulon", "study", "ES")
colpal <- RColorBrewer::brewer.pal(11, "PRGn")
lrdf.melt [is.na(lrdf.melt$ES), "ES"] <- 0
lrdf.melt [lrdf.melt$ES == 0, "color"] <- colpal[6]
lrdf.melt [lrdf.melt$ES < 0, "color"] <- colpal[1]
lrdf.melt [lrdf.melt$ES > 0, "color"] <- colpal[11]
regorder <- iRegs[order(iRegs)]
tile.plot <- ggplot(lrdf.melt, aes(x = study, y = Regulon, fill = color)) + 
     geom_tile(colour = "black") + 
     scale_fill_manual(values = levels(as.factor(lrdf.melt$color)),
                       labels = c("active", "repressed", "ns"),
                       guide = guide_legend(title = "Regulon State",
                                            direction = "vertical",
                                            override.aes = list(color = "black", linetype = 1))) +
     coord_fixed(ratio = 0.5) +
     labs(x = "", y = "") + 
     scale_x_discrete(expand = c(0, 0)) +
     scale_y_discrete(expand = c(0, 0), limits = rev(regorder)) +
     theme(text = element_text(size = 20),
           axis.text = element_text(color = "black", size = 25),
           axis.text.x = element_text(angle = 60, hjust = 1),
           axis.title.y = element_text(color = "black", size = 30),
           legend.position = "top")

#############################
# save
#############################
fname <- paste("2_3_1_1_TilePlot_MoA.pdf", sep = "")
ggsave(filename = fname, plot = tile.plot, width = 25, height = 35, units = "cm", scale = 2)
