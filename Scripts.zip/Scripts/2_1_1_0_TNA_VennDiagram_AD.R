#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("reshape2", "VennDiagram", "gplots", "gridExtra"), repos = "http://lib.stat.cmu.edu/R/CRAN")

#############################
# Load Data
#############################
MRA_Vargas2018 <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/MRA_Vargas2018.txt", stringsAsFactors=FALSE)
iRegs <- MRA_Vargas2018$Regulon

#############################
# Extract results from TNA
#############################
regExp <- paste("TNA.*", ".RData$", sep = "")
## REGULONS MODELS
models <- c("MODEL-AD_5XFAD", "MODEL-AD_hAbeta_KI", "MODEL_APP.PS1")
results <- list()
for(i in seq(models)) {
        model <- models[i]
        filename <- grep(pattern = regExp, dir(model), ignore.case = T)
        if(length(filename) == 1) {
                filepath <- paste(model, "/", dir(model)[filename], sep = "")
                load(filepath)
                results [[length(results) + 1]] <- tna@results$MRA.results
                names(results)[length(results)] <- make.names(model)
                rm(tna, filename, filepath)
        } else {
                for (f in filename) {
                        filepath <- paste(model, "/", dir(model)[f], sep = "")
                        load(filepath)
                        results [[length(results) + 1]] <- tna@results$MRA.results
                        m <- sub(pattern = "TNA_", replacement = "", x = basename(filepath))
                        m <- sub(pattern = ".RData", replacement = "", x = m)
                        m <- paste(model, m, sep = ".")
                        names(results)[length(results)] <- make.names(m)
                        rm(tna, f, filepath, m)
                }
        }
        rm(i)
}
models <- c("HumanDatasets/GSE39420/", "HumanDatasets/MergedSet/")
for(i in seq(models)) {
        model <- models[i]
        filename <- grep(pattern = regExp, dir(model), ignore.case = T)
        if(length(filename) == 1) {
                filepath <- paste(model, "/", dir(model)[filename], sep = "")
                load(filepath)
                results [[length(results) + 1]] <- tna@results$MRA.results
                names(results)[length(results)] <- make.names(model)
                rm(tna, filename, filepath)
        } else {
                for (f in filename) {
                        filepath <- paste(model, "/", dir(model)[f], sep = "")
                        load(filepath)
                        results [[length(results) + 1]] <- tna@results$MRA.results
                        m <- sub(pattern = "TNA_", replacement = "", x = basename(filepath))
                        m <- sub(pattern = ".RData", replacement = "", x = m)
                        m <- paste(model, m, sep = ".")
                        names(results)[length(results)] <- make.names(m)
                        rm(tna, f, filepath, m)
                }
        }
        rm(i)
}

threshold_cutoff <- 0.05
results_sig <- lapply(results, function(x, iRegs, threshold_cutoff) {
        # x <- x[iRegs,]
        x <- subset (x, subset = x$Adjusted.Pvalue < threshold_cutoff)
        return(x)
}, iRegs = iRegs, threshold_cutoff = threshold_cutoff)

#############################
# Venn Diagram
#############################
listSYMBOL <- lapply(X = results_sig, function(x) {
        x$Regulon
})
listSYMBOL <- lapply(listSYMBOL, unique)
a1 <- length(x = listSYMBOL[[1]])
a2 <- length(x = listSYMBOL[[2]])
a3 <- length(x = listSYMBOL[[3]])
a4 <- length(x = listSYMBOL[[4]])
a5 <- length(x = listSYMBOL[[5]])
n12 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[2]]))
n13 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[3]]))
n14 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[4]]))
n15 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[5]]))
n23 <- length(intersect(listSYMBOL[[2]], listSYMBOL[[3]]))
n24 <- length(intersect(listSYMBOL[[2]], listSYMBOL[[4]]))
n25 <- length(intersect(listSYMBOL[[2]], listSYMBOL[[5]]))
n34 <- length(intersect(listSYMBOL[[3]], listSYMBOL[[4]]))
n35 <- length(intersect(listSYMBOL[[3]], listSYMBOL[[5]]))
n45 <- length(intersect(listSYMBOL[[4]], listSYMBOL[[5]]))
n123 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]])) == 3)
n124 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[4]])) == 3)
n125 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[5]])) == 3)
n134 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[3]], listSYMBOL[[4]])) == 3)
n135 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[3]], listSYMBOL[[5]])) == 3)
n145 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[4]], listSYMBOL[[5]])) == 3)
n234 <- sum(table(c(listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[4]])) == 3)
n235 <- sum(table(c(listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[5]])) == 3)
n245 <- sum(table(c(listSYMBOL[[2]], listSYMBOL[[4]], listSYMBOL[[5]])) == 3)
n345 <- sum(table(c(listSYMBOL[[3]], listSYMBOL[[4]], listSYMBOL[[5]])) == 3)
n1234 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[4]])) == 4)
n1235 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[5]])) == 4)
n1245 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[4]], listSYMBOL[[5]])) == 4)
n1345 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[3]], listSYMBOL[[4]], listSYMBOL[[5]])) == 4)
n2345 <- sum(table(c(listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[4]], listSYMBOL[[5]])) == 4)
n12345 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[4]], listSYMBOL[[5]])) == 5)
# vennPlot <- draw.triple.venn(area1 = a1, 
#                              area2 = a2,
#                              area3 = a3,
#                              n12 = n12,
#                              n23 = n23,
#                              n13 = n13,
#                              n123 = n123,
#                              scaled = F,
#                              category = c(names(listSYMBOL)[1], 
#                                           names(listSYMBOL)[2], 
#                                           names(listSYMBOL)[3]), 
#                              lty = 1,
#                              fill = c("pink1", "skyblue", "orange"),
#                              cat.cex = c (2, 2, 2),
#                              cat.pos = c(0, 0, 180),
#                              cat.dist = c(0.02, 0.02, 0.02),
#                              cat.just = list(c(0.9, 1), 
#                                              c(0.4, 1), 
#                                              c(0.5, 0)),
#                              int = F)
# vennPlot <- draw.quad.venn(area1 = a1,
#                            area2 = a2,
#                            area3 = a3,
#                            area4 = a4,
#                            n12 = n12,
#                            n13 = n13,
#                            n14 = n14,
#                            n23 = n23,
#                            n24 = n24,
#                            n34 = n34,
#                            n123 = n123,
#                            n124 = n124,
#                            n134 = n134,
#                            n234 = n234,
#                            n1234 = n1234,
#                            scaled = F,
#                            category = c(names(listSYMBOL)[1],
#                                         names(listSYMBOL)[2],
#                                         names(listSYMBOL)[3],
#                                         names(listSYMBOL)[4]),
#                            lty = 1,
#                            cex = rep(3, 15),
#                            fill = c("pink1", "skyblue", "orange", "lightblue"),
#                            cat.cex = c (2, 2, 2, 2),
#                            cat.pos = c(0, 0, 0, 0),
#                            cat.dist = c(0.2, 0.2, 0.1, 0.1),
#                            cat.just = c(list(c(0.85, 0.5)),
#                                         list(c(0.55, 0.5)),
#                                         rep(list(c(0.5, 0.5)), 2)),
#                            int = F)
vennPlot <- draw.quintuple.venn(area1 = a1,
                                area2 = a2,
                                area3 = a3,
                                area4 = a4,
                                area5 = a5,
                                n12 = n12,
                                n13 = n13,
                                n14 = n14,
                                n15 = n15,
                                n23 = n23,
                                n24 = n24,
                                n25 = n25,
                                n34 = n34,
                                n35 = n35,
                                n45 = n45,
                                n123 = n123,
                                n124 = n124,
                                n125 = n125,
                                n134 = n134,
                                n135 = n135,
                                n145 = n145,
                                n234 = n234,
                                n235 = n235,
                                n245 = n245,
                                n345 = n345,
                                n1234 = n1234,
                                n1235 = n1235,
                                n1245 = n1245,
                                n1345 = n1345,
                                n2345 = n2345,
                                n12345 = n12345,
                                scaled = F,
                                category = c(names(listSYMBOL)[1],
                                             names(listSYMBOL)[2],
                                             names(listSYMBOL)[3],
                                             names(listSYMBOL)[4],
                                             names(listSYMBOL)[5]),
                                lty = 1,
                                # cex = rep(4, 15),
                                fill = c("pink1", "skyblue", "orange", "lightblue", "gray"),
                                cat.cex = c (2, 2, 2, 2, 2),
                                cat.pos = c(0, 0, 0, 0, 0),
                                cat.dist = c(0.2, 0.2, 0.1, 0.1, 0.1),
                                cat.just = c(list(c(0.85, 0.5)),
                                             list(c(0.55, 0.5)),
                                             rep(list(c(0.5, 0.5)), 3)),
                                int = F)

#############################
# Save Plots
#############################
fname <- "2_1_1_1_VennDiagram_MRA_AD.pdf"
pdf (file = fname, width = 30, height = 15)
grid.arrange(gTree(children = vennPlot), 
             bottom = textGrob(paste("MRA = adj.pvalue < ", threshold_cutoff, sep = ""),
                               gp = gpar(fontsize =25, font = 8)))
dev.off()
