#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("reshape2"), repos = "http://lib.stat.cmu.edu/R/CRAN")

#############################
# Custom Function
#############################
## extract.intersections ####
# ARGUMENTS -- combination_matrix (matrix), symbolsList (list)
extract.intersections <- function (combination_matrix, symbolsList) {
        tcomb <- t(combination_matrix)
        tcomb <- data.frame(tcomb, stringsAsFactors = F)
        tcomb$intersection_count <- NA
        m <- (ncol(tcomb) - 1)
        if (m == 2) {
                for (r in seq(nrow(tcomb))) {
                        x <- tcomb[r,1]
                        y <- tcomb[r,2]
                        tcomb$intersection_count[r] <- length(intersect(x = symbolsList[[x]], y = symbolsList[[y]]))
                        rm(x, y, r)
                }
        } else {
                for (r in seq(nrow(tcomb))) {
                        s <- unlist(tcomb[r,1:m, drop = F])
                        symbs <- symbolsList[s]
                        symbs <- do.call("c", symbs)
                        symbs <- table(symbs)
                        tcomb$intersection_count[r] <- sum(symbs == m)
                        rm(s, symbs, r)
                }
        }
        return(tcomb)
}
#############################
## combinationDF ############
# ARGUMENTS -- combM_intersects (data.frame), index_vec (character)
#       > index_vec -- named character
combinationDF <- function(combM_intersects, index_vec) {
        m <- ncol(combM_intersects) - 1
        comb_df <- matrix(nrow = nrow(combM_intersects), 
                          ncol = 2, 
                          dimnames = list("row" = NULL, 
                                          "col" = c("combination_indexed", 
                                                    "intersection_count")))
        for (r in seq(nrow(combM_intersects))) {
                row_comb <- unlist(combM_intersects[r,1:m])
                row_comb <- paste(index_vec[row_comb], collapse = "|")
                comb_df[r,1] <- row_comb
                comb_df[r,2] <- combM_intersects[r,(m+1)]
        }
        return(comb_df)
}
#############################

#############################
# Load Data
#############################
FEA_GO <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/FEA/DEG/FEA_GO.txt", 
                       stringsAsFactors=FALSE)
feaList <- split(x = FEA_GO, f = FEA_GO$study)

#############################
# Data Frames
#############################
listSYMBOL <- lapply(feaList, function(x) x$ID)
listSYMBOL <- lapply(listSYMBOL, na.omit)
listSYMBOL <- lapply(listSYMBOL, unique)
degUnion <- do.call("c", listSYMBOL)
degUnion <- unique(degUnion)
names(degUnion) <- degUnion

## Intersection DF extended
### Gene x Study - Logical Assignments
intersectDF_extended <- as.matrix(degUnion)
colnames(intersectDF_extended) <- "GO"
intersectDF_extended <- data.frame(intersectDF_extended, stringsAsFactors = F)
intersectDF_extended <- intersectDF_extended[order(intersectDF_extended$GO),,drop=F]
for (col in seq(listSYMBOL)) {
        intersectDF_extended[[names(listSYMBOL)[col]]] <- intersectDF_extended$GO %in% listSYMBOL[[col]]
}

## Intersectin DF simple
### Study | Study Index | Combinatin | Intersection Count
studies_vec <- 1:length(listSYMBOL)
names(studies_vec) <- names(listSYMBOL) 
studies_df <- data.frame("study" = names(listSYMBOL), "index" = studies_vec, stringsAsFactors = F)

ncomb2 <- combn(x = names(listSYMBOL), m = 2)
comb2_intersect <- extract.intersections(ncomb2, listSYMBOL)
ncomb3 <- combn(x = names(listSYMBOL), m = 3)
comb3_intersect <- extract.intersections(ncomb3, listSYMBOL)
ncomb4 <- combn(x = names(listSYMBOL), m = 4)
comb4_intersect <- extract.intersections(ncomb4, listSYMBOL)
ncomb5 <- combn(x = names(listSYMBOL), m = 5)
comb5_intersect <- extract.intersections(ncomb5, listSYMBOL)

comb_dfList <- list(comb2_intersect,
                    comb3_intersect,
                    comb4_intersect,
                    comb5_intersect
)
comb_dfList <- lapply(comb_dfList, combinationDF, index_vec = studies_vec)
comb_df <- do.call("rbind", comb_dfList)

intersectDF_simple <- matrix(nrow = (nrow(studies_df) + nrow(comb_df)),
                             ncol = 4,
                             dimnames = list("row" = NULL,
                                             "col" = c(colnames(studies_df),
                                                       colnames(comb_df)
                                             )))
intersectDF_simple[1:nrow(studies_df), 1] <- studies_df$study
intersectDF_simple[1:nrow(studies_df), 2] <- studies_df$index
intersectDF_simple[(nrow(studies_df) + 1):nrow(intersectDF_simple), 3] <- comb_df[,1]
intersectDF_simple[(nrow(studies_df) + 1):nrow(intersectDF_simple), 4] <- comb_df[,2]

#############################
# Save
#############################
ndir <- paste(getwd(), "FEA", sep = "/")
if(!dir.exists(ndir)) {
        dir.create(ndir)
}
ndir <- paste(ndir, "DEG", sep = "/")
if(!dir.exists(ndir)) {
        dir.create(ndir)
}

fname <- paste(ndir, "/1_1_1_IntersectionsTable_DEG_GO_extended.txt", sep = "")
write.table(x = intersectDF_extended, file = fname, sep = "\t", row.names = F)

fname <- paste(ndir, "/1_1_2_IntersectionsTable_DEG_GO_simple.txt", sep = "")
write.table(x = intersectDF_simple, file = fname, sep = "\t", row.names = F)
