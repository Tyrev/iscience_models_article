#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("RTN", "DESeq2"), 
                repos = "http://bioconductor.org/biocLite.R")

#############################
# Load Data
#############################
MRA_Vargas2018 <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/MRA_Vargas2018.txt", stringsAsFactors=FALSE)
iRegs <- MRA_Vargas2018$Regulon

#############################
# Extract results from TNA
#############################
regExp <- paste("TNA.*", ".RData$", sep = "")
## REGULONS MODELS
models <- c("MODEL-AD_5XFAD", "MODEL-AD_hAbeta_KI", "MODEL_APP.PS1")
results <- list()
for(i in seq(models)) {
        model <- models[i]
        filename <- grep(pattern = regExp, dir(model), ignore.case = T)
        if(length(filename) == 1) {
                filepath <- paste(model, "/", dir(model)[filename], sep = "")
                load(filepath)
                results [[length(results) + 1]] <- tna@results$MRA.results
                names(results)[length(results)] <- make.names(model)
                rm(tna, filename, filepath)
        } else {
                for(f in filename) {
                        filepath <- paste(model, "/", dir(model)[f], sep = "")
                        load(filepath)
                        results [[length(results) + 1]] <- tna@results$MRA.results
                        m <- sub(pattern = "TNA_", replacement = "", x = basename(filepath))
                        m <- sub(pattern = ".RData", replacement = "", x = m)
                        m <- paste(model, m, sep = ".")
                        names(results)[length(results)] <- make.names(m)
                        rm(tna, f, filepath, m)
                }
        }
        rm(i)
}
models <- c("HumanDatasets/GSE39420/", "HumanDatasets/MergedSet/")
for(i in seq(models)) {
        model <- models[i]
        filename <- grep(pattern = regExp, dir(model), ignore.case = T)
        if(length(filename) == 1) {
                filepath <- paste(model, "/", dir(model)[filename], sep = "")
                load(filepath)
                results [[length(results) + 1]] <- tna@results$MRA.results
                names(results)[length(results)] <- make.names(model)
                rm(tna, filename, filepath)
        } else {
                for(f in filename) {
                        filepath <- paste(model, "/", dir(model)[f], sep = "")
                        load(filepath)
                        results [[length(results) + 1]] <- tna@results$MRA.results
                        m <- sub(pattern = "TNA_", replacement = "", x = basename(filepath))
                        m <- sub(pattern = ".RData", replacement = "", x = m)
                        m <- paste(model, m, sep = ".")
                        names(results)[length(results)] <- make.names(m)
                        rm(tna, f, filepath, m)
                }
        }
        rm(i)
}

threshold_cutoff <- 0.05
results_sig <- lapply(results, function(x, iRegs, threshold_cutoff) {
        # x <- x[iRegs,]
        x <- subset (x, subset = x$Adjusted.Pvalue < threshold_cutoff)
        return(x)
}, iRegs = iRegs, threshold_cutoff = threshold_cutoff)
listSYMBOL <- lapply(X = results_sig, function(x) {
        x$Regulon
})
listSYMBOL <- lapply(listSYMBOL, unique)
iRegs <- table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]], listSYMBOL[[4]], listSYMBOL[[5]]))
iRegs <- names(iRegs)[iRegs>=4]
results_sig <- lapply(results_sig, function(x, iRegs) {
        x <- x[iRegs,]
}, iRegs = iRegs)

pval <- lapply(results_sig, function(x) {
        pval.res <- x$"Adjusted.Pvalue"
        names(pval.res) <- x$"Regulon"
        pval.res
})

#############################
# Regulons DataFrame
#############################
# iRegs <- unique(do.call("c", lapply(pval, names)))
## Mapping
mlength <- length(iRegs)
rdf <- matrix(nrow = mlength, ncol = length(pval))
row.names(rdf) <- iRegs
colnames(rdf) <- names(pval)
for(r in seq(pval)) {
        for(g in names(pval[[r]])) {
                if(g %in% iRegs) {
                        rdf[g, r] <- pval[[r]][g]
                }
        }
}
frdf <- rdf

#############################
# Tile plot
#############################
require(ggplot2)
require(reshape2)
lrdf.melt <- melt(frdf)
colnames(lrdf.melt) <- c("Regulon", "study", "Adjusted.Pvalue")
if(any(is.na(lrdf.melt$Adjusted.Pvalue))) {
        lrdf.melt$Adjusted.Pvalue [is.na(lrdf.melt$Adjusted.Pvalue)] <- 1
}
colpal <- RColorBrewer::brewer.pal(9, "Reds")
lrdf.melt [lrdf.melt$Adjusted.Pvalue > 0.05, "color"] <- "white"
lrdf.melt [lrdf.melt$Adjusted.Pvalue <= 0.05, "color"] <- colpal[5]
lrdf.melt [lrdf.melt$Adjusted.Pvalue <= 0.01, "color"] <- colpal[7]
lrdf.melt [lrdf.melt$Adjusted.Pvalue <= 0.005, "color"] <- colpal[9]
regorder <- row.names(rdf)[order(row.names(rdf))]
tile.plot <- ggplot(lrdf.melt, aes(x = study, y = Regulon, fill = color)) + 
        geom_tile(colour = "black") + 
        scale_fill_manual(values = levels(as.factor(lrdf.melt$color)),
                           labels = c("0.005", "0.01", "0.05", "ns"),
                           guide = guide_legend(title = "adj. p-value cutoff",
                                                override.aes = list(color = "black", linetype = 1))) +
        coord_fixed(ratio = 0.5) +
        labs(x = "", y = "") + 
        scale_x_discrete(expand = c(0, 0)) +
        scale_y_discrete(expand = c(0, 0), limits = rev(regorder)) +
        theme(axis.text = element_text(color = "black", size = 25),
               axis.text.x = element_text(angle = 60, hjust = 1))

#############################
# save
#############################
fname <- paste("2_2_1_1_TilePlot_MRA.pdf", sep = "")
ggsave(filename = fname, plot = tile.plot, width = 25, height = 30, units = "cm", scale = 2)
fname <- paste("2_2_1_2_TilePlot_MRA_intersection.txt")
dput(x = iRegs, file = fname)
