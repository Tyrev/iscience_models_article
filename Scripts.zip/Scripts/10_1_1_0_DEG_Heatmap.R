#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("reshape2", "ggplot2", "gridExtra"), repos = "http://lib.stat.cmu.edu/R/CRAN")

#############################
# Load Data
#############################
degList <- list()
degList[["MODEL-AD_5XFAD"]] <- read.delim(file = "MODEL-AD_5XFAD/hemizygous-WT_DEG.txt", stringsAsFactors = F)
degList[["MODEL-AD_hAbeta_KI_homozygous_22months-WT_22months"]] <- read.delim(file = "MODEL-AD_hAbeta_KI/homozygous_22months-WT_22months_DEG.txt", stringsAsFactors = F)
degList[["MODEL_APP.PS1"]] <- read.delim(file = "MODEL_APP.PS1/APPPS1-WT_DEG.txt", stringsAsFactors = F)
degList[["Human_EOAD"]] <- read.delim(file = "HumanDatasets/MergedSet/AD_early-CONTROL_early_DEG.txt", stringsAsFactors = F)
degList[["Human_LOAD"]] <- read.delim(file = "HumanDatasets/MergedSet/AD_late-CONTROL_late_DEG.txt", stringsAsFactors = F)

#############################
#
#############################
threshold_cutoff <- 0.05
degList_logfc <- lapply(X = degList, function(deg, threshold_cutoff) {
        symbol_col <- grep(pattern = "hgnc", x = colnames(deg), ignore.case = T)
        if(!any(symbol_col)) {
                symbol_col <- grep(pattern = "symbol", x = colnames(deg), ignore.case = T)
        }
        sig_col <- grep(pattern = "value", x = colnames(deg), ignore.case = T)
        x <- subset(deg[,c(3,symbol_col)], subset = deg[,sig_col] < threshold_cutoff)
        x <- na.omit(x)
        xx <- split(x = x, f = x[,2])
        xx <- lapply(xx, function(y) {
                symb <- unique(y[,2])
                data.frame("symbol" = symb, "log2FoldChange" = mean(y[,1]), row.names = symb)
        })
        xx <- do.call("rbind", xx)
        return(xx)
}, threshold_cutoff = threshold_cutoff)
listSYMBOL <- lapply(degList_logfc, function(x) x$symbol)
hssymbol <- unique(unlist(listSYMBOL))

mtx <- matrix(data = NA, nrow = length(hssymbol), ncol = length(listSYMBOL), 
              dimnames = list("row" = hssymbol, "col" = names(listSYMBOL)))
for(cn in colnames(mtx)) {
        sym <- degList_logfc[[cn]][,1]
        mtx[sym,cn] <- degList_logfc[[cn]][,2]
}
mtx <- data.frame("symbol" = row.names(mtx), mtx, stringsAsFactors = F)
dlogfc <- as.matrix(mtx[,-1])

#############################
#
#############################
dlogfc_melt <- melt(dlogfc)
tile.plot <- ggplot(dlogfc_melt, aes(x = Var2, y = Var1, fill = value)) + 
        geom_tile() +
        labs(y = "") +
        scale_fill_gradient2(midpoint = 1, low = "green", mid = "black", high = "yellow",
                             na.value = "white", breaks = seq(from = -2, to = 4, by = 2)) +
        theme(axis.text = element_text(color = "black", size = 25),
              axis.text.x = element_text(angle = 60, hjust = 1))

#############################
# Save Plots
#############################
fname <- "0_1_1_0_Heatmap_DEG.pdf"
ggsave(filename = fname, plot = tile.plot, width = 10, height = 30, dpi = 1500)
