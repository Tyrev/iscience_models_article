#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
cran.pkgs <- c("rJava", "RCurl", "reshape2", "ggplot2", "RColorBrewer")
bioc.pkgs <- c("RTN", "RedeR", "STRINGdb", "igraph")
# ## installing
# install.packages(cran.pkgs)
# BiocManager::install(bioc.pkgs)
## loading
for(pkg in c(cran.pkgs, bioc.pkgs)) {
        library(package = pkg, character.only = T)
}

#############################
# Custom Function
#############################
## combine string scores
combinescores <- function(dat, evidences = "all", confLevel = 0.7){
        if(evidences[1] == "all"){
                edat <- dat[,-c(1,2,ncol(dat))]
        } else {
                if(!all(evidences%in%colnames(dat))){
                        stop("NOTE: one or more 'evidences' not listed in 'dat' colnames!")
                }
                edat <- dat[,evidences]
        }
        edat <- edat/1000
        edat <- 1-edat
        sc <- sapply(1:nrow(edat), function(i){
                tp <- edat[i,]
                1-prod(tp)
        })
        dat <- cbind(dat[,c(1,2)], combined_score = sc)
        idx <- dat$combined_score > confLevel
        dat <- dat[idx,]
        return(dat)
}
### for undirected networks the degree of a node i is just the number of connections it has.
# und.degree <- function(from.to.data) {
#      g <- unique(c(from.to.data[,1], from.to.data[,2]))
#      dgr <- c(from.to.data[,1], from.to.data[,2])
#      dgr <- as.data.frame(table(dgr))
#      node.degree <- dgr[,2]
#      names(node.degree) <- dgr[,1]
#      avg.degree <- sum(node.degree)/length(node.degree)
#      list("degree.per.node" = node.degree, "avg.degree" = avg.degree)
# }

#############################
# Load Data
#############################
IntersectionsTable_DEG_AD_extended <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/1_1_2_1_IntersectionsTable_DEG_AD_extended.txt")
intersectTable <- IntersectionsTable_DEG_AD_extended[,-1]
row.names(intersectTable) <- IntersectionsTable_DEG_AD_extended$SYMBOL
coi <- c("MODEL_APP.PS1",
         "Human_EOAD")
## only in model
ev1 <- intersectTable[,-which(colnames(intersectTable) %in% coi[2])]
ev1 <- ev1[ev1[,coi[1]],]
ev1 <- ev1[apply(ev1, 1, sum) == 1,]
ev1 <- row.names(ev1)
## only in disease
ev2 <- intersectTable[,-which(colnames(intersectTable) %in% coi[1])]
ev2 <- ev2[ev2[,coi[2]],]
ev2 <- ev2[apply(ev2, 1, sum) == 1,]
ev2 <- row.names(ev2)
## intersect of ONLY model + disease
listSYMBOL <- list(intersect(ev1, ev2))
listSYMBOL <- lapply(listSYMBOL, na.omit)
listSYMBOL <- lapply(listSYMBOL, unique)

geneList <- data.frame("genes" = listSYMBOL[[1]])

#############################
# Start STRING port
#############################
string_db <- STRINGdb$new(version = "11", species = 9606, score_threshold = 0, input_directory = "")

## map genelist onto stringdb
string.map <- string_db$map(geneList, "genes", removeUnmappedRows = T, takeFirst = T)
string.map$ENSP <- substr(string.map$STRING_id, 6, 1000)
string.map[string.map$ENSP %in% string.map$ENSP[duplicated(string.map$ENSP)],] ## ENSP annotated to more than 1 gene symbol
### remove duplicated ENSP
string.map <- string.map[!duplicated(string.map$ENSP), ]
row.names(string.map) <- string.map$ENSP

## get stringdb interactions
string.dat <- string_db$get_interactions(string.map$STRING_id)
### remove species stringdb identification
string.dat$from <- substr(string.dat$from, 6, 1000)
string.dat$to <- substr(string.dat$to, 6, 1000)
### substitute ENSP annotation for symbol annotation
string.dat$from <- string.map[string.dat$from, "genes"]
string.dat$to <- string.map[string.dat$to, "genes"]

# graphData <- combinescores(string.dat, confLevel = 0.95)
graphData <- string.dat
graphData$combined_score <- graphData$combined_score/1000
graphData <- graphData[graphData$combined_score>0.4,]

#############################
## Graph
#############################
## build graph
graph <- graph_from_data_frame(d = unique(graphData), directed = F)
## build subgraph
# dgr <- degree(graph)
# dgr <- dgr[order(dgr, decreasing = T)]
# dgr <- dgr[dgr > 2]
# subG <- make_ego_graph(graph = graph, nodes = names(dgr), order = 50)
# subNodes <- lapply(subG, function(g) {
#         as_data_frame(x = g, what = "edges")
# })
# subNodes <- unique(Reduce("rbind", subNodes))
# subNodes <- unique(Reduce("c", subNodes[,1:2]))
# subG <- induced_subgraph(graph = graph, v = subNodes)
# graph <- subG
##
graphMap <- as_data_frame(graph, what = "both")
VgraphMap <- graphMap$vertices
EgraphMap <- graphMap$edges
## Map graph
### Add Node Degree
dgr <- degree(graph)
VgraphMap[names(dgr), "degree"] <- dgr
### Add logFC
graph <- att.mapv(g = graph, dat = VgraphMap)
graph <- att.mape(g = graph, dat = EgraphMap)
### nodeColor to degree
palfunc <- colorRampPalette(c("white", "#ffaec0", "red"))
graph <- att.setv(g = graph, from = "degree", to = "nodeColor", nquant = 10,
                  cols = palfunc(nrow(VgraphMap)), getleg = T, roundleg = 1)
### nodeSize to degree
graph <- att.setv(g = graph, from = "degree", to = "nodeSize", nquant = 10, getleg = T)
### edgeWidth to jaccardcoefficient
graph <- att.sete(g = graph, from = "combined_score", to = "edgeWidth", nquant = 5, 
                  xlim = c(1,4,0.5), roundleg = 3)

## RedeR
rdp <- RedPort()
calld(rdp)
addGraph(obj = rdp, g = graph, gscale = 80, zoom = 20)

### Legend
gAttr <- graph.attributes(graph)
addLegend.color(obj = rdp, 
                type = "node",
                colvec = gAttr$legNodeColor$scale,
                labvec = gAttr$legNodeColor$legend,
                title = "Node Degree", 
                vertical = T,
                position = "bottomright",
                ftsize = 20, bend = 0.5)
addLegend.size(obj = rdp, 
               type = "node",
               sizevec = gAttr$legNodeSize$scale,
               labvec = gAttr$legNodeSize$legend,
               title = "Node Degree", 
               vertical = F,
               position = "bottomleft",
               ftsize = 20, intersp = 50, dxborder = 20, dxtitle = 50)
addLegend.size(obj = rdp, 
               type = "edge",
               sizevec = gAttr$legEdgeWidth$scale,
               labvec = gAttr$legEdgeWidth$legend,
               title = "Combined_Score", 
               vertical = T,
               position = "topright",
               ftsize = 20, intersp = 50, dyborder = 10)

#############################
# Graph Info Saves
#############################
graphSave <- getGraph(rdp, attribs = "all")
graphMapSave <- get.data.frame(x = graphSave, what = "both")
VgraphSave <- merge(graphMapSave$vertices, VgraphMap)
row.names(VgraphSave) <- VgraphSave$name
fname <- paste(getwd(), "4_3_1_PPI_Network_nodeInfo_EOAD.txt", sep = "/")
write.table(x = VgraphSave, file = fname, sep = "\t", row.names = F)
# EgraphSave <- graphMapSave$edges
# EgraphSave <- cbind(EgraphSave, EgraphMap[,-c(1:2)])
# fname <- paste(getwd(), GEOID, "PPI_Network_edgeInfo.txt", sep = "/")
# write.table(x = EgraphSave, file = fname, sep = "\t", row.names = F)