## original R code from viper package (msviper function)
## -----
## adapted by Marco A. De Bastiani: msviper_adapted 2019
###############
# msviper_adapted -- This function performs MAster Regulator INference Analysis with parallelization
###############
msviper_adapted <- function (ges, 
                             regulon, 
                             nullmodel = NULL, 
                             pleiotropy = FALSE, 
                             minsize = 25, 
                             adaptive.size = FALSE, 
                             ges.filter = TRUE, 
                             synergy = 0, 
                             level = 10, 
                             pleiotropyArgs = list(regulators = 0.05, 
                                                   shadow = 0.05, 
                                                   targets = 10, 
                                                   penalty = 20, 
                                                   method = "adaptive"), 
                             cores = 1, verbose = TRUE
){
        require(viper)
        viper_env <- environment(viper)
        if (is.vector(ges)) {
                ges <- matrix(ges, length(ges), 1, dimnames = list(names(ges), NULL))
        }
        regulon <- viper_env$updateRegulon(regulon)
        if (ges.filter) { 
                ges <- viper_env$filterRowMatrix(ges, 
                                                 rownames(ges) %in% unique(c(names(regulon), 
                                                                             unlist(lapply(regulon, function(x) {
                                                                                     names(x$tfmode)
                                                                                     }), use.names = FALSE))
                                                 )
                )
        }
        regulon <- lapply(regulon, function(x, genes) {
                filtro <- names(x$tfmode) %in% genes
                x$tfmode <- x$tfmode[filtro]
                x$likelihood <- x$likelihood[filtro]
                return(x)
        }, genes = rownames(ges))
        regulon <- regulon [sapply (regulon, function (r) sum (r$likelihood) != 0)]
        if (!is.null(nullmodel)) {
                nullmodel <- nullmodel[match(rownames(ges), rownames(nullmodel)), ]
        }
        if (adaptive.size) {
                regulon <- regulon[sapply(regulon, function(x) {
                        sum(x$likelihood/max(x$likelihood))
                }) >= minsize]
        } else {
                regulon <- regulon[sapply(regulon, function(x) {length(x$tfmode)}) >=  minsize]
        }
        if (verbose) {
                message("Computing regulon enrichment with aREA algorithm")
        }
        res <- aREA(ges, regulon, method = "loop", cores = cores, 
                    minsize = 0, verbose = verbose)
        if (is.null(nullmodel)) {
                nes <- res$nes
        } else {
                if (verbose) {
                        message("\nEstimating the normalized enrichment scores")
                }
                tmp <- aREA(nullmodel, regulon, cores = cores, minsize = 0, 
                            verbose = verbose)$es
                nes <- t(sapply(1:nrow(tmp), function(i, tmp, es) {
                        viper_env$aecdf(tmp[i, ], symmetric = TRUE)(es[i, ])$nes
                }, tmp = tmp, es = res$es))
                if (nrow(nes) == 1) {
                        nes <- t(nes)
                }
                rownames(nes) <- rownames(res$es)
        }
        if (pleiotropy) {
                pb <- NULL
                if (verbose) {
                        message("\nComputing pleiotropy for ", ncol(nes), 
                                " samples.")
                        message("\nProcess started at ", date())
                }
                if (cores > 1) {
                        if (verbose) {
                                pb <- txtProgressBar(max = ncol(nes), style = 3)
                        }
                        nes <- mclapply(1:ncol(nes), function(i, ss, nes, regulon, args, dnull, pb) {
                                nes <- nes[, i]
                                sreg <- viper_env$shadowRegulon(ss[, i], nes, regulon, 
                                                                regulators = args[[1]], shadow = args[[2]], 
                                                                targets = args[[3]], penalty = args[[4]], 
                                                                method = args[[5]])
                                if (!is.null(sreg)) {
                                        if (is.null(dnull)) {
                                                tmp <- aREA(ss[, i], sreg, minsize = 5, 
                                                            cores = 1)$nes[, 1]
                                        } else {
                                                tmp <- aREA(cbind(ss[, i], dnull), sreg, 
                                                            minsize = 5, cores = 1)$es
                                                tmp <- na.omit (tmp)
                                                tmp <- apply(tmp, 1, function(x) {
                                                        viper_env$aecdf(x[-1], symmetric = TRUE)(x[1])$nes
                                                })
                                        }
                                        nes[match(names(tmp), names(nes))] <- tmp
                                }
                                if (is(pb, "txtProgressBar")) {
                                        setTxtProgressBar(pb, i)
                                }
                                return(nes)
                        }, ss = ges, nes = nes, regulon = regulon, args = pleiotropyArgs, dnull = nullmodel, pb = pb, 
                        mc.cores = cores)
                        nes <- sapply(nes, function(x) x)
                } else {
                        if (verbose) {
                                pb <- txtProgressBar(max = ncol(nes), style = 3)
                        }
                        nes <- sapply(1:ncol(nes), function(i, ss, nes, regulon, args, dnull, pb) {
                                nes <- nes[, i]
                                sreg <- viper_env$shadowRegulon(ss[, i], nes, regulon, 
                                                      regulators = args[[1]], shadow = args[[2]], 
                                                      targets = args[[3]], penalty = args[[4]], 
                                                      method = args[[5]])
                                if (!is.null(sreg)) {
                                        if (is.null(dnull)) {
                                                tmp <- aREA(ss[, i], sreg, minsize = 5)$nes[, 1]
                                        } else {
                                                tmp <- aREA(cbind(ss[, i], dnull, minsize = 5), sreg)$es
                                                tmp <- na.omit (tmp)
                                                tmp <- apply(tmp, 1, function(x) {
                                                        viper_env$aecdf(x[-1], symmetric = TRUE)(x[1])$nes
                                                        })
                                        }
                                        nes[match(names(tmp), names(nes))] <- tmp
                                }
                                if (is(pb, "txtProgressBar")) {
                                        setTxtProgressBar(pb, i)
                                }
                                return(nes)
                        }, ss = ges, nes = nes, regulon = regulon, args = pleiotropyArgs, dnull = nullmodel, pb = pb)
                }
                if (verbose) 
                        message("\nProcess ended at ", date(), "\n")
                colnames(nes) <- colnames(ges)
        }
        senes <- sqrt(frvarna(nes)/ncol(nes))[, 1]
        if (ncol(nes) == 1) 
                senes <- NULL
        nes1 <- rowMeans(nes)
        pval1 <- pnorm(abs(nes1), lower.tail = FALSE) * 2
        res <- list(signature = ges, regulon = regulon, es = list(nes = nes1, 
                                                                  nes.se = senes, 
                                                                  size = sapply(regulon, function(x) length(x$tfmode)), 
                                                                  p.value = pval1, nes.bt = nes), 
                    param = list(minsize = minsize, adaptive.size = adaptive.size), 
                    nullmodel = nullmodel)
        class(res) <- "msviper"
        if (synergy > 0) 
                res <- viper_env$msviperSynergy(msviperCombinatorial(mobj = res, 
                                                           regulators = synergy, nullmodel = nullmodel, minsize = minsize, 
                                                           adaptive.size = adaptive.size, level = level, verbose = verbose), 
                                      verbose = verbose)
        return(res)
}