synapse.browser <- function (synid) {
        a = NULL
        ite <- 1
        lvls_synd <- list()
        while(is.null(a)) {
                lvls_synd[[ite]] <- synid
                
                iterator <- list()
                for(i in 1:length(synid)) {
                        x <- synGetChildren(synid[[i]], includeTypes = list("file", "folder"), sortBy = "NAME")
                        iterator[[i]] <- as.list(x)
                        names(iterator)[i] <- paste("level", ite, sep = "_")
                }
                
                iter <- list()
                for(i in 1:length(iterator)) {
                        x <- lapply(iterator[[i]], function(i) do.call("c", i))
                        x <- do.call("rbind", x)
                        x <- x[,c("id", "name"),drop=F]
                        x <- data.frame("level" = names(iterator), x, stringsAsFactors = F)
                        iter[[i]] <- x
                }
                iter <- do.call("rbind", iter)
                iter$browser_option <- 1:nrow(iter)
                
                print(iter)
                print("Enter 'browser_option' number to browse that directory.")
                print("To select all 'browser_option', answer 'ALL'.")
                print("To stop browsing, answer 'END'.")
                print("Return to previous folder by typing 'BACK'.")
                answer1 <- readline(prompt = "Type answer:")
                if (grepl(pattern = "^END$", x = answer1, ignore.case = T)) {
                        a <- "stop"
                        final <- iter[,c("id", "name")]
                } else if (grepl(pattern = "^ALL$", x = answer1, ignore.case = T)){
                        a <- NULL
                        synid <- iter$id
                        ite <- ite + 1
                } else if (grepl(pattern = "^BACK$", x = answer1, ignore.case = T)){
                        a <- NULL
                        synid <- lvls_synd[[ite - 1]]
                        ite <- ite - 1
                } else {
                        a <- NULL
                        synid <- iter$id [as.numeric(answer1)]
                        ite <- ite + 1
                }
        }
        return(final)
}