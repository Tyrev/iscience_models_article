#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("reshape2"), repos = "http://lib.stat.cmu.edu/R/CRAN")

#############################
# Load Data
#############################
FEA_GO <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/FEA/DEG/FEA_GO.txt", 
                     stringsAsFactors=FALSE)
feaList <- split(x = FEA_GO, f = FEA_GO$study)
feaList <- feaList[c("MODEL-AD_hAbeta_KI_homozygous_22months-WT_22months", 
                     "MODEL_APP.PS1", "MODEL-AD_5XFAD")]
feaList <- lapply(feaList, function(x) subset(x = x, subset = x$ONTOLOGY == "BP"))

#############################
# Venn Diagram
#############################
listSYMBOL <- lapply(feaList, function(x) x$ID)
listSYMBOL <- lapply(listSYMBOL, na.omit)
listSYMBOL <- lapply(listSYMBOL, unique)
a1 <- length(x = listSYMBOL[[1]])
a2 <- length(x = listSYMBOL[[2]])
a3 <- length(x = listSYMBOL[[3]])
n12 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[2]]))
n13 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[3]]))
n23 <- length(intersect(listSYMBOL[[2]], listSYMBOL[[3]]))
n123 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]])) == 3)

#############################
# Chi Test
#############################
ki_countTest <- matrix(nrow = 2, ncol = 2, 
                       dimnames = list("row" = c(names(listSYMBOL)[2],
                                                 names(listSYMBOL)[3]), 
                                       "column" = c("Overlap", "NotOverlap")))
ki_countTest[names(listSYMBOL)[2], "Overlap"] <- n12
ki_countTest[names(listSYMBOL)[2], "NotOverlap"] <- a1 - n12
ki_countTest[names(listSYMBOL)[3], "Overlap"] <- n13
ki_countTest[names(listSYMBOL)[3], "NotOverlap"] <- a1 - n13
ki_countTestres <- chisq.test(ki_countTest, correct = T)

## proportion matrix
r_sum <- rowSums(ki_countTest)
prop_mtx <- ki_countTest
for(r in 1:nrow(prop_mtx)) {
        prop_mtx[r,] <- prop_mtx[r,]/r_sum[r]
}
prop_mtx <- round(prop_mtx, 3)

#############################
# Mosaic Plots
#############################
ndir <- paste(getwd(), "FEA", sep = "/")
if(!dir.exists(ndir)) {
        dir.create(ndir)
}
ndir <- paste(ndir, "DEG", sep = "/")
if(!dir.exists(ndir)) {
        dir.create(ndir)
}

fname <- paste(ndir, "/2_1_0_MosaicPlots_ChiSquare_GO_models.pdf", sep = "")
pdf(file = fname, width = 12, height = 12)
mosaicplot(ki_countTest, 
           col = c("firebrick", "goldenrod1"), 
           cex.axis = 1, 
           xlab = "Disease", 
           ylab = names(listSYMBOL)[1], 
           main = ki_countTestres$method,
           sub = paste(names(ki_countTestres$statistic), " = ", round(ki_countTestres$statistic, 2), "; ",
                       "p-value = ", round(ki_countTestres$p.value, 4),
                       sep = ""))
plot.new()
gridExtra::grid.table(ki_countTest)
plot.new()
gridExtra::grid.table(prop_mtx)
dev.off()
