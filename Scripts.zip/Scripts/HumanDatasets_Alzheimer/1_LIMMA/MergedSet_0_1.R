#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("arrayQualityMetrics", 
                  "AffyCompatible",
                  "GEOquery",
                  "affy", "vsn", "sva",
                  "virtualArray"), repos = "http://bioconductor.org/biocLite.R")

#############################
# Custom Function
#############################
## original R code from virtualArray package (virtualArrayBuildfData function)
## -----
## adapted by Marco A. De Bastiani: collapse_eSet 2019
###############
# collapse_eSet 
#       -- Expression values are collapsed according to given identifiers, e.g. gene symbols. 
#       In the same run, a data.frame with 2 columns to fill the "fData" slot of the 
#       ExpressionSet is build. The data is pulled from the Bioconductor annotation package 
#       defined in the "annotation" slot of the ExpressionSet.
# ARGUMENTS -- 
#       -- x - expressionSet object
#       -- see ?virtualArrayBuildfData for the remaining arguments
###############
collapse_eSet <- function (x, 
                           identifier = "SYMBOL", 
                           collapse_fun = median) 
{
    
    identifier <- identifier
    z <- NULL
    z <- x
    
    annot <- annotation(x)
    annot_identifier <- paste(annot, identifier, sep = "")
    annot_package <- sub(" ", ".", paste(annot, "db"))
    require(package = annot_package, character.only = TRUE)
    annot_identifier <- toggleProbes(value = "all", x = eval(as.symbol(annot_identifier)))
    
    # assayData
    exprs_z <- as.data.frame(exprs(z))
    exprs_z <- data.frame(identifier = fData(z)[, identifier], exprs_z, row.names = NULL, stringsAsFactors = F)
    exprs_z <- exprs_z[!exprs_z$identifier %in% "" & !is.na(exprs_z$identifier),]
    exprs_z <- reshape2::recast(data = exprs_z, 
                                formula = identifier ~ variable, 
                                fun.aggregate = collapse_fun)
    rownames(exprs_z) <- exprs_z[, 1]
    exprs_z <- exprs_z[,-1]
    exprs_z <- data.matrix(exprs_z, rownames.force = TRUE)
    
    # featureData
    featData_z <- fData(z)
    match_fData_y2 <- match(rownames(exprs_z), fData(z)[, identifier])
    featData_z <- featData_z[match_fData_y2, ]
    row.names(featData_z) <- featData_z$SYMBOL
    featData_z <- AnnotatedDataFrame(data = featData_z)
    
    x <- ExpressionSet(assayData = exprs_z,
                       phenoData = phenoData(z),
                       featureData = featData_z,
                       annotation = annotation(z))
    return(x)
}

## original R code from virtualArray package (virtualArrayBuildExprs function)
## -----
## adapted by Marco A. De Bastiani: virtualArrayBuild_fData 2019
###############
# virtualArrayBuild_fData 
#       -- This function takes ExpressionSets as input and formats the feature data into 
#       a data.frame whose identifiers are put into the first column.
# ARGUMENTS -- 
#       -- x - expressionSet object
###############
virtualArrayBuild_fData <- function (x, identifier = "SYMBOL") 
{
    dtfrm <- data.frame(fData(x), stringsAsFactors = FALSE, check.names = FALSE)
    dtfrm <- dtfrm[,-1]
    id <- which(colnames(dtfrm) %in% identifier)
    dtfrm <- dtfrm[,c(identifier, colnames(dtfrm)[-id])]
    return(dtfrm)
}

## original R code from virtualArray package (virtualArrayComBat function)
## -----
## adapted by Marco A. De Bastiani: virtualArray_ComBat 2019
###############
# virtualArray_ComBat 
#       -- 
# ARGUMENTS -- 
#       -- expression_xls - The expression matrix to adjust.
#       -- sample_info_file - The sample information data.frame regarding batch contribution and possibly covariates.
#       -- type - The type of input; Defaults to "txt".
#       -- write - Write output to external file or provide new expression matrix.
#       -- covariates - Describe which Covariates to use in the process and which to dismiss. The default is to use only "Batch".
#       -- par.prior - Logical; set prior parameters or not; Use prespecified values for the variables ("TRUE") or start a priori ("FALSE").
#       -- filter - Filter for genes not present in a given percentage of the samples. Requires present/absent calls in the data. Can be either "FALSE" or a numeric between "0" and "1". Recommended is "0.8" or "FALSE".
#       -- skip - Columns to skip in the input "expression_xls" matrix.
#       -- prior.plots - Create quantile-quantile and kernel density plots including prior estimates to assess the quality of the estimation.
###############
design.mat <- function (saminfo) 
{
    tmp <- which(colnames(saminfo) == "Batch")
    tmp1 <- as.factor(saminfo[, tmp])
    cat("Found", nlevels(tmp1), "batches\n")
    design <- build.design(tmp1, start = 1)
    ncov <- ncol(as.matrix(saminfo[, -c(1:2, tmp)]))
    cat("Found", ncov, "covariate(s)\n")
    if (ncov > 0) {
        for (j in 1:ncov) {
            tmp1 <- as.factor(as.matrix(saminfo[, -c(1:2, tmp)])[, 
                                                                 j])
            design <- build.design(tmp1, des = design)
        }
    }
    design
}
list.batch <- function (saminfo) 
{
    tmp1 <- as.factor(saminfo[, which(colnames(saminfo) == "Batch")])
    batches <- NULL
    for (i in 1:nlevels(tmp1)) {
        batches <- append(batches, list((1:length(tmp1))[tmp1 == 
                                                             levels(tmp1)[i]]))
    }
    batches
}
aprior <- function (gamma.hat) 
{
    m = mean(gamma.hat)
    s2 = var(gamma.hat)
    (2 * s2 + m^2)/s2
}
bprior <- function (gamma.hat) 
{
    m = mean(gamma.hat)
    s2 = var(gamma.hat)
    (m * s2 + m^3)/s2
}
it.sol <- function (sdat, g.hat, d.hat, g.bar, t2, a, b, conv = 1e-04) 
{
    n <- apply(!is.na(sdat), 1, sum)
    g.old <- g.hat
    d.old <- d.hat
    change <- 1
    count <- 0
    while (change > conv) {
        g.new <- postmean(g.hat, g.bar, n, d.old, t2)
        sum2 <- apply((sdat - g.new %*% t(rep(1, ncol(sdat))))^2, 
                      1, sum, na.rm = TRUE)
        d.new <- postvar(sum2, n, a, b)
        change <- max(abs(g.new - g.old)/g.old, abs(d.new - d.old)/d.old)
        g.old <- g.new
        d.old <- d.new
        count <- count + 1
    }
    adjust <- rbind(g.new, d.new)
    rownames(adjust) <- c("g.star", "d.star")
    adjust
}
virtualArray_ComBat <- function (expression_xls, sample_info_file, type = "txt", write = FALSE, 
                                 covariates = "Batch", par.prior = TRUE, filter = FALSE, skip = 0, 
                                 prior.plots = FALSE) 
{
    cat("Reading Sample Information File\n")
    saminfo <- sample_info_file
    if (sum(colnames(saminfo) == "Batch") != 1) {
        return("ERROR: Sample Information File does not have a Batch column!")
    }
    cat("Reading Expression Data File\n")
    dat <- expression_xls
    if (skip > 0) {
        geneinfo <- as.matrix(dat[, 1:skip])
        dat <- dat[, -c(1:skip)]
    }
    else {
        geneinfo = NULL
    }
    if (filter) {
        ngenes <- nrow(dat)
        col <- ncol(dat)/2
        present <- apply(dat, 1, filter.absent, filter)
        dat <- dat[present, -(2 * (1:col))]
        if (skip > 0) {
            geneinfo <- geneinfo[present, ]
        }
        cat("Filtered genes absent in more than", filter, "of samples. Genes remaining:", 
            nrow(dat), "; Genes filtered:", ngenes - nrow(dat), 
            "\n")
    }
    if (any(apply(dat, 2, mode) != "numeric")) {
        return("ERROR: Array expression columns contain non-numeric values! (Check your .xls file for non-numeric values and if this is not the problem, make a .csv file and use the type=csv option)")
    }
    tmp <- match(colnames(dat), saminfo[, 1])
    if (any(is.na(tmp))) {
        return("ERROR: Sample Information File and Data Array Names are not the same!")
    }
    saminfo <- saminfo[tmp, ]
    saminfo <- saminfo[, c(covariates),drop=F]
    design <- virtualArray:::design.mat(saminfo)
    batches <- virtualArray:::list.batch(saminfo)
    n.batch <- length(batches)
    n.batches <- sapply(batches, length)
    n.array <- sum(n.batches)
    NAs = any(is.na(dat))
    if (NAs) {
        cat(c("Found", sum(is.na(dat)), "Missing Data Values\n"), 
            sep = " ")
    }
    cat("Standardizing Data across genes\n")
    if (!NAs) {
        B.hat <- solve(t(design) %*% design) %*% t(design) %*% 
            t(as.matrix(dat))
    }
    else {
        B.hat = apply(dat, 1, Beta.NA, design)
    }
    grand.mean <- t(n.batches/n.array) %*% B.hat[1:n.batch, ]
    if (!NAs) {
        var.pooled <- ((dat - t(design %*% B.hat))^2) %*% rep(1/n.array, 
                                                              n.array)
    }
    else {
        var.pooled <- apply(dat - t(design %*% B.hat), 1, var, 
                            na.rm = TRUE)
    }
    stand.mean <- t(grand.mean) %*% t(rep(1, n.array))
    if (!is.null(design)) {
        tmp <- design
        tmp[, c(1:n.batch)] <- 0
        stand.mean <- stand.mean + t(tmp %*% B.hat)
    }
    s.data <- (dat - stand.mean)/(sqrt(var.pooled) %*% t(rep(1, 
                                                             n.array)))
    cat("Fitting L/S model and finding priors\n")
    batch.design <- design[, 1:n.batch]
    if (!NAs) {
        gamma.hat <- solve(t(batch.design) %*% batch.design) %*% 
            t(batch.design) %*% t(as.matrix(s.data))
    }
    else {
        gamma.hat = apply(s.data, 1, Beta.NA, batch.design)
    }
    delta.hat <- NULL
    for (i in batches) {
        delta.hat <- rbind(delta.hat, apply(s.data[, i], 1, var, 
                                            na.rm = TRUE))
    }
    gamma.bar <- apply(gamma.hat, 1, mean)
    t2 <- apply(gamma.hat, 1, var)
    a.prior <- apply(delta.hat, 1, virtualArray:::aprior)
    b.prior <- apply(delta.hat, 1, virtualArray:::bprior)
    if (prior.plots & par.prior) {
        par(mfrow = c(2, 2))
        tmp <- density(gamma.hat[1, ])
        plot(tmp, type = "l", main = "Density Plot")
        xx <- seq(min(tmp$x), max(tmp$x), length = 100)
        lines(xx, dnorm(xx, gamma.bar[1], sqrt(t2[1])), col = 2)
        qqnorm(gamma.hat[1, ])
        qqline(gamma.hat[1, ], col = 2)
        tmp <- density(delta.hat[1, ])
        invgam <- 1/rgamma(ncol(delta.hat), a.prior[1], b.prior[1])
        tmp1 <- density(invgam)
        plot(tmp, typ = "l", main = "Density Plot", ylim = c(0, 
                                                             max(tmp$y, tmp1$y)))
        lines(tmp1, col = 2)
        qqplot(delta.hat[1, ], invgam, xlab = "Sample Quantiles", 
               ylab = "Theoretical Quantiles")
        lines(c(0, max(invgam)), c(0, max(invgam)), col = 2)
        title("Q-Q Plot")
    }
    gamma.star <- delta.star <- NULL
    if (par.prior) {
        cat("Finding parametric adjustments\n")
        for (i in 1:n.batch) {
            temp <- virtualArray:::it.sol(s.data[, batches[[i]]], gamma.hat[i, 
            ], delta.hat[i, ], gamma.bar[i], t2[i], a.prior[i], 
            b.prior[i])
            gamma.star <- rbind(gamma.star, temp[1, ])
            delta.star <- rbind(delta.star, temp[2, ])
        }
    }
    else {
        cat("Finding nonparametric adjustments\n")
        for (i in 1:n.batch) {
            temp <- int.eprior(as.matrix(s.data[, batches[[i]]]), 
                               gamma.hat[i, ], delta.hat[i, ])
            gamma.star <- rbind(gamma.star, temp[1, ])
            delta.star <- rbind(delta.star, temp[2, ])
        }
    }
    cat("Adjusting the Data\n")
    bayesdata <- s.data
    j <- 1
    for (i in batches) {
        bayesdata[, i] <- (bayesdata[, i] - t(batch.design[i, 
        ] %*% gamma.star))/(sqrt(delta.star[j, ]) %*% t(rep(1, 
                                                            n.batches[j])))
        j <- j + 1
    }
    bayesdata <- (bayesdata * (sqrt(var.pooled) %*% t(rep(1, 
                                                          n.array)))) + stand.mean
    if (write) {
        output_file <- paste("Adjusted", expression_xls, ".xls", 
                             sep = "_")
        outdata <- cbind(ProbeID = geneinfo, bayesdata)
        write.table(outdata, file = output_file, sep = "\t")
        cat("Adjusted data saved in file:", output_file, "\n")
    }
    else {
        return(cbind(geneinfo, bayesdata))
    }
}

#############################
# Datasets
#############################
wd <- getwd()
bDir <- paste(wd, "HumanDatasets", sep = "/")
fname <- paste(bDir, "HumanDatasets.txt", sep = "/")
HumanDatasets <- read.delim(fname, stringsAsFactors = FALSE)

loadDatasets <- subset(HumanDatasets, subset = HumanDatasets$AD_type %in% "LOAD")
gse_list <- list()
## load myEset objects to extract phenoData
for(study in loadDatasets$Study[-1]) {
    fname <- paste(bDir, study, "eSet.RData", sep = "/")
    load(fname)
    
    pData <- na.omit(pData(myEset))
    pData <- pData[,c("title","geo_accession","experimental_groups", "age")]
    pData <- data.frame(pData, "study" = study, stringsAsFactors = F)
    
    myEset <- myEset[,pData$geo_accession]
    pData(myEset) <- pData
    
    colnames(fData(myEset))[grep(pattern = "symbol", 
                                 x = colnames(fData(myEset)), 
                                 ignore.case = T)] <- "SYMBOL"
    
    gse_list[[study]] <- myEset
    
    rm(fname, myEset, pData)
}

all_expression_sets <- gse_list
collapse_fun <- median
identifier <- "SYMBOL"
common_phenoDatavar <- c("experimental_groups", "age")

#############################
# Combine different ExpressionSets into one
#############################
## Collapses expression values according to given identifiers
collapse_esets <- lapply(all_expression_sets, 
                         collapse_eSet,
                         collapse_fun = collapse_fun, 
                         identifier = identifier)

exprs_df <- lapply(collapse_esets, virtualArrayBuildExprs)
fData_df <- lapply(collapse_esets, virtualArrayBuild_fData)

## merge ExpressionSets
merged_exprs <- virtualArrayMergeRecurse(exprs_df, by = "identifier", incomparables = NA)
rownames(merged_exprs) <- merged_exprs[, 1]
merged_exprs <- merged_exprs[2:dim(merged_exprs)[2]]
cat("\nSize of expression matrix of whole dataset:", 
    dim(merged_exprs)[1], "rows and", dim(merged_exprs)[2], "columns\n")
merged_exprs <- new("ExpressionSet", exprs = as.matrix(merged_exprs))
merged_exprs <- affyPLM::normalize.ExpressionSet.quantiles(merged_exprs)

## merge phenoData
pData_df <- lapply(names(all_expression_sets), function(gse, eset, common) {
    x <- eset[[gse]]
    pDt <- pData(x)[,c("geo_accession", common)]
    pDt <- data.frame(pDt, "study" = gse, stringsAsFactors = F)
    return(pDt)
}, eset = all_expression_sets, common = common_phenoDatavar)
names(pData_df) <- names(all_expression_sets)
pData_df <- do.call("rbind", pData_df)
row.names(pData_df) <- pData_df$geo_accession
colnames(pData_df)[grep(pattern = "study", x = colnames(pData_df))] <- "Batch"
pData_df <- pData_df[,c(1,4,2,3)]
pData_df$experimental_groups <- toupper(pData_df$experimental_groups)

## merge featureData
fData_df <- lapply(fData_df, function(fdt, m_exprs) {
    rnames <- row.names(exprs(m_exprs))
    fdt[rnames,]
}, m_exprs = merged_exprs)
fData_df <- fData_df[[1]]

## merged and uncorrected expressionSet
uncorrected_eSet <- merged_exprs
pData(uncorrected_eSet) <- pData_df
fData(uncorrected_eSet) <- fData_df

#############################
# Batch Correction of Combined Datasets
#############################
Combat_edata <- virtualArray_ComBat(expression_xls = exprs(uncorrected_eSet), 
                                    sample_info_file = pData_df[,-c(3,4)],
                                    covariates = "Batch", prior.plots = F)

corrected_eSet <- ExpressionSet(assayData = Combat_edata,
                                phenoData = phenoData(uncorrected_eSet))
fData(corrected_eSet) <- fData(uncorrected_eSet)

#############################
# Save BATCH CORRECTED merged eSet
#############################
## create directory
fname <- paste(bDir, "MergedSet", sep = "/")
if(!dir.exists(fname)) {
    dir.create(path = fname)
}
save(list = "corrected_eSet", file = paste(fname, "merged_eSet.RData", sep = "/"))

#############################
# Evaluation of Batch Correction - PCA
#############################
## 
library (ggplot2)
library (gridExtra)
library (GGally)
library (FactoMineR)
library (factoextra)

## uncorrected expression set
exp <- t(exprs(uncorrected_eSet))
s_exp <- scale(exp)
pca <- PCA(s_exp)
pcinfo <- data.frame(pca$svd$U, stringsAsFactors = F)
colnames (pcinfo) <- paste ("PC", 1:ncol (pcinfo), sep = "")
pcinfo$study <- pData(uncorrected_eSet)$Batch
pair <- ggpairs(data = pcinfo, 
                mapping = aes (color = study), 
                columns = c(1:2,6), 
                upper = list (combo = "box"), 
                diag = list (continuous = "blankDiag"))
pdf (file = paste(fname, "PCA_eSet_uncorrected.pdf", sep = "/"), width = 12, height = 12)
print (pair)
dev.off()

## uncorrected expression set
exp <- t(exprs(corrected_eSet))
s_exp <- scale(exp)
pca <- PCA(s_exp)
pcinfo <- data.frame(pca$svd$U, stringsAsFactors = F)
colnames (pcinfo) <- paste ("PC", 1:ncol (pcinfo), sep = "")
pcinfo$study <- pData(uncorrected_eSet)$Batch
pair <- ggpairs(data = pcinfo, 
                mapping = aes (color = study), 
                columns = c(1:2,6), 
                upper = list (combo = "box"), 
                diag = list (continuous = "blankDiag"))
pdf (file = paste(fname, "PCA_eSet_corrected.pdf", sep = "/"), width = 12, height = 12)
print (pair)
dev.off()

#############################
# Evaluation of Batch Correction - Hierarchical Clustering
#############################
## uncorrected expression set
arrayclust <- exprs(uncorrected_eSet)
dist1 <- dist(t(arrayclust), method = "euclidian")
hc_nocolor <- hclust(dist1, method = "average")
col_df <- unique(pData_df[,"Batch"])
col_df <- data.frame("Batch" = col_df, stringsAsFactors = F)
col_df$color <- RColorBrewer::brewer.pal(n = nrow(col_df), name = "Set1")
hc_color <- pData_df[,c("geo_accession", "Batch")]
hc_color <- merge(hc_color, col_df)
row.names(hc_color) <- hc_color$geo_accession
hc_color <- hc_color[hc_nocolor$labels[hc_nocolor$order],]
pdf (file = paste(fname, "HC_eSet_uncorrected.pdf", sep = "/"), width = 20, height = 12)
virtualArrayHclust(hc_nocolor, 
                   lab.col = hc_color$color,
                   lab = hc_color$geo_accession,
                   main = "batch effect NOT removed", cex = 0.7,
                   xlab = "sample names")
legend("topright", inset = .02, title = "Study",
       col_df$Batch, fill = col_df$color, horiz = F, cex = 0.8)
dev.off()

## corrected expression set
arrayclust <- exprs(corrected_eSet)
dist1 <- dist(t(arrayclust), method = "euclidian")
hc_nocolor <- hclust(dist1, method = "average")
col_df <- unique(pData_df[,"Batch"])
col_df <- data.frame("Batch" = col_df, stringsAsFactors = F)
col_df$color <- RColorBrewer::brewer.pal(n = nrow(col_df), name = "Set1")
hc_color <- pData_df[,c("geo_accession", "Batch")]
hc_color <- merge(hc_color, col_df)
row.names(hc_color) <- hc_color$geo_accession
hc_color <- hc_color[hc_nocolor$labels[hc_nocolor$order],]
pdf (file = paste(fname, "HC_eSet_corrected.pdf", sep = "/"), width = 20, height = 12)
virtualArrayHclust(hc_nocolor, 
                   lab.col = hc_color$color,
                   lab = hc_color$Batch,
                   main = "batch effect removed", cex = 0.7,
                   xlab = "sample names")
legend("topright", inset = .02, title = "Study",
       col_df$Batch, fill = col_df$color, horiz = F, cex = 0.8)
dev.off()
