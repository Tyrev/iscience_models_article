#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("annotate", 
                  "org.Hs.eg.db", 
                  "biomaRt", 
                  "limma", 
                  "genefilter", 
                  "useful"), repos = "http://bioconductor.org/biocLite.R")

#############################
# dol.gse function
#############################
source(paste(getwd(), "/Scripts/dol.gse.R", sep = ""))

#############################
# Datasets
#############################
wd <- getwd()
bDir <- paste(wd, "HumanDatasets", sep = "/")
fname <- paste(bDir, "HumanDatasets.txt", sep = "/")
HumanDatasets <- read.delim(fname, stringsAsFactors = FALSE)

#############################
# Data
#############################
GEOID <- HumanDatasets[3,1]
fname <- paste (bDir, GEOID, "eSet.RData", sep = "/")
load (fname)
gse <- myEset

## arrayQualityMetrics
qc_table <- read.delim2(file = paste(bDir, GEOID, "QC_Processed_table.txt", sep = "/"), header = T, stringsAsFactors = F)
qc_outliers <- apply(qc_table[,c(3:5)], 2, function(col) grep("x", col))
qc_outliers <- Reduce("union", qc_outliers)
if(!is.null(qc_outliers)) {
     gse <- gse[,-qc_outliers]
}

#############################
# LIMMA
#############################
## make proper column names to match toptable 
fvarLabels(gse) <- make.names(fvarLabels(gse))

## log2 transform
ex <- exprs(gse)
qx <- as.numeric(quantile(ex, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
LogC <-(qx[5] > 100) ||
     (qx[6]-qx[1] > 50 && qx[2] > 0) ||
     (qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)
if(LogC) { ex[which(ex <= 0)] <- NaN
exprs(gse) <- log2(ex) }

### setting study groups
groups <- pData(gse)$experimental_groups
groups <- as.factor(groups)
names(groups) <- pData(gse)$geo_accession

## Remove uninformative probes and duplicated probes
annot <- annotation(gse)
annot_package <- sub(" ", ".", paste(annot, "db"))
require(package = annot_package, character.only = TRUE)
### 
gse_filter <- nsFilter(gse, var.cutoff = 0.25)
gse <- gse_filter$eset

### setting limma groups contrast matrix
gse$description <- as.character(groups)
design <- model.matrix(~ description + 0, gse)
colnames(design) <- levels(groups)
contrast.comb <- combn(levels(groups), 2)
contrast.matrix <- NULL
for(i in seq(ncol(contrast.comb))) {
     cont <- paste(contrast.comb[1,i], "-", contrast.comb[2,i], sep = "")
     contrast.matrix <- c(contrast.matrix, cont)
     rm(cont, i)
}
contrast.matrix <- makeContrasts(contrasts = contrast.matrix, levels = design)

### Linear model fitting for study
fit <- lmFit(exprs(gse), design)
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2, 0.01)
tT <- topTable(fit2, adjust="fdr", sort.by="B", number = 100000, p.value = 1)

### load NCBI platform annotation
ncbifd <- fData(gse)
row.names(ncbifd) <- ncbifd$ID

## replace original platform annotation
tT <- data.frame("ID" = row.names(tT), tT)
tT <- merge(tT, ncbifd, by = "ID")
tT <- tT[order(tT$P.Value), ]  # restore correct order
tT <- subset(tT, select=c("ID","adj.P.Val","P.Value","t","B","logFC","Definition","Symbol","Entrez_Gene_ID"))

## result outputs
contrast.name <- colnames(contrast.matrix)
fname <- paste(bDir, "/", GEOID, "/", contrast.name, "_DEG.txt", sep = "")
write.table(tT, file = fname, sep = "\t")
