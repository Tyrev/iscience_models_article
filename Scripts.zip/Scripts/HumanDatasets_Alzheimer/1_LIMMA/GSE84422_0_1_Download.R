#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("arrayQualityMetrics", 
                   "AffyCompatible",
                   "GEOquery",
                   "affy"), repos = "http://bioconductor.org/biocLite.R")

#############################
# dol.gse function
#############################
source(paste(getwd(), "/Scripts/dol.gse.R", sep = ""))

#############################
# Datasets
#############################
wd <- getwd()
bDir <- paste(wd, "HumanDatasets", sep = "/")
fname <- paste(bDir, "HumanDatasets.txt", sep = "/")
HumanDatasets <- read.delim(fname, stringsAsFactors = FALSE)

phenoData <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/GSE84422/phenoData.txt", 
                        stringsAsFactors=FALSE)

#############################
# Download RAWs
#############################
GEOID <- HumanDatasets[6,1]
fname <- paste(bDir, GEOID, sep = "/")
if(!dir.exists(paste(fname, "RAWs", sep = "/"))) {
     dir.create(path = paste(fname, "RAWs", sep = "/"))
}
for(f in phenoData$geo_accession) {
     getGEOSuppFiles(GEO = f, baseDir = paste(fname, "RAWs", sep = "/"))
}
gzfiles <- dir(paste(fname, "RAWs", sep = "/"))
gzfiles <- paste(paste(fname, "RAWs", sep = "/"), gzfiles, sep = "/")
gzfiles <- paste (gzfiles, dir(gzfiles), sep = "/")
for(f in seq(gzfiles)) {
     file.copy(from = gzfiles[f], to = paste(fname, "RAWs", sep = "/"), overwrite = T)
     file.remove(gzfiles[f])
}
setwd(paste(fname, "RAWs", sep = "/"))
gzfiles <- dir(paste(fname, "RAWs", sep = "/"))
gzfiles <- paste(paste(fname, "RAWs", sep = "/"), gzfiles, sep = "/")
for(f in seq(gzfiles)) {
     gunzip(filename = gzfiles[f])
}
