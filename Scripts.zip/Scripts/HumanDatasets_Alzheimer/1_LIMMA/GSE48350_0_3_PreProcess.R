#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("arrayQualityMetrics", 
                  "AffyCompatible",
                  "GEOquery",
                  "affy", "vsn"), repos = "http://bioconductor.org/biocLite.R")

#############################
# dol.gse function
#############################
source(paste(getwd(), "/Scripts/dol.gse.R", sep = ""))

#############################
# Datasets
#############################
wd <- getwd()
bDir <- paste(wd, "HumanDatasets", sep = "/")
fname <- paste(bDir, "HumanDatasets.txt", sep = "/")
HumanDatasets <- read.delim(fname, stringsAsFactors = FALSE)

phenoData <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/GSE48350/phenoData.txt", 
                        stringsAsFactors=FALSE)

GEOID <- HumanDatasets[5,1]
gse <- dol.gse(GEOID = GEOID, wd.here = F, wd.path = "HumanDatasets")
## arrayQualityMetrics
qc_table <- read.delim2(file = paste(bDir, GEOID, "QC_RAW_table.txt", sep = "/"), header = T, stringsAsFactors = F)
qc_outliers <- apply(qc_table[,c(3:5)], 2, function(col) grep("x", col))
qc_outliers <- Reduce("union", qc_outliers)

#############################
# Read CEL
#############################
celnames <- paste(bDir, GEOID, "RAWs", sep = "/")
celnames <- paste(celnames, dir(celnames), sep = "/")
rawdata <- affy::ReadAffy(filenames = celnames)

rawpdata <- data.frame("geo_accession" = row.names(pData(rawdata)), pData(rawdata), stringsAsFactors = F)
raworder <- sapply(X = phenoData$geo_accession, function(x, rawp) {
     grep(pattern = x, x = rawp, ignore.case = T)
}, rawp = rawpdata$geo_accession)
rawdata <- rawdata[,raworder]

## phenoData
phenoD <- phenoData
phenoD <- cbind(phenoD[,1:2], 
                "experimental_groups" = ifelse(test = grepl(pattern = "_AD$", 
                                                            x = phenoD$source_name_ch1, ignore.case = T), 
                                               yes = "AD", no = "control"),
                "age" = as.numeric(phenoD[,c("age..yrs..ch1")]))
phenoD <- data.frame(sapply(phenoD, function(x) {
     if(class(x) != "numeric") {
          x <- as.character(x)
          x[!is.na(x)] <- make.names(x[!is.na(x)])
     }
     return(x)
}), stringsAsFactors = F)
row.names(phenoD) <- phenoD$geo_accession
phenoD <- as(phenoD, "AnnotatedDataFrame")
phenoData(rawdata) <- phenoD

## protocolData
protocolData(rawdata) <- protocolData(gse[,pData(rawdata)$geo_accession])
# hist(rawdata)
# boxplot(rawdata)

#############################
#Pre-processing
#############################
#Normalizations
## Creates normalized and background corrected expression values using the RMA method.
eset <- vsn::vsnrma(rawdata[,-qc_outliers])
### annotation
annot <- annotation(eset)
annot_package <- sub(" ", ".", paste(annot, "db"))
require(package = annot_package, character.only = TRUE)
annot_identifier <- paste(annot, "SYMBOL", sep = "")
annot_identifier <- toggleProbes(value = "all", x = eval(as.symbol(annot_identifier)))
annot_identifier <- toTable(annot_identifier)
eset <- eset[intersect(row.names(eset), annot_identifier$probe_id),]
## featureData
fvarLabels(gse) <- make.names(fvarLabels(gse))
ncbifd <- fData(gse)
row.names(ncbifd) <- ncbifd$ID
ncbifd <- ncbifd[,c("ID", "GB_ACC", "Gene.Title", "Gene.Symbol", "ENTREZ_GENE_ID")]
ncbifd <- ncbifd[row.names(exprs(eset)),]
fData(eset) <- ncbifd

#############################
# Save Expression Set
#############################
myEset <- eset
save(myEset, file = paste(bDir, GEOID, "eSet.RData", sep = "/"))

#############################
# Quality Control Processed
#############################
qc <- arrayQualityMetrics(expressionset = eset,
                          outdir = paste(bDir, GEOID, "QC_Processed", sep = "/"),
                          do.logtransform = F,
                          force = T,
                          reporttitle = "QC_report",
                          intgroup = "experimental_groups",
                          spatial = F)
qc_table <- qc$arrayTable
write.table(x = qc_table, file = paste(bDir, GEOID, "QC_Processed_table.txt", sep = "/"), sep = "\t", row.names = F)
