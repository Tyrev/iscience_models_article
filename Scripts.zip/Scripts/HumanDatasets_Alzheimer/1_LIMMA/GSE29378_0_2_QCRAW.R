#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("arrayQualityMetrics", 
                  "AffyCompatible",
                  "GEOquery",
                  "affy"), repos = "http://bioconductor.org/biocLite.R")

#############################
# dol.gse function
#############################
source(paste(getwd(), "/Scripts/dol.gse.R", sep = ""))

#############################
# Datasets
#############################
wd <- getwd()
bDir <- paste(wd, "HumanDatasets", sep = "/")
fname <- paste(bDir, "HumanDatasets.txt", sep = "/")
HumanDatasets <- read.delim(fname, stringsAsFactors = FALSE)

#############################
#
#############################
GEOID <- HumanDatasets[3,1]
gse <- dol.gse(GEOID = GEOID, wd.here = F, wd.path = "HumanDatasets")

## make proper column names to match toptable 
fvarLabels(gse) <- make.names(fvarLabels(gse))

## log2 transform
ex <- exprs(gse)
qx <- as.numeric(quantile(ex, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
LogC <-(qx[5] > 100) ||
     (qx[6]-qx[1] > 50 && qx[2] > 0) ||
     (qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)
if(LogC) { ex[which(ex <= 0)] <- NaN
exprs(gse) <- log2(ex) }

## new pData
pdt <- pData(gse)
pdt <- pdt[,c(1,2,42)]
names(pdt)[3] <- "age"
experimental_groups <- strsplit(x = pdt$title, split = " ")
experimental_groups <- sapply(experimental_groups, "[[", 1)
pdt$experimental_groups <- experimental_groups
pData(gse) <- pdt

#############################
# Save Expression Set
#############################
myEset <- gse
save(myEset, file = paste(bDir, GEOID, "eSet.RData", sep = "/"))

#############################
# Quality Control Processed
#############################
qc <- arrayQualityMetrics(expressionset = gse,
                          outdir = paste(bDir, GEOID, "QC_Processed", sep = "/"),
                          do.logtransform = F,
                          force = T,
                          reporttitle = "QC_report",
                          intgroup = "experimental_groups",
                          spatial = F)
qc_table <- qc$arrayTable
write.table(x = qc_table, file = paste(bDir, GEOID, "QC_Processed_table.txt", sep = "/"), sep = "\t", row.names = F)
