#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("arrayQualityMetrics", 
                  "AffyCompatible",
                  "GEOquery",
                  "affy", "vsn", "sva",
                  "virtualArray"), repos = "http://bioconductor.org/biocLite.R")

#############################
# Datasets
#############################
wd <- getwd()
bDir <- paste(wd, "HumanDatasets", sep = "/")
fname <- paste(bDir, "HumanDatasets.txt", sep = "/")
HumanDatasets <- read.delim(fname, stringsAsFactors = FALSE)

fname <- paste(bDir, "MergedSet", "merged_eSet.RData", sep = "/")
load(fname)
eset <- corrected_eSet

#############################
# Quality Control Processed
#############################
qc <- arrayQualityMetrics(expressionset = eset,
                          outdir = paste(bDir, "MergedSet", "QC_Processed", sep = "/"),
                          do.logtransform = F,
                          force = T,
                          reporttitle = "QC_report",
                          intgroup = "experimental_groups",
                          spatial = F)
qc_table <- qc$arrayTable
write.table(x = qc_table, file = paste(bDir, "MergedSet", "QC_Processed_table.txt", sep = "/"), sep = "\t", row.names = F)
