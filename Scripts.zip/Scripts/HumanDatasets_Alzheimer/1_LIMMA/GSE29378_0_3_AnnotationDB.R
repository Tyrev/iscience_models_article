#===================================================================
#       Setup and install annotation packages for the platforms used
# See http://www.bioconductor.org/packages/release/bioc/vignettes/AnnotationDbi/inst/doc/SQLForge.pdf
#===================================================================
#############################
#Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("GEOquery", "AnnotationDbi", "AnnotationForge"), repos = "http://bioconductor.org/biocLite.R")

#############################
# Custom Annotation Database
#############################
wd <- getwd()
bDir <- paste(wd, "HumanDatasets", sep = "/")
fname <- paste(bDir, "HumanDatasets.txt", sep = "/")
HumanDatasets <- read.delim(fname, stringsAsFactors = FALSE)
GEOID <- HumanDatasets[3,1]
fname <- paste(bDir, GEOID, "eSet.RData", sep = "/")
load(fname)
gse <- myEset
ncbifd <- fData(gse)

atable <- ncbifd[,c("ID", "Entrez_Gene_ID", "Symbol", "Definition")]
colnames(atable) <- c("ID", "Entrez_Gene_ID", "GeneSymbol", "GeneTitle")
atable_fname <- paste(bDir, "/", GEOID, "/", "CustomAnnotationTable.csv", sep = "")
write.table(atable, file = atable_fname, row.names = F, col.names = , sep = "\t", quote = F)

out <- paste(bDir, GEOID, sep = "/")
catdb_name <- annotation(gse)
makeDBPackage("HUMAN_DB",
              affy = FALSE,
              prefix = catdb_name,
              fileName = atable_fname,
              baseMapType = "eg",
              author = "De Bastiani MA",
              outputDir = out,
              version = "1.0",
              manufacturer = "MAB",
              chipName = catdb_name,
              manufacturerUrl = "-")
custom_pkgname <- paste(out, "/", catdb_name, ".db", sep = "")
install.packages(custom_pkgname, repos = NULL, type = "source")
