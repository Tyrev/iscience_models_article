#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("arrayQualityMetrics", 
                   "AffyCompatible",
                   "GEOquery",
                   "affy"), repos = "http://bioconductor.org/biocLite.R")

#############################
# dol.gse function
#############################
source(paste(getwd(), "/Scripts/dol.gse.R", sep = ""))

#############################
# Datasets
#############################
wd <- getwd()
bDir <- paste(wd, "HumanDatasets", sep = "/")
fname <- paste(bDir, "HumanDatasets.txt", sep = "/")
HumanDatasets <- read.delim(fname, stringsAsFactors = FALSE)

phenoData <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/GSE84422/phenoData.txt", 
                        stringsAsFactors=FALSE)

GEOID <- HumanDatasets[6,1]
gse <- dol.gse(GEOID = GEOID, wd.here = F, wd.path = "HumanDatasets")
2

#############################
# Read CEL
#############################
celnames <- paste(bDir, GEOID, "RAWs", sep = "/")
celnames <- paste(celnames, dir(celnames), sep = "/")
rawdata <- affy::ReadAffy(filenames = celnames)

rawpdata <- data.frame("geo_accession" = row.names(pData(rawdata)), pData(rawdata), stringsAsFactors = F)
raworder <- sapply(X = phenoData$geo_accession, function(x, rawp) {
     grep(pattern = x, x = rawp, ignore.case = T)
}, rawp = rawpdata$geo_accession)
rawdata <- rawdata[,raworder]

## phenoData
phenoD <- phenoData
temp <- phenoD[,c(50)]
temp[grepl(pattern = "Probable|Possible", x = phenoD[,c(50)], ignore.case = T)] <- NA
phenoD <- cbind(phenoD[,c(1,2)],
                "experimental_groups" = ifelse(test = grepl(pattern = "AD$", 
                                                            x = phenoD[,c(50)], ignore.case = T), 
                                               yes = "AD", no = "control"),
                "experimental_groups_1" = temp, 
                "experimental_groups_2" = make.names(phenoD[,c(50)]))
phenoD <- data.frame(sapply(phenoD, function(x) {
     x <- as.character(x)
     x[!is.na(x)] <- make.names(x[!is.na(x)])
     return(x)
}), stringsAsFactors = F)
row.names(phenoD) <- phenoD$geo_accession
phenoD <- as(phenoD, "AnnotatedDataFrame")
phenoData(rawdata) <- phenoD

## protocolData
protocolData(rawdata) <- protocolData(gse[,pData(rawdata)$geo_accession])
# hist(rawdata)
# boxplot(rawdata)

#############################
# Quality Control Processed
#############################
qc <- arrayQualityMetrics(expressionset = rawdata,
                           outdir = paste(bDir, GEOID, "QC_RAW", sep = "/"),
                           do.logtransform = F,
                           force = T,
                           reporttitle = "QC_report",
                           intgroup = "experimental_groups_2",
                           spatial = F)
qc_table <- qc$arrayTable
write.table(x = qc_table, file = paste(bDir, GEOID, "QC_RAW_table.txt", sep = "/"), sep = "\t", row.names = F)
