#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("annotate", 
                  "org.Hs.eg.db", 
                  "biomaRt", 
                  "limma", 
                  "genefilter", 
                  "useful"), repos = "http://bioconductor.org/biocLite.R")

#############################
# Datasets
#############################
wd <- getwd()
bDir <- paste(wd, "HumanDatasets", sep = "/")
fname <- paste(bDir, "MergedSet", "merged_eSet.RData", sep = "/")
load(fname)
gse <- corrected_eSet

## arrayQualityMetrics
qc_table <- read.delim2(file = paste(bDir, "MergedSet", "QC_Processed_table.txt", sep = "/"), header = T, stringsAsFactors = F)
qc_outliers <- apply(qc_table[,c(3:5)], 2, function(col) grep("x", col))
qc_outliers <- Reduce("union", qc_outliers)
if(!is.null(qc_outliers)) {
        gse <- gse[,-qc_outliers]
}
gse <- gse[,as.numeric(pData(gse)$age) > 40]

#############################
# LIMMA
#############################
## make proper column names to match toptable 
fvarLabels(gse) <- make.names(fvarLabels(gse))

### setting study groups
pData(gse)$age_group <- ifelse(pData(gse)$age < 65, yes = "early", no = "late")
pData(gse)$experimental_groups_1 <- apply(cbind(pData(gse)$experimental_groups,pData(gse)$age_group), 1, paste, collapse = "_")
out <- which(pData(gse)$age_group != "early")
gse <- gse[,out]
groups <- pData(gse)$experimental_groups_1
groups <- as.factor(groups)
names(groups) <- pData(gse)$geo_accession

### setting limma groups contrast matrix
gse$description <- as.character(groups)
design <- model.matrix(~ description + 0, gse)
colnames(design) <- levels(groups)
contrast.comb <- combn(levels(groups), 2)
contrast.matrix <- NULL
for(i in seq(ncol(contrast.comb))) {
        cont <- paste(contrast.comb[1,i], "-", contrast.comb[2,i], sep = "")
        contrast.matrix <- c(contrast.matrix, cont)
        rm(cont, i)
}
contrast.matrix <- makeContrasts(contrasts = contrast.matrix, levels = design)

### Linear model fitting for study
fit <- lmFit(exprs(gse), design)
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2, 0.01)
tT <- topTable(fit2, adjust="fdr", sort.by="B", number = 100000, p.value = 1)

### load NCBI platform annotation
ncbifd <- fData(gse)
names(ncbifd)[1] <- "Gene.Symbol"
ncbifd$ID <- ncbifd[,1]
row.names(ncbifd) <- ncbifd$ID

## replace original platform annotation
tT <- data.frame("ID" = row.names(tT), tT)
tT <- merge(tT, ncbifd, by = "ID")
tT <- tT[order(tT$P.Value), ]  # restore correct order
tT <- subset(tT, select=c("ID","adj.P.Val","P.Value","t","B","logFC","GB_ACC","Gene.Title","Gene.Symbol","ENTREZ_GENE_ID"))

## result outputs
contrast.name <- colnames(contrast.matrix)
fname <- paste(bDir, "/", "MergedSet", "/", contrast.name, "_DEG.txt", sep = "")
write.table(tT, file = fname, sep = "\t")
