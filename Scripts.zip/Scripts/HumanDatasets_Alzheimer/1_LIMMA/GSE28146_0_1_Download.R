#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("arrayQualityMetrics", 
                   "AffyCompatible",
                   "GEOquery",
                   "affy"), repos = "http://bioconductor.org/biocLite.R")

#############################
# dol.gse function
#############################
source(paste (getwd(), "/Scripts/dol.gse.R", sep = ""))

#############################
# Datasets
#############################
wd <- getwd()
bDir <- paste(wd, "HumanDatasets", sep = "/")
fname <- paste(bDir, "HumanDatasets.txt", sep = "/")
HumanDatasets <- read.delim(fname, stringsAsFactors = FALSE)

#############################
# Download RAWs
#############################
GEOID <- HumanDatasets[2,1]
getGEOSuppFiles(GEO = GEOID, baseDir = bDir)
fname <- paste(bDir, GEOID, sep = "/")
tarname <- grep(pattern = ".tar", x = dir(fname))
tarname <- paste(fname, dir(fname)[tarname], sep = "/")
untar(tarfile = tarname, list = F, exdir = paste(fname, "RAWs", sep = "/"))
gzfiles <- dir(paste(fname, "RAWs", sep = "/"))
gzfiles <- paste(paste(fname, "RAWs", sep = "/"), gzfiles, sep = "/")
setwd(paste(fname, "RAWs", sep = "/"))
for (f in seq(gzfiles)) {
     gunzip(filename = gzfiles[f])
}
