#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("RTN", "viper", "reshape2", "DESeq2"), repos = "http://bioconductor.org/biocLite.R")
source(paste(getwd(), "Scripts", "aracne2regulon_adapted.R", sep = "/"))
source(paste(getwd(), "Scripts", "msviper_adapted.R", sep = "/"))

#############################
# TNI
#############################
# RTNI info
# source("~/Dropbox/MR_AD/Scripts/Transcription network inference_hip_GSE60862.R"))
GEOID <- "GSE60862"
fname <- paste ("HumanDatasets", "/", GEOID, "/", "tni_hip.RData", sep = "")
load(fname)
MRA_Vargas2018 <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/MRA_Vargas2018.txt", stringsAsFactors=FALSE)

#############################
# ExpressionSet object
#############################
wd <- getwd()
bDir <- paste(wd, "HumanDatasets", sep = "/")
##
load("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/MergedSet/merged_eSet.RData")
gse <- corrected_eSet
## arrayQualityMetrics
qc_table <- read.delim2(file = paste(bDir, "MergedSet", "QC_Processed_table.txt", sep = "/"), header = T, stringsAsFactors = F)
qc_outliers <- apply(qc_table[,c(3:5)], 2, function(col) grep("x", col))
qc_outliers <- Reduce("union", qc_outliers)
if(!is.null(qc_outliers)) {
     gse <- gse[,-qc_outliers]
}
gse <- gse[,as.numeric(pData(gse)$age) > 40]
##
pData(gse)$age_group <- ifelse(pData(gse)$age < 65, yes = "early", no = "late")
pData(gse)$experimental_groups_1 <- apply(cbind(pData(gse)$experimental_groups,pData(gse)$age_group), 1, paste, collapse = "_")
out <- which(pData(gse)$age_group != "early")
gse <- gse[,out]

#############################
# Load DEG
#############################
fname <- paste (bDir, "MergedSet", sep = "/")

degfiles <- grep(pattern = "_DEG.txt", x = dir(fname), ignore.case = T)
names(degfiles) <- gsub(pattern = "_DEG.txt", replacement = "", x = dir(fname)[degfiles])
fname <- paste(fname, dir(fname), sep = "/")
degList <- lapply (X = fname[degfiles], FUN = read.delim, header = T, stringsAsFactors = F)
names(degList) <- names(degfiles)
sig <- degList[[2]]
row.names(sig) <- sig$ID
signature <- (qnorm(sig$P.Value/2, lower.tail = FALSE) * sign(sig$logFC))
names(signature) <- sig$SYMBOL

## setting study groups
groups <- pData(gse)$experimental_groups_1
groups <- as.factor(groups)
names(groups) <- pData(gse)$geo_accession

#############################
# VIPER
#############################
mim <- tni.get(object = rtni.hip, what = "tnet", idkey = "SYMBOL")
mmim <- melt(mim)
mmim$value <- abs(mmim$value)
mmim <- mmim[mmim$value != 0, ]
dset <- rtni.hip@gexp
row.names(dset) <- rtni.hip@annotation[row.names(dset), "SYMBOL"]
regul <- aracne2regulon_adapted(meltedmim = mmim, eset = dset, verbose = T, cores = 3)

pData(gse)$description_1 <- groups
pData(gse)$description_1 <- as.character(pData(gse)$description_1)

g1 <- levels(as.factor(pData(gse)[["description_1"]]))[1]
g2 <- levels(as.factor(pData(gse)[["description_1"]]))[2]

pos1 <- pData(gse)[["description_1"]] %in% g1
pos2 <- pData(gse)[["description_1"]] %in% g2
nullmodel <- ttestNull(x = exprs(gse)[, pos1], 
                       y = exprs(gse)[, pos2], 
                       per = 1000, repos = TRUE,
                       cores = 1, verbose = T, seed = 123)
row.names(nullmodel) <- fData(gse)[row.names(nullmodel), 1]

signature <- bootstrapTtest(x = gse, 
                            pheno = "description_1", 
                            group1 = g1, group2 = g2, 
                            per = 1000, verbose = T, seed = 123)
row.names(signature) <-  fData(gse)[row.names(signature), 1]

mra <- msviper_adapted(ges = signature, 
                       regulon = regul, 
                       nullmodel = nullmodel, 
                       pleiotropy = T,
                       adaptive.size = T,
                       verbose = T, 
                       cores = 1)
mra <- bootstrapmsviper(mra, "mode")
mra <- msviperCombinatorial(mra, regulators = 100, nullmodel = nullmodel, verbose = T)
mra <- msviperSynergy(mra, verbose = T, seed = 123)
mra <- ledge(mra)
mra <- shadow(mra, regulators = 100, verbose = T, seed = 123)

## results
fname <- paste (bDir,"/MergedSet/", names(degList)[2], "|VIPER.RData", sep = "")
save(mra, file = fname)
