#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("RTN", "DESeq2"), 
                 repos = "http://bioconductor.org/biocLite.R")

#############################
# TNI
#############################
# RTNI info
# source("~/Dropbox/MR_AD/Scripts/Transcription network inference_hip_GSE60862.R"))
load("HumanDatasets/GSE60862/tni_hip.RData")
MRA_Vargas2018 <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/MRA_Vargas2018.txt", stringsAsFactors=FALSE)

#############################
# Load Data
#############################
wd <- getwd()
bDir <- paste(wd, "HumanDatasets", sep = "/")
fname <- paste (bDir, "MergedSet", sep = "/")

degfiles <- grep(pattern = "_DEG.txt", x = dir(fname), ignore.case = T)
names(degfiles) <- gsub(pattern = "_DEG.txt", replacement = "", x = dir(fname)[degfiles])
fname <- paste(fname, dir(fname), sep = "/")
degList <- lapply (X = fname[degfiles], FUN = read.delim, header = T, stringsAsFactors = F)
names(degList) <- names(degfiles)
deg.table <- degList[[1]]

#############################
# Construct TNA
#############################
# Load DEG
deg.table <- na.omit(deg.table)
row.names(deg.table) <- deg.table$EMSEMBLID

# phenotype
pheno <- deg.table$logFC
names(pheno) <- deg.table$ID

# hits
threshold_cutoff <- 0.05
hits <- deg.table[deg.table$P.Value < threshold_cutoff,]
hits <- as.character(hits$ID)

# phenoIDs
gcol <- NULL
if(length(grep("Symbol", names(deg.table), ignore.case = T)) != 0) {gcol <- c(gcol, grep("Symbol", names(deg.table), ignore.case = T))}
pid <- deg.table [,c(1, gcol)]
names(pid) <- c("ID", "Gene.Symbol")[1:ncol(pid)]

## TNI to TNA
tna <- tni2tna.preprocess(rtni.hip, phenotype = pheno, hits = hits, phenoIDs = pid)

## MRA
set.seed(123)
tna <- tna.mra(tna, minRegulonSize = 100)
mra.result <- tna.get(tna, what = "mra")

## one-tail GSEA
library(snow)
options(cluster = makeCluster(2, "SOCK"))
set.seed(123)
tna <- tna.gsea1(tna, minRegulonSize = 100, orderAbsValue = T, sizeFilterMethod = "posPLUSneg")
stopCluster(getOption("cluster"))
gsea1.result <- tna.get(tna, what = "gsea1")

## two-tail GSEA
library(snow)
options(cluster = makeCluster(2, "SOCK"))
set.seed(123)
tna <- tna.gsea2(tna, sizeFilterMethod = "posPLUSneg")
stopCluster(getOption("cluster"))
gsea2.result <- tna.get(tna, what = "gsea2")$differential

# results
fname <- paste (bDir, "/MergedSet/", names(degList)[1], "|TNA.RData", sep = "")
save(tna, file = fname)
