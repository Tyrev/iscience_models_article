#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("ggplot2", "reshape2"), repos = "http://lib.stat.cmu.edu/R/CRAN")

#############################
# Load Data
#############################
wd <- getwd()
bDir <- paste(wd, "HumanDatasets", sep = "/")
fname <- paste(bDir, "MergedSet", sep = "/")
degfiles <- grep(pattern = "_DEG.txt", x = dir(fname), ignore.case = T)
names(degfiles) <- gsub(pattern = "_DEG.txt", replacement = "", x = dir(fname)[degfiles])
fname <- paste(fname, dir(fname), sep = "/")
degList <- lapply(X = fname[degfiles], FUN = read.delim, header = T, stringsAsFactors = F)
names(degList) <- names(degfiles)
degList <- lapply(degList, na.omit)
degList <- lapply(degList, unique)

#############################
# Bar Plots
#############################
make.DEGcount <- function(degL, 
                          bar_title, 
                          sig_var,
                          logfc_var,
                          sig_threshold = 0.05, 
                          logfc_threshold = 1,
                          filter = c("both", "sig", "logfc")
) 
{
        filter <- match.arg(arg = NULL, choices = filter)
        if(filter == "both") {
                count_eval <- lapply(degL, function(deg) {
                        deg[,sig_var] < sig_threshold & abs(deg[,logfc_var]) > logfc_threshold
                })
                subtitle <- paste("DEG = ", sig_var, " < ", sig_threshold, "AND |logFC| > ", logfc_threshold)
        } else if(filter == "sig") {
                count_eval <- lapply(degL, function(deg) {
                        deg[,sig_var] < sig_threshold
                })
                subtitle <- paste("DEG = ", sig_var, " < ", sig_threshold)
        } else if(filter == "logfc") {
                count_eval <- lapply(degL, function(deg) {
                        abs(deg[,logfc_var]) > logfc_threshold
                })
                subtitle <- paste("|logFC| > ", logfc_threshold)
        }
        deg_count <- sapply(count_eval, sum)
        deg_count <- data.frame("contrast" = names(deg_count), "deg.count" = deg_count, stringsAsFactors = F)
        deg_count$contrast <- gsub(pattern = "-", replacement = " vs ", x = deg_count$contrast)
        g <- ggplot(data = deg_count, mapping = aes(x = contrast, y = deg.count)) + 
                geom_col(size = 1.5) +
                ggtitle(label = bar_title, subtitle = subtitle) +
                xlab(label = "Comparison") +
                ylab(label = "DEG Count") +
                geom_text(aes(label = deg.count, y = deg.count + 10),
                          position = position_dodge(0.9),
                          vjust = 0) +
                theme(panel.background = element_rect(fill = "white", colour = NA), 
                      panel.border = element_rect(fill = NA, colour = "grey20"), 
                      panel.grid = element_line(colour = "grey92"), 
                      panel.grid.minor = element_line(size = rel(0.5)), 
                      strip.background = element_rect(fill = "grey85", colour = "grey20"), 
                      axis.text.x = element_text(angle = 45, hjust = 1),
                      plot.margin = margin(t = 2, r = 2, b = 2, l = 50))
        return(g)
        
}
threshold_cutoff <- 0.05
barPlot <- make.DEGcount(degL = degList,
                         bar_title = names(degList),
                         sig_var = "P.Value", 
                         logfc_var = "logFC",
                         sig_threshold = threshold_cutoff, 
                         filter = "sig")
barPlot <- barPlot + scale_y_continuous(limits = c(0,5000))

#############################
# Save Plots
#############################
ndir <- paste(bDir, "MergedSet/Figures", sep = "/")
if(!dir.exists(ndir)) {
        dir.create(ndir)   
}
fname <- paste(bDir, "MergedSet", sep = "/")
filepath <- paste(ndir, "/", basename(fname), "_CountPlot.pdf", sep = "")
ggsave(filename = filepath, plot = barPlot, width = 12, height = 12)
