#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("reshape2", "ggplot2", "gplots", "gridExtra", "cowplot", "dplyr"), repos = "http://lib.stat.cmu.edu/R/CRAN")

#############################
# Custom Function
#############################
countDirection <- function(res, input) {
     row.names(input) <- input$human_EntrezGeneID
     gList <- strsplit(x = res$geneID, split = "/")
     names(gList) <- res$ID
     direction <- lapply(gList, function(g, input) {
          d <- ifelse(test = sign(input[g,3]) == 1, yes = "up", no = "down")
          d <- as.data.frame(table(d))
          d$d <- as.character(d$d)
          if(nrow(d) != 2) {
               if(as.character(d$d) == "up") {
                    d <- rbind(d, c("down", 0))
               } else {
                    d <- rbind(d, c("up", 0))
               }
               
          }
          up <- d$d == "up"
          d <- data.frame("up" = as.numeric(d[up,"Freq"]), "down" = as.numeric(d[!up,"Freq"]))
          return(d)
     }, input = input)
     direction <- do.call("rbind", direction)
     direction <- data.frame("ID" = row.names(direction), direction, stringsAsFactors = F)
     return(direction)
}

#############################
# Load Data
#############################
### DEGs
degList <- list()
degList[["MODEL-AD_5XFAD"]] <- read.delim(file = "MODEL-AD_5XFAD/hemizygous-WT_DEG.txt", stringsAsFactors = F)
degList[["MODEL-AD_hAbeta_KI_homozygous_22months-WT_22months"]] <- read.delim(file = "MODEL-AD_hAbeta_KI/homozygous_22months-WT_22months_DEG.txt", stringsAsFactors = F)
degList[["MODEL_APP.PS1"]] <- read.delim(file = "MODEL_APP.PS1/APPPS1-WT_DEG.txt", stringsAsFactors = F)
degList[["Human_EOAD"]] <- read.delim(file = "HumanDatasets/MergedSet/AD_early-CONTROL_early_DEG.txt", stringsAsFactors = F)
degList[["Human_LOAD"]] <- read.delim(file = "HumanDatasets/MergedSet/AD_late-CONTROL_late_DEG.txt", stringsAsFactors = F)

pval_cutoff <- 0.05
degList <- lapply(X = degList, function(deg, pv) {
     symbol_col <- grep(pattern = "HGNC_SYMBOL|Gene.Symbol", x = colnames(deg), ignore.case = T)
     sig_col <- grep(pattern = "value", x = colnames(deg), ignore.case = T)
     log_col <- grep(pattern = "log", x = colnames(deg), ignore.case = T)
     subset(deg[,c(log_col,symbol_col)], subset = deg[,sig_col] < pv)
}, pv = pval_cutoff)
degList <- lapply(degList, na.omit)
degList <- lapply(degList, unique)

### FEA input
bDir <- "/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/FEA/DEG/"
fname <- dir(bDir)
fname <- grep(pattern = "input", x = fname, ignore.case = T)
fname <- paste(bDir, dir(bDir)[fname], sep = "/")
FEA_inputList <- lapply(fname, read.delim, stringsAsFactors=FALSE)
FEA_inputList <- lapply(FEA_inputList, na.omit)
names(FEA_inputList) <- gsub(pattern = "FEA_input_|\\.txt", replacement = "", x = basename(fname))

for(grp in names(degList)) {
     deg_table <- degList[[grp]]
     col_vars <- colnames(deg_table)
     col_vars <- c(grep(pattern = "log", x = col_vars, ignore.case = T), 
                   grep(pattern = "HGNC_SYMBOL|Gene.Symbol", x = col_vars, ignore.case = T))
     deg_table <- deg_table[,col_vars]
     FEA_inputList[[grp]] <- merge(x = FEA_inputList[[grp]], y = deg_table, 
                                   by.x = "human_GeneSymbol", by.y = colnames(deg_table)[2])
}
FEA_inputList <- lapply(FEA_inputList, function(x) {
     if(any(duplicated(x$human_EntrezGeneID))) {
          xspl <- split(x = x, f = x$human_EntrezGeneID)
          u <- lapply(xspl, function(y) {
               log_col <- y[,3]
               r <- data.frame(unique(y[,-3]), mean(log_col), stringsAsFactors = F)
               colnames(r) <- colnames(y)
               return(r)
          })
          u <- do.call("rbind", u)
          u <- data.frame(u, stringsAsFactors = F)
     } else {
          u <- x
     }
     return(u)
})

### FEA result
FEA_res <- read.delim(paste(bDir, "FEA_KEGG.txt", sep = "/"),
                      stringsAsFactors=FALSE)
feaList <- split(x = FEA_res, f = FEA_res$study)

#############################
# Count Directions
#############################
feaCount <- list()
for(grp in names(FEA_inputList)) {
     count <- countDirection(res = feaList[[grp]], input = FEA_inputList[[grp]])
     feaCount[[grp]] <- merge(feaList[[grp]], count)
}
feaCount <- lapply(feaCount, function(x) x[order(x$qvalue),])
feaCount <- lapply(feaCount, function(x) x[1:10,])
feaCount <- do.call("rbind", feaCount)
feaCount <- feaCount[,c("ID", "Description", "qvalue", "study", "up", "down")]

meltCount <- melt(data = feaCount, measure.vars = c("up", "down"))
meltCountList <- split(x = meltCount, f = meltCount$study)

#############################
# Plot
#############################
fplot <- lapply(meltCountList, function(meltCountData) {
     count_plot <- ggplot(data = meltCountData, mapping = aes(x = ID)) +
          geom_col(mapping = aes(y = value, fill = variable)) +
          coord_flip()
     qval_plot <- ggplot(data = unique(meltCountData[,1:3]), mapping = aes(x = ID)) +
          geom_col(mapping = aes(y = -log10(qvalue)), fill = "gray") +
          geom_hline(yintercept = -log10(0.05), color = "red", linetype = 2) +
          coord_flip()
     list("count_plot" = count_plot, "qval_plot" = qval_plot)
})
fplot <- lapply(names(fplot), function(grp,p) {
     mergedplot <- cowplot::plot_grid(plotlist = p[[grp]], 
                        align = "h", nrow = 1, rel_heights = c(0.5, 0.5))
     title <- ggdraw() + 
          draw_label(
               grp,
               fontface = 'bold',
               x = 0,
               hjust = 0
          ) +
          theme(
               # add margin on the left of the drawing canvas,
               # so title is aligned with left edge of first plot
               plot.margin = margin(0, 0, 0, 7)
          )
     plot_grid(
          title, mergedplot,
          ncol = 1,
          # rel_heights values control vertical title margins
          rel_heights = c(0.1, 1)
     )
}, p = fplot)
names(fplot) <- names(meltCountList)

#############################
# Save
#############################
ndir <- paste(getwd(), "FEA", sep = "/")
if(!dir.exists(ndir)) {
     dir.create(ndir)
}
ndir <- paste(ndir, "DEG", sep = "/")
if(!dir.exists(ndir)) {
     dir.create(ndir)
}
ndir <- paste(ndir, "KEGG", sep = "/")
if(!dir.exists(ndir)) {
     dir.create(ndir)
}

for(grp in names(fplot)) {
     p <- fplot[[grp]]
     fname <- paste(ndir, "/3_1_", grp, "_dualplot.pdf", sep = "")
     ggsave(filename = fname, plot = p)
}
fname <- paste(ndir, "/3_0_KEGGCountTable.txt", sep = "")
write.table(x = feaCount, file = fname, sep = "\t", row.names = F)