## original R code from viper package (aracne2regulon function)
## -----
## adapted by Marco A. De Bastiani: aracne2regulon_adapted 2019
###############
# aracne2regulon_adapted 
#   -- generates a regulon object from RTN ARACNe pipeline results and the corresponding expression dataset
#   -- add parallel option
# ARGUMENTS -- meltedmim (data.frame), eset (ExpressionSet or matrix), verbose (logical), cores (integer)
#   > meltedmim -- melted mutual information matrix from aracne reconstruction (tni@results$tn.ref or tni@results$tn.dpi)
#   > eset -- ExpressionSet object or matrix of gene expression
###############
aracne2regulon_adapted <- function (meltedmim,
                                    eset, 
                                    verbose = TRUE,
                                    cores = 3
){
    require(viper)
    viper_env <- environment(viper)
    if (is(eset, "ExpressionSet")) {
        eset <- exprs(eset)
    }
    if (verbose) {
        message("\nLoading the dataset...")
    }
    if (length(eset) == 1) {
        tmp <- strsplit(readLines(eset), "\t")
        dset <- t(sapply(tmp[-1], function(x) as.numeric(x[-(1:2)])))
        colnames(dset) <- tmp[[1]][-(1:2)]
        rownames(dset) <- sapply(tmp[-1], function(x) x[1])
        annot <- t(sapply(tmp[-1], function(x) x[1:2]))
    } else {
        dset <- eset
        annot <- rownames(eset)
        names(annot) <- rownames(eset)
        rm(eset)
    }
    if (verbose) {
        message("Generating the regulon objects...")
    }
    if (ncol (meltedmim) != 3) {
        stop ("Incorrect meltedmim argument.")
    } 
    colnames (meltedmim) <- c("target", "tf", "mi")
    aracne <- meltedmim
    tmp <- aracne[!is.na(aracne$mi), ]
    tmp <- tmp[rowSums(matrix(as.matrix(tmp[, 1:2]) %in% rownames(dset), nrow(tmp), 2)) == 2, ]
    aracne <- tapply(1:nrow(tmp), tmp$tf, function(pos, tmp) {
        tfmode <- rep(0, length(pos))
        names(tfmode) <- tmp$target[pos]
        list(tfmode = tfmode, likelihood = tmp$mi[pos])
    }, tmp = tmp)
    names(aracne) <- levels(tmp$tf)
    aracne <- viper_env$TFmode1(aracne, dset)
    rm(dset)
    aracne <- aracne[names(aracne) != "NA"]
    aracne <- mclapply(aracne, function(x) {
        filtro <- !(names(x$tfmode) == "NA" | is.na(x$tfmode) | 
                        is.na(x$likelihood))
        x$tfmode <- x$tfmode[filtro]
        x$likelihood <- x$likelihood[filtro]
        return(x)
    }, mc.cores = cores)
    aracne <- aracne[mclapply(aracne, function(x) {length(names(x$tfmode))}, mc.cores = cores) > 0]
    regul <- viper_env$TFscore(aracne, verbose = verbose)
    class(regul) <- "regulon"
    return(regul)
}