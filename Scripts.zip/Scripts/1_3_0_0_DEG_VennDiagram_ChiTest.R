#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste (getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install (c("reshape2"), repos = "http://lib.stat.cmu.edu/R/CRAN")

#############################
# Load Data
#############################
degList <- list()
degList[["MODEL-AD_hAbeta_KI_homozygous_22months-WT_22months"]] <- read.delim(file = "MODEL-AD_hAbeta_KI/homozygous_22months-WT_22months_DEG.txt", stringsAsFactors = F)
degList[["MODEL-AD_5XFAD"]] <- read.delim(file = "MODEL-AD_5XFAD/hemizygous-WT_DEG.txt", stringsAsFactors = F)
degList[["MODEL_APP.PS1"]] <- read.delim(file = "MODEL_APP.PS1/APPPS1-WT_DEG.txt", stringsAsFactors = F)

#############################
# Venn Diagram
#############################
threshold_cutoff <- 0.05
listSYMBOL <- lapply(X = degList, function(deg, threshold_cutoff) {
        symbol_col <- grepl(pattern = "hgnc", x = colnames(deg), ignore.case = T)
        if(!any(symbol_col)) {
                symbol_col <- grep(pattern = "symbol", x = colnames(deg), ignore.case = T)
        }
        sig_col <- grep(pattern = "value", x = colnames(deg), ignore.case = T)
        subset(deg[,symbol_col], subset = deg[,sig_col] < threshold_cutoff)
}, threshold_cutoff = threshold_cutoff)
listSYMBOL <- lapply(listSYMBOL, na.omit)
listSYMBOL <- lapply(listSYMBOL, unique)
a1 <- length(x = listSYMBOL[[1]])
a2 <- length(x = listSYMBOL[[2]])
a3 <- length(x = listSYMBOL[[3]])
n12 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[2]]))
n13 <- length(intersect(listSYMBOL[[1]], listSYMBOL[[3]]))
n23 <- length(intersect(listSYMBOL[[2]], listSYMBOL[[3]]))
n123 <- sum(table(c(listSYMBOL[[1]], listSYMBOL[[2]], listSYMBOL[[3]])) == 3)

#############################
# Chi Test
#############################
ki_countTest <- matrix(nrow = 2, ncol = 2, 
                       dimnames = list("row" = c(names(listSYMBOL)[2],
                                                 names(listSYMBOL)[3]), 
                                       "column" = c("Overlap", "NotOverlap")))
ki_countTest[names(listSYMBOL)[2], "Overlap"] <- n12
ki_countTest[names(listSYMBOL)[2], "NotOverlap"] <- a1 - n12
ki_countTest[names(listSYMBOL)[3], "Overlap"] <- n13
ki_countTest[names(listSYMBOL)[3], "NotOverlap"] <- a1 - n13
ki_countTestres <- chisq.test(ki_countTest, correct = T)

## proportion matrix
r_sum <- rowSums(ki_countTest)
prop_mtx <- ki_countTest
for(r in 1:nrow(prop_mtx)) {
        prop_mtx[r,] <- prop_mtx[r,]/r_sum[r]
}
prop_mtx <- round(prop_mtx, 3)

#############################
# Mosaic Plots
#############################
fname <- paste("1_2_1_1_MosaicPlots_ChiSquare_gene_models.pdf", sep = "")
pdf(file = fname, width = 12, height = 12)
mosaicplot(ki_countTest, 
           col = c("firebrick", "goldenrod1"), 
           cex.axis = 1, 
           xlab = "Disease", 
           ylab = names(listSYMBOL)[1], 
           main = ki_countTestres$method,
           sub = paste(names(ki_countTestres$statistic), " = ", round(ki_countTestres$statistic, 2), "; ",
                       "p-value = ", round(ki_countTestres$p.value, 4),
                       sep = ""))
plot.new()
gridExtra::grid.table(ki_countTest)
plot.new()
gridExtra::grid.table(prop_mtx)
dev.off()
