#############################
# Package Install/Load
#############################
setwd("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/")
source(paste(getwd(), "/Scripts/load or install packages.R", sep = ""))
load_or_install(c("RTN", "DESeq2"), 
                repos = "http://bioconductor.org/biocLite.R")

#############################
# Custom Function
#############################
## extract.intersections ####
# ARGUMENTS -- combination_matrix (matrix), symbolsList (list)
extract.intersections <- function (combination_matrix, symbolsList) {
        tcomb <- t(combination_matrix)
        tcomb <- data.frame(tcomb, stringsAsFactors = F)
        tcomb$intersection_count <- NA
        m <- (ncol(tcomb) - 1)
        if (m == 2) {
                for (r in seq(nrow(tcomb))) {
                        x <- tcomb[r,1]
                        y <- tcomb[r,2]
                        tcomb$intersection_count[r] <- length(intersect(x = symbolsList[[x]], y = symbolsList[[y]]))
                        rm(x, y, r)
                }
        } else {
                for (r in seq(nrow(tcomb))) {
                        s <- unlist(tcomb[r,1:m, drop = F])
                        symbs <- symbolsList[s]
                        symbs <- do.call("c", symbs)
                        symbs <- table(symbs)
                        tcomb$intersection_count[r] <- sum(symbs == m)
                        rm(s, symbs, r)
                }
        }
        return(tcomb)
}
#############################
## combinationDF ############
# ARGUMENTS -- combM_intersects (data.frame), index_vec (character)
#       > index_vec -- named character
combinationDF <- function(combM_intersects, index_vec) {
        m <- ncol(combM_intersects) - 1
        comb_df <- matrix(nrow = nrow(combM_intersects), 
                          ncol = 2, 
                          dimnames = list("row" = NULL, 
                                          "col" = c("combination_indexed", 
                                                    "intersection_count")))
        for (r in seq(nrow(combM_intersects))) {
                row_comb <- unlist(combM_intersects[r,1:m])
                row_comb <- paste(index_vec[row_comb], collapse = "|")
                comb_df[r,1] <- row_comb
                comb_df[r,2] <- combM_intersects[r,(m+1)]
        }
        return(comb_df)
}
#############################

#############################
# Load Data
#############################
MRA_Vargas2018 <- read.delim("/mnt/hd/Marco/Dropbox/PosDoc02_Zimmer/HumanDatasets/MRA_Vargas2018.txt", stringsAsFactors=FALSE)
iRegs <- MRA_Vargas2018$Regulon

#############################
# Extract results from TNA
#############################
regExp <- paste("TNA.*", ".RData$", sep = "")
## REGULONS MODELS
models <- c("MODEL-AD_5XFAD", "MODEL-AD_hAbeta_KI")
results <- list()
for(i in seq(models)) {
        model <- models[i]
        filename <- grep(pattern = regExp, dir(model), ignore.case = T)
        if(length(filename) == 1) {
                filepath <- paste(model, "/", dir(model)[filename], sep = "")
                load(filepath)
                results [[length(results) + 1]] <- tna.get(object = tna, what = "regulons")[iRegs]
                names(results)[length(results)] <- make.names(model)
                rm(tna, filename, filepath)
        } else {
                for (f in filename) {
                        filepath <- paste(model, "/", dir(model)[f], sep = "")
                        load(filepath)
                        results [[length(results) + 1]] <- tna.get(object = tna, what = "regulons")[iRegs]
                        m <- sub(pattern = "TNA_", replacement = "", x = basename(filepath))
                        m <- sub(pattern = ".RData", replacement = "", x = m)
                        m <- paste(model, m, sep = ".")
                        names(results)[length(results)] <- make.names(m)
                        rm(tna, f, filepath, m)
                }
        }
        rm(i)
}
models <- c("HumanDatasets/GSE39420/", "HumanDatasets/MergedSet/")
for(i in seq(models)) {
        model <- models[i]
        filename <- grep(pattern = regExp, dir(model), ignore.case = T)
        if(length(filename) == 1) {
                filepath <- paste(model, "/", dir(model)[filename], sep = "")
                load(filepath)
                results [[length(results) + 1]] <- tna.get(object = tna, what = "regulons")[iRegs]
                names(results)[length(results)] <- make.names(model)
                rm(tna, filename, filepath)
        } else {
                for (f in filename) {
                        filepath <- paste(model, "/", dir(model)[f], sep = "")
                        load(filepath)
                        results [[length(results) + 1]] <- tna.get(object = tna, what = "regulons")[iRegs]
                        m <- sub(pattern = "TNA_", replacement = "", x = basename(filepath))
                        m <- sub(pattern = ".RData", replacement = "", x = m)
                        m <- paste(model, m, sep = ".")
                        names(results)[length(results)] <- make.names(m)
                        rm(tna, f, filepath, m)
                }
        }
        rm(i)
}
regulon_targets <- lapply(results, function(x) {
        x <- unique(unlist(x))
        return(x)
})
regulon_targets <- unique(unlist(regulon_targets))

#############################
# Data Frames
#############################
degList <- list()
degList[["MODEL-AD_5XFAD"]] <- read.delim(file = "MODEL-AD_5XFAD/hemizygous-WT_DEG.txt", stringsAsFactors = F)
# degList[["MODEL-AD_hAbeta_KI_homozygous-WT"]] <- read.delim(file = "MODEL-AD_hAbeta_KI/homozygous-WT_DEG.txt", stringsAsFactors = F)
degList[["MODEL-AD_hAbeta_KI_homozygous_22months-WT_22months"]] <- read.delim(file = "MODEL-AD_hAbeta_KI/homozygous_22months-WT_22months_DEG.txt", stringsAsFactors = F)
# degList[["MODEL-AD_hAbeta_KI_homozygous_2months-WT_2months"]] <- read.delim(file = "MODEL-AD_hAbeta_KI/homozygous_2months-WT_2months_DEG.txt", stringsAsFactors = F)
# degList[["Human_EOAD"]] <- read.delim(file = "HumanDatasets/GSE39420/AD-control_DEG.txt", stringsAsFactors = F)
degList[["Human_LOAD"]] <- read.delim(file = "HumanDatasets/MergedSet/AD-control_DEG.txt", stringsAsFactors = F)
listSYMBOL <- lapply(X = degList, function(deg) {
        symbol_col <- grepl(pattern = "hgnc", x = colnames(deg), ignore.case = T)
        if(!any(symbol_col)) {
                symbol_col <- grep(pattern = "symbol", x = colnames(deg), ignore.case = T)
        }
        sig_col <- grep(pattern = "value", x = colnames(deg), ignore.case = T)
        subset(deg[,symbol_col], subset = deg[,sig_col] < 0.01)
})
listSYMBOL <- lapply(listSYMBOL, unique)
listSYMBOL <- lapply(listSYMBOL, function(x, targets) {
        x[x %in% targets]
}, targets = regulon_targets)

degUnion <- do.call("c", listSYMBOL)
degUnion <- unique(degUnion)
names(degUnion) <- degUnion

## Intersection DF extended
### Gene x Study - Logical Assignments
intersectDF_extended <- as.matrix(degUnion)
colnames(intersectDF_extended) <- "SYMBOL"
intersectDF_extended <- data.frame(intersectDF_extended, stringsAsFactors = F)
intersectDF_extended <- intersectDF_extended[order(intersectDF_extended$SYMBOL),,drop=F]
for (col in seq(listSYMBOL)) {
        intersectDF_extended[[names(listSYMBOL)[col]]] <- intersectDF_extended$SYMBOL %in% listSYMBOL[[col]]
}

## Intersectin DF simple
### Study | Study Index | Combinatin | Intersection Count
studies_vec <- 1:length(listSYMBOL)
names(studies_vec) <- names(listSYMBOL) 
studies_df <- data.frame("study" = names(listSYMBOL), "index" = studies_vec, stringsAsFactors = F)

ncomb2 <- combn(x = names(listSYMBOL), m = 2)
comb2_intersect <- extract.intersections(ncomb2, listSYMBOL)
ncomb3 <- combn(x = names(listSYMBOL), m = 3)
comb3_intersect <- extract.intersections(ncomb3, listSYMBOL)
# ncomb4 <- combn(x = names(listSYMBOL), m = 4)
# comb4_intersect <- extract.intersections(ncomb4, listSYMBOL)
# ncomb5 <- combn(x = names(listSYMBOL), m = 5)
# comb5_intersect <- extract.intersections(ncomb5, listSYMBOL)
# ncomb6 <- combn(x = names(listSYMBOL), m = 6)
# comb6_intersect <- extract.intersections(ncomb6, listSYMBOL)

comb_dfList <- list(comb2_intersect,
                    comb3_intersect
                    # comb4_intersect,
                    # comb5_intersect,
                    # comb6_intersect
)
comb_dfList <- lapply(comb_dfList, combinationDF, index_vec = studies_vec)
comb_df <- do.call("rbind", comb_dfList)

intersectDF_simple <- matrix(nrow = (nrow(studies_df) + nrow(comb_df)),
                             ncol = 4,
                             dimnames = list("row" = NULL,
                                             "col" = c(colnames(studies_df),
                                                       colnames(comb_df)
                                             )))
intersectDF_simple[1:nrow(studies_df), 1] <- studies_df$study
intersectDF_simple[1:nrow(studies_df), 2] <- studies_df$index
intersectDF_simple[(nrow(studies_df) + 1):nrow(intersectDF_simple), 3] <- comb_df[,1]
intersectDF_simple[(nrow(studies_df) + 1):nrow(intersectDF_simple), 4] <- comb_df[,2]

#############################
# Save
#############################
fname <- "3_2_1_IntersectionsTable_RegulonTargets_extended.txt"
write.table(x = intersectDF_extended, file = fname, sep = "\t", row.names = F)

fname <- "3_2_2_IntersectionsTable_RegulonTargets_simple.txt"
write.table(x = intersectDF_simple, file = fname, sep = "\t", row.names = F)
